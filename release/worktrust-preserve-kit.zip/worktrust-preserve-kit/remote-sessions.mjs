/**
 * SEVERAL AGENT SESSIONS ON ONE COMPUTER (2026-11-07; owner: the phone prompts and manages several sessions). Each remote
 * session has its own session_id, project, agent and process; they run side by side up to a maximum (settings
 * max_sessions, default 4), are listed in device.inventory and status.report, can be attached (their journal replayed),
 * stopped and closed, and resume by the agent's own session id.
 *
 * Order inside a start, held by tests: the steered ledger names the agent's session id BEFORE the agent is spawned (owner
 * decision 1: a remote-steered session is never the person's AI Hours), then session.created, then the agent. A command
 * that starts a turn is AGENT_ACCEPTED only when Claude Code begins that turn (its init line), never when the prompt went in.
 */
import { randomUUID } from "node:crypto";
import { basename, join } from "node:path";
import * as P from "./remote-protocol.mjs";
import { appendSteered } from "./remote-steered.mjs";
import { adapterOf, checkStartProbed } from "./remote-inventory.mjs";
import { allowedModes, startChoice } from "./remote-settings.mjs";
import { claudeArgs, isClaudeSessionId, removeQuietly, startClaude, writeMcpConfig } from "./remote-adapter-claude-code.mjs";
import { backgroundJobs, emptyClaudeState, endClaudeRun, mapClaudeLine } from "./remote-claude-events.mjs";
import { collectChanges, snapshotChanges } from "./remote-changes.mjs";
import { codexDeskGrants, isCodexThreadId, startCodex, writeBridgeSession } from "./remote-adapter-codex.mjs";
import { emptyCodexState, mapCodexMessage, unwrapShell } from "./remote-codex-events.mjs";
import { isOpenCodeSessionId, mintOpenCodeSessionId } from "./remote-adapter-opencode.mjs";
import { emptyOpenCodeState } from "./remote-opencode-events.mjs";
import { spawnOpenCode } from "./remote-opencode-session.mjs";
import { createCoalescer } from "./remote-coalesce.mjs";
import { accept, announceQueue, claudeReplay, codexLanded, dropWaiting, interruptedEnd, interruptOf, modelRefusal, steerLive, steerModeOf, switchModel } from "./remote-steering.mjs";
import { classifyAction } from "./remote-policy.mjs";
import { activeRows, listSessions, statusReport } from "./remote-session-list.mjs";
import { claudeHeard, claudeResume, closeTurn, openTurn, otherWay, refs, said, withActive, transcriptMark } from "./remote-turns.mjs"; // what was said, each turn, the active time, and how Claude Code is started again

export const DEFAULT_MAX_SESSIONS = 4;
const LEDGER_EVERY_MS = 10 * 60_000;
/** Per agent: the shape of its own session id (a resume names one), and a fresh stream state. */
const AGENT_ID = { "claude-code": isClaudeSessionId, codex: isCodexThreadId, opencode: isOpenCodeSessionId };
const FRESH_STATE = { "claude-code": emptyClaudeState, codex: emptyCodexState, opencode: emptyOpenCodeState };
export { createCoalescer } from "./remote-coalesce.mjs"; // kept here for the modules that import it from sessions

export function createSessions(ctx) {
  const live = new Map(); // session_id -> session

  const attention = (s, activity, needs = null, finished = false) => {
    const prev = s.attention;
    const next = { activity, needs, state_change_seq: (prev?.state_change_seq ?? 0) + 1, completion_seq: finished ? (prev?.completion_seq ?? 0) + 1 : prev?.completion_seq ?? null };
    s.attention = next;
    ctx.emit(s.session_id, "agent.attention", next, s.command_id, P.notifyHint(prev, next));
  };
  const mark = (s) => s.agent_ref && appendSteered({ v: 1, steered: "remote", adapter: s.adapter, agent_session_ref: s.agent_ref, remote_session_id: s.session_id, project_id: s.project_id, how: s.how, first_steered_at: s.first, last_steered_at: ctx.now() });
  const advance = (s, kind) => { if (s.command_id) ctx.journal.advance(s.command_id, { kind }, ctx.now()); };
  const deskGranted = (adapter, projectPath) => adapter === "codex" && codexDeskGrants({ env: ctx.agentEnv(), projectPath }).length > 0; // read at each start

  function nextTurn(s) {
    // A Claude Code steer not yet read may become a turn of its own: the next prompt waits until it was (P3-7).
    if (s.switching || s.turnOpen || s.queue.length === 0 || !s.run?.alive() || (s.adapter !== "codex" && s.steers.length > 0)) return;
    if (s.queue[0].model !== undefined && s.queue[0].model !== s.model && switchModel(ctx, s, s.queue[0].model, { respawn: () => spawnAgent(s, s.agent_ref), resumeTurns: () => nextTurn(s) }) === "later") return;
    const item = s.queue.shift();
    s.waiting = item;
    s.turnOpen = true; s.turnMark = { ...(s.adapter === "claude-code" ? transcriptMark(ctx.agentEnv(), s.projectPath, s.agent_ref) : null), at: ctx.now() }; // when these words were handed over, and where the closed turns end in its transcript
    s.run.write(item.text);
    announceQueue(ctx, s); // the ones still waiting moved up
  }

  /** A release's task ends with its turn (remote-releases.mjs), once. */
  const taskEnded = (s, outcome) => { if (s.task && !s.taskEnded) { s.taskEnded = true; ctx.onTaskEnded?.(s.session_id, outcome); } };

  function send(s, event) {
    event = interruptedEnd(ctx, s, event); // a turn the person interrupted was stopped, not failed
    if (event.type === "agent.stopped" && s.stopping) return; // stop() sends its own
    if (event.type === "agent.completed" || event.type === "agent.failed" || event.type === "agent.stopped") event = { ...event, body: withActive(ctx, s, event.body) };
    if (event.type === "agent.stopped") taskEnded(s, "stopped");
    if (event.type === "agent.usage") s.tokens = event.body.session;
    if (event.type === "agent.subagent") s.subagents.set(event.body.subagent_id, { subagent_id: event.body.subagent_id, parent_id: event.body.parent_id, label: event.body.label, state: event.body.state, tokens_total: event.body.tokens.total });
    if (event.type === "agent.completed" && event.body.result) Object.assign(event.body.result, collectChanges(s.snapshot ?? { source: "agent_tools" }, s.projectPath, s.agentFiles ?? [], ctx.runDir));
    if (event.type === "agent.step_started") advance(s, "running");
    if (event.type === "agent.completed") advance(s, "completed");
    if (event.type === "agent.failed") advance(s, "failed");
    ctx.emit(s.session_id, event.type, event.body, s.command_id, event.type === "agent.completed" ? "finished" : "none");
    if (event.type === "agent.completed") taskEnded(s, "completed");
    if (event.type === "agent.failed") taskEnded(s, "failed");
    ctx.onActivity?.();
  }

  /** Tokens and a running subagent's counts at most once per two seconds (the latest wins); an end goes at once. */
  function deliver(s, event) {
    const go = () => send(s, event);
    if (event.type === "agent.usage") return event.body.turn_final ? s.coalesce.now("usage", go) : s.coalesce.offer("usage", go);
    if (event.type === "agent.subagent") return event.body.state === "working" ? s.coalesce.offer(`sag:${event.body.subagent_id}`, go) : s.coalesce.now(`sag:${event.body.subagent_id}`, go);
    if (event.type === "agent.completed" || event.type === "agent.failed") s.coalesce.flush();
    go();
  }

  /** What still waits goes out, then every subagent still open is stopped: the map never shows one working forever. */
  function endRun(s) {
    s.coalesce.flush();
    if (s.adapter !== "claude-code") return; // Codex and OpenCode report no subagents to close
    const end = endClaudeRun(s.state, ctx.now());
    s.state = end.state;
    for (const e of end.events) deliver(s, e);
  }

  function onLine(s, line) {
    if (claudeHeard(ctx, s, line)) return; // its refusal to resume a session it never wrote: onExit starts it fresh (remote-turns.mjs)
    claudeReplay(ctx, s, line); // a live steer Claude Code read: accepted now
    // Background jobs the agent reports (2026-11-08): a change in the count re-sends the project tree, nothing else.
    const jobs = backgroundJobs(s.jobs ?? null, line);
    if (jobs !== (s.jobs ?? null)) { const was = s.jobs?.size ?? null; s.jobs = jobs; if (jobs.size !== was) ctx.onSessionsChanged?.(); }
    const mapped = mapClaudeLine(s.state, line, (prefix = "stp") => P.mintId(prefix, ctx.random), ctx.now());
    s.state = mapped.state;
    // Claude Code wrote under another id than the ledger names (a forked resume, a new version): the ledger names that one
    // too before the turn is accepted, so its log is never read as the person's (review 2026-11-07, P2-c).
    if (mapped.state.sessionRef && mapped.state.sessionRef !== s.agent_ref) { s.agent_ref = mapped.state.sessionRef; mark(s); ctx.journal.recordSession({ session_id: s.session_id, ...refs(ctx, s) }); }
    if (line.type === "assistant") for (const b of line.message?.content ?? []) if (b?.type === "tool_use" && /^(Edit|MultiEdit|Write|NotebookEdit)$/.test(b.name) && typeof (b.input?.file_path ?? b.input?.notebook_path) === "string") s.agentFiles.push(b.input.file_path ?? b.input.notebook_path);
    afterMapped(s, mapped);
  }

  /**
   * Codex's app-server stream (remote-codex-events.mjs), through the same turn handling as Claude Code's. Codex runs the
   * reads it deems safe without asking, so a command that reads a secret path ends the turn here, on the computer, as it
   * starts (review 2026-11-07, P1-3; the person accepted that gap when they turned Codex on).
   */
  function onCodex(s, msg) {
    if (msg?.method === "item/started" && msg.params?.item?.type === "commandExecution" && classifyAction("codex", "Bash", { command: unwrapShell(msg.params.item.command ?? "") }, s.projectPath).action.class === "secret_read") {
      s.run.interrupt();
      ctx.emit(s.session_id, "agent.output_delta", { stream: "tool", offset: 0, text: "Stopped on the computer: the agent began to read a secret path (keys, .env, credentials)." }, s.command_id);
    }
    const mapped = mapCodexMessage(s.state, msg, (prefix = "stp") => P.mintId(prefix, ctx.random), ctx.now());
    s.state = mapped.state;
    if (mapped.landed) codexLanded(ctx, s);
    afterMapped(s, mapped);
  }

  function afterMapped(s, mapped) {
    if (mapped.turn === "started") { s.ownTurn = Boolean(s.waiting); openTurn(ctx, s, mapped.state.turnStartedAt ?? null); }
    if (mapped.turn === "started" && !s.waiting && s.adapter === "codex" && s.steers.length > 0) { const item = s.steers.shift(); s.command_id = item.command_id; accept(ctx, s, item, "new_turn"); }
    if (mapped.turn === "started" && s.waiting) {
      const item = s.waiting;
      s.command_id = item.command_id; s.waiting = null;
      accept(ctx, s, item, "new_turn", mapped.state.turnStartedAt ?? null);
      attention(s, "working");
    }
    if (mapped.turn === "started") { s.turnOpen = true; s.snapshot = snapshotChanges(s.projectPath); s.agentFiles = []; s.turnStartedAt = mapped.state.turnStartedAt ?? ctx.now(); }
    for (const event of mapped.events) deliver(s, event);
    if (mapped.turn === "ended") {
      s.interrupting = false; closeTurn(ctx, s);
      s.turnOpen = false;
      if (s.jobs?.size) ctx.onSessionsChanged?.(); // "ready, but a job is still running": the tree hears the turn ended
      mark(s);
      attention(s, "idle", null, true);
      nextTurn(s);
    }
  }

  function onExit(s, how) {
    clearInterval(s.ledgerTimer);
    if (s.jobs?.size) { s.jobs = new Set(); ctx.onSessionsChanged?.(); } // its jobs ended with the agent's process group
    endRun(s);
    ctx.journal.recordSession({ session_id: s.session_id, pid: null });
    ctx.approvals.unregister(s.token);
    removeQuietly(s.mcpFile);
    // Claude Code only refused the START (a resume of a session it never wrote, or the reverse): the other way, once, the words kept.
    if (otherWay(s, how)) { s.run = null; s.turnOpen = false; if (s.waiting) { s.queue.unshift(s.waiting); s.waiting = null; } try { spawnAgent(s, s.agent_ref); return nextTurn(s); } catch { /* it did not come back: what waited is settled below, never left hanging */ } }
    if (s.turnOpen && !s.stopping) { advance(s, "failed"); ctx.emit(s.session_id, "agent.failed", { reason: "agent_exited", message: how.code === null ? null : `Claude Code exited (${how.code}).` }, s.command_id); taskEnded(s, "failed"); }
    if (!s.stopping) closeTurn(ctx, s);
    if (!s.stopping) taskEnded(s, "failed"); // an agent that exits before its task's turn ended did not do the task
    s.turnOpen = false;
    s.run = null;
    if (!s.switching) dropWaiting(ctx, s); // a revived session never runs words sent to the agent that died (a model switch's restart keeps them)
    ctx.onActivity?.();
  }

  /**
   * Codex: the thread id reaches the ledger before its first turn (startCodex calls onThread before turn/start). Its
   * planning tools are the session's own bridge, its token in a 0600 file beside Claude Code's MCP config (2026-11-09).
   */
  function spawnCodex(s, resume) {
    s.token = ctx.approvals.register(s); // so its open approvals are denied when it ends (P3-8)
    const plans = ctx.bridgePath && ctx.socket ? { node: ctx.node, bridge: ctx.bridgePath, session: s.mcpFile = writeBridgeSession(join(ctx.runDir, `${s.session_id}.codex.json`), { socket: ctx.socket(), token: s.token }) } : null;
    s.run = startCodex({ file: ctx.inventory().files.codex, cwd: s.projectPath, env: ctx.agentEnv(), model: s.model, mode: s.mode, resume, plans,
      onMessage: (msg) => onCodex(s, msg), onExit: (how) => onExit(s, how),
      onThread: (id) => { s.agent_ref = id; mark(s); ctx.journal.recordSession({ session_id: s.session_id, ...refs(ctx, s) }); },
      approve: async (tool, input) => (await ctx.approvals.request(s, tool, input))?.behavior === "allow" });
    ctx.journal.recordSession({ session_id: s.session_id, pid: s.run.pid ?? null });
    s.ledgerTimer = setInterval(() => { if (s.turnOpen) mark(s); }, LEDGER_EVERY_MS); s.ledgerTimer.unref?.();
  }

  function spawnAgent(s, resume) {
    if (s.adapter === "codex") return spawnCodex(s, resume);
    if (s.adapter === "opencode") return spawnOpenCode(ctx, s, { mark, onExit, afterMapped, everyMs: LEDGER_EVERY_MS }); // remote-opencode-session.mjs
    const features = ctx.inventory().features["claude-code"];
    s.token = ctx.approvals.register(s);
    s.mcpFile = writeMcpConfig(join(ctx.runDir, `${s.session_id}.mcp.json`), { node: ctx.node, bridge: ctx.bridgePath, socket: ctx.socket(), token: s.token });
    const args = claudeArgs({ features, mode: s.agentMode ?? s.mode, model: s.model, resume: claudeResume(ctx, s, resume), sessionRef: s.agent_ref, mcpConfig: s.mcpFile, effort: s.effort ?? null, addDirs: s.extraPaths ?? [], web: ctx.web?.() });
    mark(s); // the ledger names the session before the agent writes a line
    s.run = startClaude({ file: ctx.inventory().files["claude-code"], cwd: s.projectPath, env: ctx.agentEnv(), args, onLine: (line) => onLine(s, line), onExit: (how) => onExit(s, how) });
    ctx.journal.recordSession({ session_id: s.session_id, pid: s.run.pid ?? null, ...refs(ctx, s) }); // a later daemon ends it if this one dies (P2-b)
    s.ledgerTimer = setInterval(() => { if (s.turnOpen) mark(s); }, LEDGER_EVERY_MS); s.ledgerTimer.unref?.();
  }

  function start(env, payload) {
    if (live.has(env.session_id) || ctx.journal.session(env.session_id)) return "conflict";
    if ([...live.values()].filter((s) => s.run).length >= (ctx.settings().max_sessions ?? DEFAULT_MAX_SESSIONS)) return "busy";
    // Project and extras by the ids of the computer's own list, never a path; the 0.11.7 options against its own ceiling.
    const known = ctx.projects(), project = known.find((p) => p.project_id === env.project_id);
    if (!project) return "not_found";
    // A RESUME OF A DESK SESSION IS ASKED OF THE DESK FIRST (CLI 0.11.20; owner, 2026-11-21: a session open in VS Code was refused
    // `unsupported`): held on the computer is the answer (`in_use`) whatever the options say, and an id outside its own list is
    // `not_found`. A free, listed one still passes every check below before anything starts.
    const desk = payload.resume !== null && env.task !== true ? (ctx.desk ? ctx.desk.resumable(payload.resume, project.project_id) : "not_found") : null; if (desk) return desk; // release 36: only a session of the computer's own list, free
    const refused = checkStartProbed(payload, ctx.inventory); if (refused) return refused; // CLI 0.11.22: an agent whose probe failed is asked once more first
    const choice = startChoice(payload, project.project_id, ctx.inventory(), ctx.settings(), known); if (typeof choice === "string") return choice;
    if (!AGENT_ID[payload.adapter] || (payload.resume !== null && !AGENT_ID[payload.adapter](payload.resume))) return "unsupported";
    if (deskGranted(payload.adapter, project.path)) return "not_allowed"; // S0: Codex's own allow rules cannot be denied per session
    const s = { session_id: env.session_id, project_id: project.project_id, projectPath: project.path, adapter: payload.adapter, model: payload.model, mode: payload.permission_mode,
      agent_ref: payload.resume ?? (payload.adapter === "codex" ? null : payload.adapter === "opencode" ? mintOpenCodeSessionId(ctx.now(), ctx.random) : randomUUID()), how: payload.resume !== null && env.task !== true ? "attached" : "started", first: ctx.now(), queue: [], state: FRESH_STATE[payload.adapter](),
      coalesce: createCoalescer({ now: ctx.now }), attention: null, command_id: null, waiting: null, turnOpen: false, run: null, steers: [], interrupting: false, ownTurn: null, task: env.task === true, tokens: P.NO_TOKENS, subagents: new Map(), turnStartedAt: null, name: payload.name ?? null, active: 0, countedTurn: null,
      agentMode: payload.agent_mode ?? null, effort: choice.effort, extraIds: choice.extraProjectIds, extraPaths: choice.extras.map((p) => p.path) };
    live.set(s.session_id, s);
    ctx.journal.recordSession({ session_id: s.session_id, adapter: s.adapter, project_id: s.project_id, ...refs(ctx, s), ...(payload.resume !== null ? { transcript_seen: true } : {}), model: s.model, mode: s.mode, at: ctx.now(), name: s.name, active_ms: 0, ...(s.agentMode ? { agent_mode: s.agentMode } : {}), ...(s.effort ? { effort: s.effort } : {}), ...(s.extraIds.length ? { extra_project_ids: s.extraIds } : {}) });
    ctx.emit(s.session_id, "session.created", { adapter: s.adapter, model: s.model, origin: "phone", title: null, project_label: basename(project.path).slice(0, 256) || null, name: s.name }, env.command_id);
    spawnAgent(s, payload.resume);
    if (payload.prompt) s.queue.push(said(ctx, s, "start", { text: payload.prompt, command_id: env.command_id, received_at: ctx.now() }, env.sender_device_id));
    else { ctx.journal.advance(env.command_id, { kind: "agent_accepted" }, ctx.now()); ctx.emit(s.session_id, "command.agent_accepted", {}, env.command_id); attention(s, "idle"); }
    nextTurn(s);
    return null;
  }

  /** A known session whose agent is gone (a daemon restart) resumes by the agent's own id. */
  function revive(sessionId) {
    let s = live.get(sessionId);
    if (s?.run || s?.switching) return s; // a model switch restarts it on its own
    const saved = s ?? ctx.journal.session(sessionId);
    if (!saved || saved.closed) return null;
    const known = ctx.projects(), project = known.find((p) => p.project_id === saved.project_id), ref = s?.agent_ref ?? saved.agent_session_ref;
    if (!project || !AGENT_ID[saved.adapter]?.(ref) || deskGranted(saved.adapter, project.path)) return null;
    const agentMode = s?.agentMode ?? saved.agent_mode ?? null; // within today's ceiling, or it stays down (0.11.7)
    if (agentMode && !allowedModes(ctx.settings()).includes(agentMode)) return null;
    const extras = (s?.extraIds ?? saved.extra_project_ids ?? []).map((id) => known.find((p) => p.project_id === id)).filter(Boolean);
    if ([...live.values()].filter((x) => x.run).length >= (ctx.settings().max_sessions ?? DEFAULT_MAX_SESSIONS)) return null;
    s = s ?? { session_id: sessionId, project_id: saved.project_id, projectPath: project.path, adapter: saved.adapter, model: saved.model ?? null, mode: saved.mode ?? "ask", agent_ref: ref, how: "started", first: ctx.now(), queue: [], state: FRESH_STATE[saved.adapter](),
      coalesce: createCoalescer({ now: ctx.now }), attention: null, command_id: null, waiting: null, turnOpen: false, run: null, steers: [], interrupting: false, ownTurn: null, task: false, tokens: P.NO_TOKENS, subagents: new Map(), turnStartedAt: null, name: saved.name ?? null, active: saved.active_ms ?? null, countedTurn: null,
      agentMode, effort: saved.effort ?? null, extraIds: extras.map((p) => p.project_id), extraPaths: extras.map((p) => p.path) };
    live.set(sessionId, s); spawnAgent(s, s.agent_ref);
    return s;
  }

  async function stop(s) {
    if (!s.run) return;
    s.stopping = true;
    const command = s.command_id;
    await s.run.stop();
    endRun(s);
    s.stopping = false;
    if (command) ctx.journal.advance(command, { kind: "cancelled" }, ctx.now());
    ctx.emit(s.session_id, "agent.stopped", withActive(ctx, s, {}), command);
    closeTurn(ctx, s);
    taskEnded(s, "stopped");
    ctx.emit(s.session_id, "agent.output_delta", { stream: "tool", offset: 0, text: "Stopped. What the agent changed before the stop stays in the project: review it at the computer." }, command);
    dropWaiting(ctx, s);
    attention(s, "idle");
  }

  /**
   * A prompt or a steer (remote-steering.mjs): a live steer into the running turn; a prompt with interrupt ends that turn
   * and runs next; anything else waits its turn, and the phone is told its place (command.queued).
   */
  async function words(s, type, payload, command_id) {
    if (s.task) return "unsupported"; // a release task's session takes no words: add a task to the release instead (P2-2)
    const report = adapterOf(ctx.inventory(), s.adapter);
    const named = ctx.attachments ? ctx.attachments.referenceText(s.session_id, payload.attachments) : payload.attachments?.length ? null : ""; // null: refused, never ""
    if (named === null) return "not_found"; // a file it names is not here whole: never a prompt without its file
    const refusedModel = payload.model === undefined ? null : modelRefusal(ctx, s, payload.model); if (refusedModel) return refusedModel;
    const item = { text: payload.text + named, command_id, received_at: ctx.now(), ...(payload.model !== undefined ? { model: payload.model } : {}) };
    if (type === "agent.steer" && steerModeOf(report) === "none") return "unsupported";
    mark(s);
    if (type === "agent.steer" && s.turnOpen && steerModeOf(report) === "live" && (await steerLive(ctx, s, item))) return null;
    if (type === "agent.prompt" && payload.interrupt === true && s.turnOpen) {
      if (!interruptOf(report)) return "unsupported";
      s.queue.unshift(item);
      s.interrupting = true;
      announceQueue(ctx, s, "interrupting");
      if (!(await s.run.interrupt())) s.interrupting = false; // nothing to end: it simply runs next (P3-6)
      return null;
    }
    s.queue.push(item);
    if (s.turnOpen) announceQueue(ctx, s);
    nextTurn(s);
    return null;
  }

  const statusOf = (s) => statusReport(ctx, s);

  return {
    list: () => [...live.values()].filter((s) => !s.closed).map((s) => ({ session_id: s.session_id, project_id: s.project_id, adapter: s.adapter, origin: "phone", attention: s.attention ?? { activity: "unknown", needs: null, state_change_seq: 0, completion_seq: null }, title: null })),
    get: (id) => live.get(id) ?? null,
    statusOf,
    onApprovalOpened: (id) => { const s = live.get(id); if (s) { advance(s, "waiting_approval"); attention(s, "needs_you", "approval"); } },
    onApprovalSettled: (id) => { const s = live.get(id); if (s && s.turnOpen) { advance(s, "approval_resolved"); attention(s, "working"); } },
    /** One session command → null when it was taken, or the reject reason. */
    async handle(env, payload) {
      const type = env.type;
      if (type === "agent.start") return start(env, payload);
      if (type === "agent.pause" || type === "agent.resume" || type === "session.focus" || type === "screen.read" || type === "question.answer") return type === "question.answer" ? "not_found" : "unsupported";
      if (type === "session.rename" && !live.has(env.session_id)) {
        // A session from the journal (closed, or before a restart) keeps its history and takes a new name all the same.
        if (!ctx.journal.session(env.session_id)) return "not_found";
        ctx.journal.recordSession({ session_id: env.session_id, name: payload.name });
        ctx.onSessionsChanged?.();
        return "taken";
      }
      const s = type === "agent.prompt" || type === "agent.steer" ? revive(env.session_id) : live.get(env.session_id);
      if (!s) return "not_found";
      if (type === "agent.prompt" || type === "agent.steer") { const refused = await words(s, type, payload, env.command_id); if (refused === null) said(ctx, s, type === "agent.steer" ? "steer" : "prompt", { command_id: env.command_id }, env.sender_device_id, payload.text, payload.attachments?.length ?? 0); return refused; }
      if (type === "agent.stop") { await stop(s); return "taken"; }
      if (type === "status.get") { ctx.emit(s.session_id, "status.report", statusOf(s), env.command_id); return "taken"; }
      if (type === "session.attach") { await ctx.replay(s.session_id, 0, env.sender_device_id); return "taken"; } // the asker only, paced (remote-catch-up.mjs)
      if (type === "session.rename") { s.name = payload.name; ctx.journal.recordSession({ session_id: s.session_id, name: s.name }); ctx.onSessionsChanged?.(); return "taken"; }
      if (type === "session.close") { await stop(s); s.closed = true; live.delete(s.session_id); ctx.journal.recordSession({ session_id: s.session_id, closed: true }); return "taken"; }
      return "unsupported";
    },
    /**
     * A release's task, started by the scheduler (remote-releases.mjs): the same start as the phone's agent.start (the
     * steered ledger before the agent, checkStart, the cap), with no command of its own. → null, or a reject reason.
     */
    startTask: (t) => start({ session_id: t.session_id, project_id: t.project_id, command_id: null, task: true }, { adapter: t.adapter, model: t.model, permission_mode: t.permission_mode, resume: t.resume, prompt: t.prompt, name: t.name ?? null }),
    /** The project tree (2026-11-07): every session this computer knows, as remote-session-list.mjs lists them. */
    listAll: () => listSessions(ctx, live),
    /** Stop a running task's turn (release.cancel_task) → false when its agent was already gone. */
    async stopTask(sessionId) { const s = live.get(sessionId); if (!s?.run) return false; await stop(s); return true; },
    /** A task's session ends with its task: the agent exits and the slot frees. Nothing more is sent on its stream. */
    async closeTask(sessionId) {
      const s = live.get(sessionId);
      if (!s) return;
      s.closed = true;
      dropWaiting(ctx, s);
      if (s.run) { s.stopping = true; await s.run.stop(); }
      live.delete(sessionId);
      ctx.journal.recordSession({ session_id: sessionId, closed: true });
    },
    runningCount: () => [...live.values()].filter((s) => s.run).length,
    /** The live feed's rows (live.ts), without the release mapping the scheduler adds. */
    activeList: () => activeRows(live),
    async stopAll() { for (const s of live.values()) if (s.run) { s.stopping = true; await s.run.stop(500); } },
  };
}
