# AI evidence for coding agents

When the person asks to preserve or audit their AI work history, explain the local workflow and
ask them to run the relevant command in their own terminal. The WorkTrust CLI treats `preserve`
as person-only. Never run it for them, bypass agent detection or read their credential/session files.
This also applies after an ordinary yes: permission to explain a workflow does not remove the CLI policy.

- Show `worktrust preserve --verify` for archive integrity and `worktrust preserve --summary` for
  measured figures. Ask for only the relevant non-sensitive output; report no number of your own.
- For setup, explain `worktrust preserve`: it is interactive and can change retention settings or
  create/append an archive. It is not a read-only audit command. The person runs it themselves.
- Explain `--apply` and `--archive` when requested; never invoke them from the agent shell.
- If installation is needed, the person can use `npx worktrust@latest preserve` or install the CLI.
  The preservation implementation is local, but npm installation/bootstrap requires network access.
- Never run bare `worktrust`, `connect`, `history`, `update`, `disconnect` or import commands for the
  person, even if a current implementation gap would let them run. They can change coupling or send data.
- Never read or quote private prompts, answers, code, paths or commit messages from session stores.
- A signed archive proves continuity under a key, not that the work was independently verified.

The kit registers no background hooks. Preservation is manual: the person runs it in their own terminal.
Do not promise automatic archiving or remove environment variables as a workaround. Authorized
maintainers can test with synthetic homes and mock inputs only.

Guideline: https://worktrust.io/preserve
