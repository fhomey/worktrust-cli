# AI evidence for agents

A skill and an audit agent that explain how to keep and inspect a **local metadata record of AI-assisted work**.
Built on `worktrust preserve` ([npm](https://www.npmjs.com/package/worktrust)): the preservation implementation
needs no WorkTrust account and sends no data. Installing or bootstrapping the CLI can contact npm.
The person runs the commands; agents interpret the output they choose to provide.

AI tools delete their own history: Claude Code and Gemini CLI after 30 days by default. This keeps it.

## Install

Claude Code:

```
/plugin marketplace add fhomey/worktrust-ai-evidence
/plugin install ai-evidence@worktrust
```

Other agents (Codex, Cursor, Gemini CLI …): copy `AGENTS.md` into your project or your agent's instructions.

The CLI itself: `npm install -g worktrust`, or in a locked-down environment the checksummed kit from
[worktrust.io/preserve](https://worktrust.io/preserve).

## What is in it

| Part | What it does |
|---|---|
| `skills/ai-evidence` | Explains preservation and audit commands for you to run; interprets the output you provide. |
| `agents/ai-governance` | Reviews supplied integrity and usage output without reading your session stores. |
| `hooks/hooks.json` | Empty: no automatic commands, archiving or uploads. Preservation is manual. |
| `AGENTS.md` | The same rules for agents without skills. |

## What the agents may never do

State a number the tool did not print; read or quote private session content; execute person-only commands
(`worktrust`, `connect`, `history`, `preserve` and imports); or bypass agent detection. Bare `preserve` can write
settings or archives and is not a read-only audit. No background hook runs preservation for you.

## What the archive holds

Per AI app per day: start and end, measured seconds and what they were (model, tools, your turns, pauses), token
counts, subagent counts, the model's name, the kind and area of work, commit hashes, a one-way hash of the project,
and which computer and profile (as hashes). Each line is chained to the one before; each day has a root. Never a
prompt, an answer, code, a file path or a commit message. The full field list is in the
[worktrust README](https://www.npmjs.com/package/worktrust#keep-your-history).

Later, if you want, the same history can go into a WorkTrust passport; until you run that command yourself it stays
on your computer.

Archive signatures establish continuity under a key; they do not independently prove that work occurred.

MIT licence.
