#!/usr/bin/env node
/**
 * THE MOMENT OF THE WORK, RECORDED — a Claude Code hook that logs a finished stretch.
 * Session observations complement repository and CI evidence with locally recorded AI activity.
 * They do not establish independent verification or human presence by themselves.
 * IT NEVER LOSES A MEASURED DAY. A session is reported day by day, on whichever run comes first,
 * so a session that stays open for a fortnight is not a fortnight of silence; a machine that was
 * closed for four months hands over its months when it comes back, through the history door; and
 * a day the network refused is sent again on the next run, because the watermark advances over
 * what was accepted and stops at the first refusal.
 * This hook supplies exactly that half, and nothing else. It NEVER decides how good the work was:
 * scoring calls no model, and a stretch reported here is corroborated by the commit and the CI run
 * that land beside it or it counts for nothing. What it sends is what a clock and a token counter
 * recorded.
 *   node log-session.mjs --install            wire it into Claude Code (SessionEnd, SessionStart, PreCompact)
 *   node log-session.mjs --uninstall [--purge] take it out again (--purge also deletes the copies)
 *   node log-session.mjs --dry-run            show what the current transcripts would send
 *   node log-session.mjs --history [--dry-run] send the months already on this machine, as HISTORY
 *   node log-session.mjs --history --rebuild   the same, re-measured: the door REPLACES this computer's earlier lines, day by day
 *   node log-session.mjs --history --summary   one JSON line: sessions, hours, first and last month, per client (sends nothing)
 *   node log-session.mjs --history --export <path>  a ChatGPT or Claude data export (zip, folder or conversations.json) as
 *                                              HISTORY: hours RECONSTRUCTED from its clocks, never measured, never tokens;
 *                                              the door withdraws the product's earlier connector lines on its days (the
 *                                              export replaces, 2026-10-10); `--withdraw-unknown` (after the person's yes)
 *                                              also withdraws the AI-app lines under no product on exactly those days
 *   node log-session.mjs --find-exports [dir]  the exports lying in a folder (default ~/Downloads), and which were sent
 *   node log-session.mjs --history --from-folder <dir>  a person's own COPY of an AI app's session folder (a backed-up
 *                                              ~/.claude/projects or ~/.codex/sessions), read with the same readers and
 *                                              clock, never the live folders: days the live folders lack, RECONSTRUCTED
 *   node log-session.mjs --history --from-archive [dir]  the archive's stretches no longer in any AI app here: a day this
 *                                              computer's device key signed as measured, every other day reconstructed
 *   (as a hook)                                reads the hook's JSON on stdin, logs, exits
 *   (from Codex)                               notify = ["node", "~/.worktrust/log-session.mjs", "--codex-notify"]
 *                                              in ~/.codex/config.toml: Codex calls it at every turn's end and
 *                                              the sweep below finds the thread's rollout; its argument, which
 *                                              carries text, is never read
 *
 * CODEX ROLLOUTS (2026-09-27) are swept beside the Claude Code transcripts: ~/.codex/sessions holds
 * the same clocks, the model per turn and a token record per response, and the reader below turns
 * them into the lines this script already measures. One hook, two clients, one rule for both.
 * ANTIGRAVITY (2026-10-04) the same way: its brain/<id>/.system_generated/logs/transcript.jsonl is swept
 * as a third client (clocks and turns; it records no tokens), woken by its own Stop hook through
 * `worktrust.mjs hook --antigravity-stop`. The readers live in transcript-readers.mjs beside this file.
 *
 * WHAT CANNOT LEAVE. The payload is built from a fixed allowlist of keys, all of them numbers,
 * dates or vocabulary from the door's own enums, and the repository as owner/name and commit hashes. No prompt, no
 * answer, no file path, no commit message, no branch, no folder name. File paths ARE read locally to decide one layer keyword,
 * the way the connector reads them to decide an activity class, and only the keyword travels.
 *
 * WHAT IS MEASURED, AND BY WHOM (0.10.20, owner 2026-10-18: "the calculation must be done by our system; we only get
 * metadata"). This hook sends a stretch's TIMELINE: one step per transcript line, as the kind of line it was and the whole
 * seconds since the previous step, never a word. WorkTrust computes the seconds and the hours in layers from that timeline
 * with its own rules; nothing here counts an hour, and no constant in this file decides a figure. `duration_basis:
 * "measured"` says the timeline was read from the app's own folder on this computer; copied or exported history is
 * reconstructed. A local stretch without timestamps is skipped rather than estimated. Tokens are what each request ADDED
 * (input plus cache creation, cache reads excluded), which the door calls `newInput`. The figures the terminal shows come
 * from WorkTrust's receipts.
 *
 * CONFIDENTIAL PROJECTS never open: `~/.worktrust-counter.json` { "exclude": ["client-x"] } is
 * honoured here too, matched against the transcript's project directory, before a file is read.
 */
import { execFileSync, spawn, spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync, lstatSync, openSync, closeSync, fsyncSync, linkSync, unlinkSync, constants } from "node:fs";
import { homedir } from "node:os";
import { dirname, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash, createPrivateKey, createPublicKey, randomBytes, sign as cryptoSign } from "node:crypto";

import { moduleArgs, moduleExecutable } from "./package-integrity.mjs";

async function main() {
const args = process.argv.slice(2), NODE_FLAGS = process.versions.node === "26.5.0" ? ["--no-concurrent-sparkplug"] : [];
const flag = (name) => args.includes(`--${name}`), value = (name) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : undefined; }, DRY = flag("dry-run");
// Return from every terminal branch and drain naturally: forced exit can deadlock Node 26.5 while V8 compiles.
const exitFlushed = (code) => new Promise((resolve) => process.stdout.write("", resolve)).then(() => { process.exitCode = code; });

/**
 * THE OTHER HALF OF A SESSION: HOW IT WAS ASKED.
 *
 * This hook records that somebody was there. What KIND of work it was — the questions asked, the
 * assumptions surfaced, the counter-arguments, the verification requests — is the local counter's
 * job (`count-behaviour.mjs`, a named rubric over the same transcripts), and it was a thing a
 * person had to remember to run. Now the hook runs it, once a day, in STAGING mode: the reading
 * waits in the app until the owner clicks Import. That is not politeness, it is F-04 — the token
 * may stage, only the owner may count — and a hook that could send counts by itself would put an
 * automatic writer on the one surface that describes how a person thinks.
 */
const RELEASE_DIR = dirname(fileURLToPath(import.meta.url));
const COUNTER = join(RELEASE_DIR, "count-behaviour.mjs");
/** Legacy marker, used only when the person explicitly purges the old installation. */
const PINNED = join(homedir(), ".worktrust", "pinned");
/** A hook command is ours when it runs this file, or the `worktrust hook` wrapper that hands it the key from the key file. */
const ours = (command) => /log-session|worktrust(?:-launch)?\.(?:mjs|py)" (?:hook|--internal-module)|worktrust(?:-launch)?\.(?:mjs|py) hook/.test(String(command ?? ""));
const COUNTER_EVERY_MS = 24 * 3600_000;
/**
 * The live door refuses stretches older than two days; older work uses the history door.
 *
 * It is not a reason to lose the work. Past this line a measured day is filed through
 * `import_history` instead: the same counted seconds, marked as history, standing as history
 * stands (it corroborates, and it never lifts a level on its own). Late is not the same as untrue.
 */
const WINDOW_HOURS = 48;
/** A stretch still being worked in is not finished; half an hour of quiet says it is. The one timing rule this hook keeps: WHEN to sweep, never how long a stretch was. */
const IDLE_BEFORE_SWEEP = 30 * 60 * 1000;
/** Tools whose result waits for the person: the gap to it is the person's time. Names only; nothing of the call is read. */
const WAITS_FOR_PERSON = new Set(["AskUserQuestion", "ExitPlanMode"]);
/**
 * CONTEXT ENGINEERING (0.8.8, framework L6): which of an AI app's own context files the stretch changed, by category,
 * counted; read from the changed paths here, a path never leaves. Instructions (CLAUDE.md, AGENTS.md, GEMINI.md, Cursor
 * rules, Copilot instructions), skills, subagents, commands, the client's settings (permissions, hooks), MCP servers.
 */
const CONTEXT_FILES = [
  ["instructions", /(^|[\\/])(CLAUDE|AGENTS|GEMINI)\.md$|(^|[\\/])\.cursorrules$|(^|[\\/])\.cursor[\\/]rules[\\/]|copilot-instructions\.md$|\.instructions\.md$|(^|[\\/])\.windsurfrules$/i],
  ["skills", /(^|[\\/])\.claude[\\/]skills[\\/]|(^|[\\/])SKILL\.md$/],
  ["agents", /(^|[\\/])\.claude[\\/]agents[\\/]|(^|[\\/])\.github[\\/]agents[\\/]/],
  ["commands", /(^|[\\/])\.claude[\\/]commands[\\/]|(^|[\\/])\.github[\\/]prompts[\\/]/],
  ["settings", /(^|[\\/])\.claude[\\/]settings(\.local)?\.json$|(^|[\\/])\.codex[\\/]config\.toml$/],
  ["mcp", /(^|[\\/])\.?mcp\.json$|(^|[\\/])\.cursor[\\/]mcp\.json$|(^|[\\/])\.vscode[\\/]mcp\.json$/],
];
const contextFilesOf = (paths) => { const out = {}; for (const path of paths) for (const [kind, pattern] of CONTEXT_FILES) if (pattern.test(path)) { out[kind] = (out[kind] ?? 0) + 1; break; } return Object.keys(out).length ? out : null; };
/** An AI named as a commit's co-author by the tools that sign their work that way (read locally; the name never leaves). */
const AI_COAUTHOR = /\b(claude|anthropic|codex|openai|chatgpt|copilot|cursor|devin|gemini|jules|aider|windsurf|cline)\b/i;
/** A path that holds tests, by the conventions of the common test runners (read here; the path never leaves). */
const TEST_PATH = /(^|[\\/])(__tests__|tests?|spec|e2e)[\\/]|\.(test|spec)\.[cm]?[jt]sx?$|_test\.(go|py|rb)$|(^|[\\/])test_[^\\/]+\.py$|Tests?\.(java|kt|cs|swift)$/;
/**
 * THE ROUTE FROM GIT (0.9.2), of the stretch's own commits, read here and never kept: commits over twenty files, a fix
 * that followed another commit of the stretch, a commit naming an issue (#12, ABC-123); and of the changed files, how
 * many are CI, scripts or docs (what lets another person run it again). Subjects and paths never leave.
 */
const CI_PATH = /(^|[\\/])\.github[\\/]workflows[\\/]|(^|[\\/])\.gitlab-ci\.ya?ml$|(^|[\\/])Jenkinsfile$|(^|[\\/])\.circleci[\\/]|(^|[\\/])azure-pipelines\.ya?ml$/;
const SCRIPT_PATH = /(^|[\\/])scripts?[\\/]|(^|[\\/])Makefile$|(^|[\\/])justfile$|\.(sh|ps1)$/;
const DOC_PATH = /(^|[\\/])docs?[\\/]|(^|[\\/])README(\.[a-z]+)?$|(^|[\\/])CHANGELOG\.md$/i;
const FIX_SUBJECT = /^(fix|hotfix|revert)\b/i, ISSUE_REF = /#\d+\b|\b[A-Z][A-Z0-9]+-\d+\b/;
const gitRouteOf = (cwd, shas, paths) => {
  const out = {};
  if (cwd && shas.length > 0) {
    const commits = git(cwd, "log", "--no-walk", "--date-order", "--reverse", "--format=%x1e%s", "--shortstat", ...shas.slice(0, 50)).split("\x1e").map((block) => block.trim()).filter(Boolean)
      .map((block) => ({ subject: block.split("\n")[0], files: Number(/(\d+) files? changed/.exec(block)?.[1] ?? 0) }));
    const large = commits.filter((commit) => commit.files > 20).length, fixes = commits.slice(1).filter((commit) => FIX_SUBJECT.test(commit.subject)).length, issues = commits.filter((commit) => ISSUE_REF.test(commit.subject)).length;
    if (large) out.commits_large = large;
    if (fixes) out.fix_followups = fixes;
    if (issues) out.issue_refs = issues;
  }
  const ci = paths.filter((path) => CI_PATH.test(path)).length, scripts = paths.filter((path) => SCRIPT_PATH.test(path)).length, docs = paths.filter((path) => DOC_PATH.test(path)).length;
  if (ci) out.ci_files = ci;
  if (scripts) out.script_files = scripts;
  if (docs) out.doc_files = docs;
  return out;
};
/** The derived record of a stretch, kept for the local archive only (see payloadFor). */
const DERIVED = new WeakMap();

/**
 * WHEN THE HOOK RUNS. SessionEnd alone was a bet that sessions end, and a session that stays open
 * for a fortnight — resumed through every compaction — reported nothing for a fortnight. These
 * three are the moments Claude Code offers that come round on their own: a session closing, a
 * session opening, and a compaction, which on a long session happens several times a day.
 *
 * Running more often costs nothing extra: the watermark means a run with nothing new to say opens
 * no file, and a day still being worked in is never sent twice.
 */
const HOOK_EVENTS = ["SessionEnd", "SessionStart", "PreCompact"];

const STATE = join(homedir(), ".worktrust", "sessions.json");
const readState = () => { try { return JSON.parse(readFileSync(STATE, "utf8")); } catch { return {}; } }, writeState = (state) => { mkdirSync(dirname(STATE), { recursive: true }); writeFileSync(STATE, JSON.stringify(state, null, 1)); };
/**
 * THE FLOORS (owner, 2026-10-04: "history is never sent silently"). `__from` is the moment this
 * computer was coupled: the hook sends nothing measured before it, so a fresh coupling (or one after
 * `disconnect` purged the watermarks) never sweeps the computer's past into the record unasked. That
 * past is offered once, by `npx worktrust`, and goes only on a yes. `__historyFloor` is set when the
 * computer changed ACCOUNT: even that offer then starts at the change, so one person's earlier work
 * is never offered to the next account.
 */
const floorOf = (state, key) => { const at = typeof state?.[key] === "string" ? Date.parse(state[key]) : NaN; return Number.isFinite(at) ? at : null; };

/**
 * ONLY THE HOUSE'S OWN DOOR (2026-09-27, audit): the coupling used to be "any MCP server whose URL
 * contains /api/mcp", the conventional path of every hosted MCP server, so a person who also held
 * another product's server would have sent their work metadata there under that product's token and
 * fetched a script to run from its origin. A door is WorkTrust's when its host is worktrust.io or a
 * subdomain, or a local one named by WORKTRUST_MCP_URL; nothing else is a coupling.
 */
/** WorkTrust's own local doors (the app in development, 3011; a module branch, 3021). Another product's local MCP server
 * (the Advisory Board on 3007, 2026-10-09) is not one: it was offered for removal on update, and could have been adopted. */
const LOCAL_DOOR_PORTS = new Set(["3011", "3021"]);
const isWorkTrustDoor = (url) => {
  try {
    const parsed = new URL(String(url));
    if (!/\/api\/mcp\/?$/.test(parsed.pathname)) return false;
    const own = process.env.WORKTRUST_MCP_URL ? new URL(process.env.WORKTRUST_MCP_URL).host : null;
    return parsed.protocol === "https:" && (parsed.hostname === "worktrust.io" || parsed.hostname.endsWith(".worktrust.io")) || (own !== null && parsed.host === own) || ((parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1") && LOCAL_DOOR_PORTS.has(parsed.port));
  } catch { return false; }
};
/** The coupling: given, or the one Claude Code already holds — the same read the counter does. */
function coupling() {
  const url = value("url") ?? process.env.WORKTRUST_MCP_URL;
  const token = value("token") ?? process.env.WORKTRUST_MCP_TOKEN;
  if (url && token) return { url, token };
  try {
    const config = JSON.parse(readFileSync(join(homedir(), ".claude.json"), "utf8"));
    const found = [];
    const walk = (node) => {
      if (!node || typeof node !== "object") return;
      if (typeof node.url === "string" && isWorkTrustDoor(node.url)) {
        const auth = node.headers?.Authorization ?? node.headers?.authorization ?? "";
        if (auth.startsWith("Bearer ")) found.push({ url: node.url, token: auth.slice(7) });
      }
      for (const child of Object.values(node)) walk(child);
    };
    walk(config);
    if (found[0]) return found[0];
  } catch { /* no Claude Code config on this machine; Codex may hold the coupling */ }
  return codexCoupling();
}

const excludes = (() => {
  try { return (JSON.parse(readFileSync(join(homedir(), ".worktrust-counter.json"), "utf8")).exclude ?? []).map(String); } catch { return []; }
})();
const excluded = (path) => excludes.some((text) => text && path.includes(text));
/**
 * THE READERS live beside this file: Codex and Antigravity in transcript-readers.mjs (the counter imports it too, one
 * reader), the database clients in session-databases.mjs. The install copies both into ~/.worktrust with this hook.
 * Without them this hook still reads Claude Code; the never-matching patterns keep every other client out.
 */
const { CODEX_ROLLOUT = /(?!)/, codexIdOf = (file) => String(file).split(/[\\/]/).at(-1).replace(/\.jsonl$/, ""), antigravityIdOf = (file) => String(file).split(/[\\/]/).at(-4), codexLines, codexRolloutFiles = function* () {}, codexCwd = () => null, ANTIGRAVITY_TRANSCRIPT = /(?!)/, antigravityLines, antigravityRoots = () => [], antigravityTranscripts = function* () {}, antigravityContext = () => ({}), rememberAntigravity = () => null, codexLive = () => null } = (await import("./transcript-readers.mjs").catch(() => null)) ?? {};
// THE STRETCH'S DERIVED RECORD (0.7.4: split from this file): tool calls named by kind, verification, recovery, delegation,
// context and routing, for the local archive only. A copy without the module still measures and sends exactly as before.
const { callOf = (block) => ({ id: block.id, kinds: [], family: String(block.name), digest: "" }), deriveStretch = () => ({}), complexityOf = null, resultOf = (block) => ({ id: block.tool_use_id, failed: block.is_error === true, refusal: null }) } = (await import("./stretch-evidence.mjs").catch(() => null)) ?? {};
const { DATABASE_SESSION = /(?!)/, databaseLines = () => null, databaseSessions = function* () {} } = (await import("./session-databases.mjs").catch(() => null)) ?? {};
// A WEB CHAT'S DATA EXPORT AS HISTORY (0.10.10, owner 2026-10-10): chat-exports.mjs reads a ChatGPT or Claude export (the counter
// imports the same reader); `--history --export <path>` sends its conversations as RECONSTRUCTED days, never measured, never tokens.
const { EXPORT_CLIENTS = [], EXPORT_TITLES = {}, exportSessions = null, exportRef = null, exportRunRef = null, findExports = null } = (await import("./chat-exports.mjs").catch(() => null)) ?? {};
const { modCounts = () => null } = (await import("./claude-mod.mjs").catch(() => null)) ?? {}; // 0.10.15: the WorkTrust mod's live counts per Claude Code session and day; absent → no `live` group, never zeros
const liveOf = (file, day) => modCounts(String(file).split(/[\\/]/).pop().replace(/\.jsonl$/, ""), day) ?? codexLive(file, day); // 0.10.16: a Codex rollout's own
const { stackOfFiles = () => [], displayStackOfFiles = () => [] } = (await import("./stack-rules.mjs").catch(() => null)) ?? {}; // 0.10.11: core's stack rules and the display-only keys (tools_seen), generated (build-stack-rules --check); absent → nothing named, never a guess
const EXPORT_PATHS = []; for (let i = 0; i < args.length; i += 1) if (args[i] === "--export" && args[i + 1]) EXPORT_PATHS.push(args[i + 1]);
const DATABASE_CLIENTS = ["hermes", "goose", "opencode", "openclaw", "cursor", "copilot"]; // the registry's keys, the name each line carries
const LIVE_SOURCE = new RegExp(`^(codex|antigravity|${DATABASE_CLIENTS.join("|")}):`); // a sweep entry's id → the client it names (every database client, 0.6.16)
const READER_FILES = ["history-outbox.mjs", "transcript-readers.mjs", "session-databases.mjs", "stretch-evidence.mjs", "chat-exports.mjs", "stack-rules.mjs", "claude-mod.mjs"]; // 0.7.4: the derived record travels with the hook; 0.10.10: the export reader; 0.10.11: the stack rules; 0.10.15: the mod
/** The roots this machine's transcripts live under; a test names its own. */
const claudeRoot = () => value("transcript-root") ?? join(homedir(), ".claude", "projects");
const codexRoot = () => { const given = value("codex-root"); if (given) return given.replace(/^~(?=\/|$)/, homedir()); return value("transcript-root") ? null : join(homedir(), ".codex", "sessions"); };
/** Every Codex rollout and Antigravity conversation on this machine, an excluded project's threads skipped by their working directory. */
function* codexRollouts() {
  const root = codexRoot();
  for (const file of root ? codexRolloutFiles(root) : []) {
    const cwd = codexCwd(file);
    if (cwd && excluded(cwd)) continue;
    yield { id: `codex:${codexIdOf(file)}`, file };
  }
  yield* antigravityConversations();
  yield* databaseConversations();
}
/** The attended sessions of the clients that keep a database (session-databases.mjs); an excluded folder skipped. */
function* databaseConversations() {
  const given = Object.fromEntries(DATABASE_CLIENTS.map((client) => [client, value(`${client}-root`)]).filter(([, root]) => root));
  for (const { client, sessionId, file, cwd, writtenAt } of databaseSessions(given, Boolean(value("transcript-root")))) {
    if (!(cwd && excluded(cwd))) yield { id: `${client}:${sessionId}`, file, writtenAt };
  }
}
/** Antigravity beside Codex: one transcript per conversation, its folder known only from the Stop hook. */
function* antigravityConversations() {
  const given = value("antigravity-root");
  for (const { conversationId, file } of antigravityTranscripts(given || !value("transcript-root") ? antigravityRoots(given) : [])) {
    const { cwd } = antigravityContext(conversationId);
    if (!(cwd && excluded(cwd))) yield { id: `antigravity:${conversationId}`, file };
  }
}
/** A transcript's lines as objects, whichever client wrote it; null when the file cannot be read. */
const parsedLines = (file) => {
  if (DATABASE_SESSION.test(file)) return databaseLines(file);
  let lines; try { lines = readFileSync(file, "utf8").split("\n"); } catch { return null; }
  if (CODEX_ROLLOUT.test(file)) return [...codexLines(lines)];
  if (ANTIGRAVITY_TRANSCRIPT.test(file)) { const id = antigravityIdOf(file); return [...antigravityLines(lines, { id, ...antigravityContext(id) })]; }
  const out = [];
  for (const raw of lines) { if (!raw.trim()) continue; try { out.push(JSON.parse(raw)); } catch { /* a torn line */ } }
  return out;
};
/** The coupling Codex holds, when Claude Code holds none: the same door, read from ~/.codex/config.toml. */
function codexCoupling() {
  let toml; try { toml = readFileSync(join(homedir(), ".codex", "config.toml"), "utf8"); } catch { return null; }
  for (const block of toml.split(/\n(?=\[)/)) {
    if (!/^\[mcp_servers\./.test(block)) continue;
    const url = /^\s*url\s*=\s*"([^"]+)"/m.exec(block)?.[1];
    const token = /Bearer\s+([A-Za-z0-9_.-]+)/.exec(block)?.[1];
    if (url && isWorkTrustDoor(url) && token) return { url, token };
  }
  return null;
}

/** Which layer a set of paths touched — the same plain reading the connector uses for classes. */
const LAYER_RULES = [
  ["database", /(^|\/)migrations?\/|\.sql$|(^|\/)(schema|seed)s?\.(prisma|sql|ts|rb)$/i],
  ["integration", /(^|\/)(integrations?|connectors?|webhooks?|clients?|sdk)\/|\.(proto|graphql|gql)$|(^|\/)openapi\.(yaml|yml|json)$/i],
  ["tooling", /(^|\/)\.github\/|(^|\/)(infra|terraform|k8s|helm|deploy|scripts?)\/|\.(tf|tfvars)$|(^|\/)(Dockerfile|docker-compose[^/]*|Makefile)$|(^|\/)\.claude\//i],
  ["frontend", /\.(css|scss|less|html|vue|svelte|astro|jsx|tsx)$/i],
  ["backend", /\.(py|go|rs|java|kt|rb|php|cs|ex|exs|swift|c|cc|cpp|h|hpp)$|(^|\/)(api|server|lib)\//i],
  ["docs", /\.(md|mdx|rst|adoc)$|(^|\/)docs?\//i],
];
const layersOf = (paths) => {
  const tally = new Map();
  for (const path of paths) for (const [layer, rule] of LAYER_RULES) if (rule.test(path)) { tally.set(layer, (tally.get(layer) ?? 0) + 1); break; }
  // MOST FILES FIRST, BUT ALL OF THEM. One stretch through the front end, the back end and the
  // docs is one piece of work with one duration and three layers; reporting only the winner threw
  // two thirds of what it touched away, and a layer is what a dimension is attributed by.
  const ordered = [...tally.entries()].sort((a, b) => b[1] - a[1]).map(([layer]) => layer);
  return { layer: ordered[0] ?? null, layers: ordered };
};

const git = (cwd, ...argv) => { try { return execFileSync("git", ["-C", cwd, ...argv], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim(); } catch { return ""; } };
/**
 * owner/name of a remote WorkTrust can couple, or null (0.8.6, privacy by design). Only a repository on GitHub, GitLab or
 * Bitbucket can be joined to its commits, CI and deploys; the name of one on the person's own or a client's server
 * proves nothing and could name the client, so it is never sent. Nothing else of the remote is read.
 */
const CODE_HOSTS = /^(?:[a-z+]+:\/\/)?(?:[^@/]+@)?(github\.com|gitlab\.com|bitbucket\.org)[:/]/i;
const repoOf = (cwd) => {
  const remote = git(cwd, "remote", "get-url", "origin");
  if (!CODE_HOSTS.test(remote)) return null;
  const match = /[:/]([^/:]+)\/([^/]+?)(?:\.git)?$/.exec(remote);
  return match ? `${match[1]}/${match[2]}` : null;
};
/** The paths this stretch touched: what was committed inside it, else what is still uncommitted. */
const pathsTouched = (cwd, from, to) => {
  const committed = git(cwd, "log", `--since=${from}`, `--until=${to}`, "--name-only", "--pretty=format:", "--no-merges");
  const paths = committed.split("\n").map((line) => line.trim()).filter(Boolean);
  // The commits themselves, as shas — a hash and nothing of the message. They let the record
  // join this stretch to its own artefacts (roadmap R8); the paths above never travel.
  const shas = git(cwd, "log", `--since=${from}`, `--until=${to}`, "--format=%H", "--no-merges").split("\n").map((line) => line.trim()).filter((line) => /^[0-9a-f]{40}$/.test(line));
  if (paths.length > 0) return { paths, committed: true, shas };
  const dirty = git(cwd, "status", "--porcelain").split("\n").map((line) => line.slice(3).trim()).filter(Boolean);
  return { paths: dirty, committed: false, shas };
};

/**
 * One transcript → the unlogged stretches, measured, ONE PER DAY.
 *
 * It used to return a single stretch covering everything since the watermark, which was right for
 * a session that lasts an afternoon and wrong in three ways for one that lasts a fortnight: the
 * whole fortnight arrived as one record dated at its end, it was truncated at the door's
 * per-stretch ceiling, and none of it existed until the session finally closed. A day is the
 * boundary the history path already uses, it needs no guess about where one piece of work ended,
 * and it is the unit the record reads back anyway.
 */
function stretchesOf(file, since) {
  // A file we cannot read is no days, never a null the caller has to remember to check: this
  // returns a list now, and one caller forgetting that is one silent crash inside a hook.
  const lines = parsedLines(file);
  if (!lines) return [];
  const messages = [];
  let cwd = null, steered = STEERED_HERE;
  for (const line of lines) {
    if (typeof line.cwd === "string") cwd = line.cwd;
    if (typeof line.steered === "string") steered = line.steered; // a client that says how it was steered (Hermes's source)
    if (!line.timestamp || (line.type !== "user" && line.type !== "assistant")) continue;
    const at = Date.parse(line.timestamp);
    if (!Number.isFinite(at)) continue;
    if (since && at <= since) continue;
    messages.push(messageOf(line, at));
  }
  if (messages.length === 0) return [];
  messages.sort((a, b) => a.at - b.at);
  const byDay = byDayOf(messages);
  const agents = agentsByDay(file, since);
  return [...byDay.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([day, ofDay]) => { const stretch = measure(cwd, ofDay); return stretch && { ...stretch, ref: stretchRef(file, day), steered, agents: agents.get(day) ?? null, live: liveOf(file, day) }; }).filter(Boolean);
}

/**
 * DAYS SPLIT ON THE CLOCK, NOTHING LOST AT MIDNIGHT (0.6.18, audit C14). A stretch is one session's UTC day, and the gap
 * between a day's last message and the next day's first belonged to neither, so a run through the night lost one gap
 * per midnight. A day whose first message follows the last one within the sweep's half hour (the session never went quiet)
 * now opens with a BRIDGE: the message before it, carrying no tokens, no model and no turn, so the gap that crosses midnight
 * is in the day's timeline once, on the day it ends, for the server to count as it counts any other gap.
 * Messages must arrive sorted.
 */
function byDayOf(messages) {
  const byDay = new Map();
  let prev = null;
  for (const message of messages) {
    const day = new Date(message.at).toISOString().slice(0, 10);
    // Only a gap the work could have run through (no half hour of quiet): a session resumed the next morning opens its day as it always did.
    if (!byDay.has(day)) byDay.set(day, prev && message.at - prev.at <= IDLE_BEFORE_SWEEP ? [{ ...prev, usage: null, model: null, cumulative: false, bridge: true }] : []);
    byDay.get(day).push(message);
    prev = message;
  }
  return byDay;
}
/** The first message a day really holds (a bridge is the day before's). */
const firstOf = (messages) => (messages.find((message) => !message.bridge) ?? messages[0]).at;
/** The computer's offset from UTC at a moment, as +02:00: what the owner's mirror needs to read a working day in local time. */
const offsetAt = (ms) => { const minutes = -new Date(ms).getTimezoneOffset(), abs = Math.abs(minutes); return `${minutes < 0 ? "-" : "+"}${String(Math.floor(abs / 60)).padStart(2, "0")}:${String(abs % 60).padStart(2, "0")}`; };
/** Claude Code's own line when the person stops the agent mid-answer (Esc), read for its marker only. */
const INTERRUPTED = /^\[Request interrupted by user/;
const textOf = (content) => (typeof content === "string" ? content : Array.isArray(content) ? content.map((block) => (block && typeof block.text === "string" ? block.text : "")).join("") : "");

/** One transcript line as the measure reads it: the clock, the role, what KIND of message it is (for the layers), its counts. */
const messageOf = (line, at) => {
  const content = line.message?.content ?? null;
  const blocks = Array.isArray(content) ? content : [];
  return {
    // A COMPACTION'S SUMMARY IS NOT THE PERSON (0.7.4): Claude Code writes it on the user role; the counter always left it
    // out, the hook counted it as a turn and the gap before it as the person's time. It is the loop's own, like a meta line.
    at, type: line.type, usage: line.message?.usage ?? null, model: line.message?.model ?? null, messageId: typeof line.message?.id === "string" ? line.message.id : null, meta: line.isMeta === true || line.isCompactSummary === true, content,
    compacted: line.isCompactSummary === true,
    // 0.8.7: the permission mode the client recorded for this turn (Claude Code's own word; a reader's for Codex), never more.
    permissionMode: typeof line.permissionMode === "string" ? line.permissionMode : null,
    // A tool's answer comes back on the user role; a line a reader marks `agentic` is an agent run (Copilot's asked → completed).
    kind: line.type === "assistant" ? "assistant" : blocks.some((block) => block && block.type === "tool_result") ? "tool_result" : "user",
    toolUse: line.type === "assistant" && blocks.some((block) => block && block.type === "tool_use"),
    // A tool that waits for the PERSON (a question, a plan to approve): the gap to its result is the person's, not the tool's. The name is read, never the input.
    waitsForPerson: line.type === "assistant" && blocks.some((block) => block && block.type === "tool_use" && WAITS_FOR_PERSON.has(String(block.name))),
    agentic: line.agentic === true, cumulative: line.cumulative === true, // the session's running totals (Hermes, Goose without a ledger)
    // 0.7.1: each tool call's kinds (never its command) and each tool result's outcome, joined on the call's id in `measure`.
    // 0.7.2: and the call's FAMILY (the tool, and its check kinds) and a digest of its input, compared here and never kept.
    calls: line.type === "assistant" ? blocks.filter((block) => block && block.type === "tool_use" && typeof block.id === "string").map(callOf) : [],
    results: blocks.filter((block) => block && block.type === "tool_result" && typeof block.tool_use_id === "string").map(resultOf),
  };
};

/**
 * SUBAGENTS AS AGENT TIME, NEVER AS HOURS (owner, 2026-10-06). Claude Code writes each subagent's transcript beside its
 * session (`<session>/subagents/*.jsonl`: 279 of them beside 48 sessions on the computer this was built on), and the
 * sweep read only the sessions, so delegated work was invisible. Each run is read for its clocks: how many runs started
 * that day and how many were open at once at the busiest moment (read here for the complexity class). Their SECONDS are
 * not computed here since 0.10.20 (no counting rule ships in this file); until a timeline per run travels, the agent
 * group is not sent. Only Claude Code keeps subagents this way; every other client answers an empty map.
 */
function subagentFiles(file) {
  if (!/\.jsonl$/.test(String(file)) || CODEX_ROLLOUT.test(file) || ANTIGRAVITY_TRANSCRIPT.test(file) || DATABASE_SESSION.test(file)) return [];
  const dir = join(String(file).replace(/\.jsonl$/, ""), "subagents");
  try { return readdirSync(dir).filter((name) => name.endsWith(".jsonl")).map((name) => join(dir, name)); } catch { return []; }
}
function agentsByDay(file, since) {
  const byDay = new Map();
  for (const sub of subagentFiles(file)) {
    const lines = parsedLines(sub);
    if (!lines) continue;
    const stamps = [];
    let started = Infinity;
    for (const line of lines) {
      if (!line.timestamp || (line.type !== "user" && line.type !== "assistant")) continue;
      const at = Date.parse(line.timestamp);
      if (!Number.isFinite(at)) continue;
      started = Math.min(started, at);
      if (!(since && at <= since)) stamps.push(at);
    }
    // A RUN IS COUNTED ONCE, on the side of the watermark where it STARTED (review, 2026-10-06): a run that straddles the
    // watermark was sent with the day it began and is not a second run on the next sweep; what it did after the
    // watermark stays unsent, which is the safe direction.
    if (stamps.length === 0 || (since && started <= since)) continue;
    stamps.sort((a, b) => a - b);
    // A run is counted on the day it started.
    const day = new Date(stamps[0]).toISOString().slice(0, 10);
    if (!byDay.has(day)) byDay.set(day, { runs: 0, spans: [] });
    const entry = byDay.get(day);
    entry.runs += 1; entry.spans.push([stamps[0], stamps[stamps.length - 1]]);
  }
  for (const entry of byDay.values()) entry.peak = peakOf(entry.spans);
  return byDay;
}
/** The most spans open at one instant; a span that ends where another starts does not overlap it. */
const peakOf = (spans) => {
  const events = spans.flatMap(([from, to]) => [[from, 1], [to, -1]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  let open = 0, peak = 0;
  for (const [, delta] of events) { open += delta; peak = Math.max(peak, open); }
  return peak;
};

/**
 * IS THIS A HUMAN TURN? (2026-09-20)
 *
 * It used to be "every user-role message that is not meta", and in agentic work that is
 * overwhelmingly the AGENT's own tool results coming back — they arrive on the user role, because
 * that is how the protocol carries them. Measured on one real session: 959 counted, 910 of them
 * tool results, 49 actual prompts. A 19.6x inflation, and it grows with how autonomous the work is,
 * so the number moved the WRONG WAY exactly where it mattered: more agent loop read as more human
 * turns. The door's own field description has always said "one turn is one message from the
 * person"; this makes the hook agree with it.
 *
 * A human turn carries text (a string, or blocks with `text`/`image`) and NO `tool_result` block.
 * A message carrying both is a tool result with commentary attached, which is still the loop.
 */
function isHumanTurn(content) {
  if (typeof content === "string") return content.trim().length > 0;
  if (!Array.isArray(content)) return false;
  const types = new Set(content.map((block) => block && block.type));
  if (types.has("tool_result")) return false;
  return types.has("text") || types.has("image");
}

/** One day's messages → the stretch: its timeline, its tokens, its model. The server measures it. */
function measure(cwd, messages) {
  // THE CLOCK IS THE SERVER'S (0.10.20). This hook sends the stretch's timeline and never a duration of its own: every
  // second WorkTrust counts lies between two recorded timestamps in that timeline, under WorkTrust's rules, and a stretch
  // too short to time is a stretch WorkTrust answers without a duration. A stretch whose clocks give nothing is still
  // reported, so a commit beside it can be joined to a moment somebody was there.
  const models = new Map();
  for (const message of messages) if (message.model) models.set(message.model, (models.get(message.model) ?? 0) + 1);
  const model = [...models.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
  const tokens = tokensOf(messages);
  const from = firstOf(messages);
  return { cwd, derived: deriveStretch(messages, { isHumanTurn, INTERRUPTED, textOf }), timeline: messages.length > 0 ? timelineOf(messages) : null, ...tokens, cumulative: messages.some((message) => message.cumulative), model, from, to: messages[messages.length - 1].at, offset: offsetAt(from) };
}

/**
 * THE TIMELINE, FOR THE SERVER'S OWN CLOCK (0.10.20, owner 2026-10-18: "the calculation must be done by our system; we only get
 * metadata"). One step per message, as the KIND the measure read it as and the whole seconds since the previous step; the
 * first step carries 0, a bridge is lowercase, an agent run is marked G. Nothing of a message travels: not a word, not a
 * tool's name, not a path. WorkTrust computes `seconds`, the hours in layers, the turns, the interruptions and the mid-task
 * turns from this with its own rules (private to the server); this file sends no figure of its own, so nothing in it can
 * move the passport.
 */
function timelineOf(messages) {
  let out = "";
  for (let i = 0; i < messages.length; i += 1) {
    const message = messages[i];
    const gap = i === 0 ? 0 : Math.max(0, Math.round((message.at - messages[i - 1].at) / 1000));
    const kind = message.kind === "assistant" ? (message.waitsForPerson ? "W" : message.toolUse ? "T" : "A") : message.kind === "tool_result" ? "R" : INTERRUPTED.test(textOf(message.content).trim()) && !message.meta ? "I" : !message.meta && isHumanTurn(message.content) ? "H" : "U";
    out += `${message.agentic ? "G" : ""}${message.bridge ? kind.toLowerCase() : kind}${Math.min(999999, gap)}`;
  }
  return out;
}
/** A digest of this hook and the readers beside it, as installed: the door records it beside each line as a signal of which code ran, never as proof. */
const selfDigest = (() => { try { const here = dirname(fileURLToPath(import.meta.url)); const hash = createHash("sha256"); for (const name of ["log-session.mjs", ...READER_FILES].sort()) { try { hash.update(`${name}\0`).update(readFileSync(join(here, name))).update("\0"); } catch { hash.update(`${name}\0missing\0`); } } return hash.digest("hex"); } catch { return null; } })();
const CLI_VERSION_SENT = /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,4}$/.test(process.env.WORKTRUST_CLI_VERSION ?? "") ? process.env.WORKTRUST_CLI_VERSION : null; // `worktrust.mjs` hands its own version to the hook it starts

/**
 * THE TOKENS, AND THE CACHE HALVES APART (roadmap 16). Claude Code's usage block carries input_tokens, output_tokens,
 * cache_creation_input_tokens and cache_read_input_tokens. `tokensIn` stays what it was — new input plus what was written
 * into the cache (the `newInput` basis) — and the two cache halves travel beside it as their own counts, so the mirror can
 * read a hit ratio. A usage block of a SHAPE this script does not know (a key that is present and not a number, or a block
 * without input and output) means the parser is behind the client: the stretch is then sent WITHOUT tokens — never with a
 * guess, the same rule as an untimed stretch. `shapeKnown` says which happened.
 */
const USAGE_KEYS = ["input_tokens", "output_tokens", "cache_creation_input_tokens", "cache_read_input_tokens"];
function usageShapeKnown(usage) {
  if (!usage || typeof usage !== "object") return false;
  if (!("input_tokens" in usage) && !("output_tokens" in usage)) return false;
  return USAGE_KEYS.every((key) => !(key in usage) || usage[key] === null || (typeof usage[key] === "number" && Number.isFinite(usage[key]) && usage[key] >= 0));
}
function tokensOf(messages) {
  let tokensIn = 0, tokensOut = 0, cacheRead = 0, cacheWrite = 0, counted = 0, shapeKnown = true;
  // ONE ANSWER, ONE USAGE (0.6.18): Claude Code writes an answer as a line per content block (thinking, text, each tool
  // call), every one repeating the answer's usage; summed per line, a real session read 2.6 times its output tokens. An
  // answer with an id is counted once; a line without one (Codex's token events) is its own.
  const seen = new Set();
  for (const message of messages) {
    const usage = message.usage;
    if (!usage) continue;
    if (message.messageId) { if (seen.has(message.messageId)) continue; seen.add(message.messageId); }
    if (!usageShapeKnown(usage)) { shapeKnown = false; break; }
    counted += 1;
    tokensIn += (usage.input_tokens ?? 0) + (usage.cache_creation_input_tokens ?? 0);
    tokensOut += usage.output_tokens ?? 0;
    cacheRead += usage.cache_read_input_tokens ?? 0;
    cacheWrite += usage.cache_creation_input_tokens ?? 0;
  }
  if (!shapeKnown) return { tokensIn: 0, tokensOut: 0, cacheRead: 0, cacheWrite: 0, shapeKnown: false };
  return { tokensIn, tokensOut, cacheRead, cacheWrite, shapeKnown: counted > 0 };
}
// A SESSION'S TOTALS ARE SENT ONCE (0.6.16, audit H2). Hermes, and Goose without its ledger, keep tokens per SESSION on its last answer, so a resumed
// session sent its whole total again. Such a stretch sends what the total grew by since the one reported (kept beside the watermark), never a negative.
const TOTALS = ["tokensIn", "tokensOut", "cacheRead", "cacheWrite"];
const grownBy = (stretch, reported) => { if (!stretch.cumulative || !stretch.shapeKnown) return reported; const total = Object.fromEntries(TOTALS.map((key) => [key, Math.max(stretch[key], reported?.[key] ?? 0)]));
  for (const key of TOTALS) stretch[key] = Math.max(0, stretch[key] - (reported?.[key] ?? 0)); return total; }; // the total to keep; a fresh session sends its total, as before

// WHICH STRETCH, HOW STEERED (0.6.10): a hash of the session id (the file name; Antigravity's, always transcript.jsonl, its conversation's folder) and the day,
// the same on any computer, so a restored backup is never counted twice; `remote` only when the session runs over SSH, otherwise nothing is said.
const stretchRef = (file, day) => createHash("sha256").update(`worktrust-stretch|${ANTIGRAVITY_TRANSCRIPT.test(file) ? antigravityIdOf(file) : String(file).split(/[\\/]/).pop().replace(/\.jsonl?$/, "")}|${day}`).digest("base64url");
const STEERED_HERE = process.env.SSH_CONNECTION || process.env.SSH_CLIENT || process.env.SSH_TTY ? "remote" : null;

/** The one payload shape this script can build. Every key is a number, a date or an enum value. */
function payloadFor(stretch) {
  const cwd = stretch.cwd && existsSync(stretch.cwd) ? stretch.cwd : null;
  const repo = cwd ? repoOf(cwd) : null;
  const touched = cwd ? pathsTouched(cwd, new Date(stretch.from).toISOString(), new Date(stretch.to).toISOString()) : { paths: [], committed: false, shas: [] };
  const { layer, layers } = layersOf(touched.paths), stack = stackOfFiles(touched.paths), toolsSeen = displayStackOfFiles(touched.paths); // 0.10.11: the stack and the tools seen, from the same paths, keys only, two fields
  // The seventh kind, used as it is defined: a stretch that changed no artefact is knowing
  // something, not building something, and it earns neither an artefact's nor a validation's credit.
  const kind = touched.paths.length === 0 ? "researched" : touched.committed ? "changed" : "built";
  // 0.8.1: what the stretch changed, as counts of files (never their paths): how many, and how many of them tests.
  // 0.7.6: and the stretch's complexity class, read from what the hook knows here (layers, subagents, duration) and the record.
  const changed = [...new Set(touched.paths)], tests = changed.filter((path) => TEST_PATH.test(path)).length;
  // 0.8.7: of the stretch's commits, how many name an AI as co-author (the Co-authored-by trailer, read here, never kept).
  const coauthored = cwd && touched.shas.length > 0 ? git(cwd, "log", "--no-walk", "--format=%(trailers:key=Co-authored-by,valueonly,separator=%x01)%x00", ...touched.shas.slice(0, 50)).split("\0").filter((entry, index) => index < Math.min(50, touched.shas.length) && AI_COAUTHOR.test(entry)).length : 0;
  const route = { ...(stretch.derived?.route ?? {}), ...(touched.committed ? gitRouteOf(cwd, touched.shas, changed) : {}) };
  const derived = stretch.derived ? { ...stretch.derived, ...(Object.keys(route).length > 0 ? { route } : {}), ...(changed.length > 0 ? { changes: { files: changed.length, test_files: tests } } : {}), ...(touched.shas.length > 0 ? { authorship: { commits: Math.min(50, touched.shas.length), ai_coauthored: coauthored } } : {}), ...(contextFilesOf(changed) ? { context_files: contextFilesOf(changed) } : {}), ...(complexityOf ? { complexity: complexityOf(stretch.derived, { layers: Math.max(layers.length, layer ? 1 : 0), agentRuns: stretch.agents?.runs ?? 0, agentPeak: stretch.agents?.peak ?? 0, seconds: null }) } : {}) } : null;
  const evidence = derived || stretch.live ? { ...(derived ?? {}), ...(stretch.live ? { live: stretch.live } : {}) } : null; // 0.10.15: the mod's counts ride as their own group
  const payload = {
    title: layer ? `AI-assisted work · ${layer}` : "AI-assisted work",
    kind,
    ...(layer ? { layer } : {}),
    ...(layers.length > 1 ? { layers } : {}),
    ...(stack.length > 0 ? { stack } : {}),
    ...(toolsSeen.length > 0 ? { tools_seen: toolsSeen } : {}), // its own line: the payload allowlist (hook-presence) reads the key here
    // THE TIMELINE AND ITS BASIS, both or neither (0.10.20): the basis says the timeline was read from the app's own folder
    // on this computer; WorkTrust computes the duration from the timeline, and a timeline too short to time gets none.
    ...(stretch.timeline ? { timeline: stretch.timeline, duration_basis: "measured" } : {}),
    // Tokens only when the usage block's shape is the one this script knows — otherwise nothing, never a guess.
    ...(stretch.shapeKnown && stretch.tokensIn + stretch.tokensOut > 0 ? { tokens_in: stretch.tokensIn, tokens_out: stretch.tokensOut, token_basis: "newInput" } : {}),
    // The turns WorkTrust counts from the timeline are the person's own messages, tool results excluded — said explicitly,
    // because a row that does not say reads as the old count, which included them.
    ...(stretch.timeline ? { turn_basis: "humanOnly" } : {}),
    // The cache halves, as counts, beside the tokens (roadmap 16): read from a cache, written into one.
    ...(stretch.shapeKnown && stretch.cacheRead > 0 ? { tokens_cache_read: stretch.cacheRead } : {}),
    ...(stretch.shapeKnown && stretch.cacheWrite > 0 ? { tokens_cache_write: stretch.cacheWrite } : {}),
    ...(stretch.model ? { model: stretch.model } : {}),
    ...(repo ? { repo } : {}),
    ...(touched.shas.length > 0 ? { commits: touched.shas.slice(0, 50) } : {}),
    ...(stretch.ref ? { stretch_ref: stretch.ref } : {}), ...(stretch.steered ? { steered_from: stretch.steered } : {}),
    // WHICH CODE SENT IT (0.10.20): a version and a digest of this hook's own files, signals never proof.
    ...(CLI_VERSION_SENT ? { cli_version: CLI_VERSION_SENT } : {}),
    ...(selfDigest ? { cli_digest: selfDigest } : {}),
    // WHEN (0.6.18): the stretch's first moment and the computer's UTC offset then. The interruptions and the mid-task turns are
    // read by WorkTrust from the timeline; the subagents' seconds wait for a timeline per run (0.10.20).
    started_at: new Date(stretch.from).toISOString(), utc_offset: stretch.offset,
    // THE STRETCH'S EVIDENCE (0.8.3): what the CLI derived from it here, kinds and counts only (stretch-evidence.mjs); the door keeps it from a CLI key alone.
    ...(evidence ? { evidence } : {}),
    at: new Date(stretch.to).toISOString(),
  };
  // WHAT STAYS ON THIS COMPUTER (0.7.1): the stretch's derived record rides beside the payload for the local archive, never in it.
  // The same record rides beside the payload for the local archive (preserve --archive).
  if (evidence) DERIVED.set(payload, evidence);
  return payload;
}

/**
 * The history door, in the batch size it asks for. Oldest first, and a resend is safe: every entry
 * is deduplicated on its content, and one that knows more than a stored line FILLS it rather than
 * adding a twin. Returns how many entries were accepted, so a caller can advance a watermark over
 * exactly what landed. `announce` because one caller is a person watching a terminal and the other
 * is a hook holding a session's exit open.
 */
/**
 * THE BATCHES: at most two hundred lines each. `byDay` (an export, 2026-10-10) never splits a UTC day across two batches unless
 * one day alone exceeds the cap: the door's receipt counts per day what it replaced and how many AI-app lines lie there, and a
 * day in two batches would be counted twice.
 */
/** A batch stays under the door's body ceiling (4.5 MB) with room for the envelope: a timeline (0.10.20) is up to 200 KB a line, so a batch is cut by bytes as well as by count. */
const BATCH_BYTES = 3_500_000;
const bytesOf = (entry) => Buffer.byteLength(JSON.stringify(entry), "utf8");
const byBytes = (entries) => { const out = []; let current = [], size = 0; for (const entry of entries) { const bytes = bytesOf(entry); if (current.length > 0 && (current.length >= 200 || size + bytes > BATCH_BYTES)) { out.push(current); current = []; size = 0; } current.push(entry); size += bytes; } if (current.length) out.push(current); return out; };
function batchesOf(group, byDay) {
  if (!byDay) return byBytes(group);
  const days = new Map();
  for (const entry of group) { const day = String(entry.at).slice(0, 10); days.set(day, [...(days.get(day) ?? []), entry]); }
  const out = []; let current = [];
  for (const ofDay of days.values()) {
    if (ofDay.length > 200) { if (current.length) { out.push(current); current = []; } for (let i = 0; i < ofDay.length; i += 200) out.push(ofDay.slice(i, i + 200)); continue; }
    if (current.length + ofDay.length > 200) { out.push(current); current = []; }
    current.push(...ofDay);
  }
  if (current.length) out.push(current);
  return out;
}
/** THE RECEIPTS' COUNTS (2026-10-10): what an export send replaced, how many AI-app lines lie on its days, how many were withdrawn; summed over the batches, read for the counts alone. */
const RECEIPTS = { new: 0, alreadyHeld: 0, filled: 0, replaced: 0, superseded: 0, recut: 0, unknownOnDays: 0, unknownWithdrawn: 0, corrected: 0, measuredSeconds: 0 }; // 0.10.20: measuredSeconds is WorkTrust's own figure for what the batch stored, the one the terminal shows // 0.10.17: recut, the one-envelope export lines its runs replaced // 2026-10-10: and what a re-measure did (new, held, filled, replaced), so the command can say it
const noteReceipt = (answer) => {
  try {
    const json = JSON.parse(answer.trim().startsWith("{") ? answer : answer.split("\n").find((row) => row.startsWith("data:"))?.slice(5) ?? "null");
    const receipt = JSON.parse(json?.result?.content?.[0]?.text ?? "{}");
    for (const key of Object.keys(RECEIPTS)) RECEIPTS[key] += Number(receipt[key]) || 0;
  } catch { /* a receipt unread leaves the counts short, never the send */ }
};
/** Only explicit durable receipts authorize a checkpoint. HTTP 200 alone says nothing. */
function confirmedReceipt(answer, expectedCount = null) {
  try {
    const candidates = answer.trim().startsWith("{") ? [answer] : answer.split(/\r?\n/).filter(line => line.startsWith("data:")).map(line => line.slice(5).trim()).filter(line => line && line !== "[DONE]");
    const replies = candidates.map(text => JSON.parse(text)).filter(reply => reply?.id === 1);
    if (replies.length !== 1) throw Error();
    const reply = replies[0];
    if (reply.jsonrpc !== "2.0" || reply.error || !reply.result || reply.result.isError === true) throw Error();
    const content = reply.result.content;
    if (!Array.isArray(content) || content.length !== 1 || content[0].type !== "text") throw Error();
    const receipt = JSON.parse(content[0].text);
    if (expectedCount === null) {
      if (!(receipt.receipt === "received" && ["accepted", "flagged", "pending"].includes(receipt.status)) && !(receipt.receipt === "unchanged" && receipt.reason === "duplicate")) throw Error();
    } else if (receipt.receipt !== "received" || receipt.received !== expectedCount || receipt.refused !== 0
      || !Number.isInteger(receipt.new) || receipt.new < 0 || !Number.isInteger(receipt.alreadyHeld) || receipt.alreadyHeld < 0
      || receipt.new + receipt.alreadyHeld !== expectedCount) throw Error();
    return receipt;
  } catch { throw Error("WorkTrust did not confirm every line; progress was not advanced. Retained metadata and safe retries remain available."); }
}
/** A private metadata journal survives retries, an edited transcript and a later CLI update. */
function retainMeasurement(payload, source) {
  const fields = ["stretch_ref", "at", "started_at", "timeline", "seconds", "client_seconds", "model_seconds", "tool_seconds", "human_seconds", "idle_seconds", "tokens_in", "tokens_out", "tokens_cache_read", "tokens_cache_write", "exchanges", "interrupts", "steers", "agent_runs", "agent_seconds", "agent_peak", "duration_basis", "token_basis", "turn_basis", "cli_version", "cli_digest"];
  const metadata = Object.fromEntries(fields.filter(key => Object.hasOwn(payload, key)).map(key => [key, payload[key]]));
  const body = JSON.stringify({ format: "worktrust-measurement/1", source: source ?? "claude", metadata }) + "\n";
  const parent = join(homedir(), ".worktrust"), dir = join(parent, "measurements");
  for (const path of [parent, dir]) { mkdirSync(path, { recursive: true, mode: 0o700 }); const st = lstatSync(path); if (!st.isDirectory() || st.isSymbolicLink()) throw Error("WorkTrust metadata directory is not a private directory"); }
  const file = join(dir, createHash("sha256").update(body).digest("hex") + ".json");
  if (existsSync(file)) { const st = lstatSync(file); if (!st.isFile() || st.isSymbolicLink() || readFileSync(file, "utf8") !== body) throw Error("WorkTrust retained metadata did not match its digest"); return; }
  const temporary = join(dir, ".pending-" + randomBytes(18).toString("hex"));
  const fd = openSync(temporary, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | (constants.O_NOFOLLOW ?? 0), 0o600);
  try {
    writeFileSync(fd, body); fsyncSync(fd);
    try { linkSync(temporary, file); } catch (error) {
      if (error.code !== "EEXIST" || lstatSync(file).isSymbolicLink() || readFileSync(file, "utf8") !== body) throw error;
    }
  } finally { closeSync(fd); unlinkSync(temporary); }
}
const HISTORY_DELIVERY = { review: 0, waiting: 0 };
async function sendHistory(door, entries, announce = false, rebuild = false, named = false, { byDay = false, withdrawUnknown = false } = {}) {
  let accepted = 0;
  const { queuedHistory, historyRefusal } = await import("./history-outbox.mjs");
  // Keep each source and its approved coupling separate.
  const groups = [["claude", entries.filter((entry) => !entrySource.has(entry))], ["codex", entries.filter((entry) => entrySource.get(entry) === "codex")], ...["antigravity", ...DATABASE_CLIENTS, ...EXPORT_CLIENTS].map((client) => [client, entries.filter((entry) => entrySource.get(entry) === client)])];
  const encodeBatch = batch => JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "import_history", arguments: { ...(rebuild ? { rebuild: true } : {}), ...(withdrawUnknown ? { withdraw_unknown: true } : {}), entries: batch.map(({commits, ...rest}) => { void commits; return rest; }) } } });
  // Persist the approved plan before sending, so later batches survive removed source files too.
  try { for (const [source, group] of groups) { const target = source === "codex" ? codexDoor ?? door : door; if (target) for (const batch of batchesOf(group, byDay)) queuedHistory(target, encodeBatch(batch), source); } }
  catch { console.error("History queue is full, busy or unavailable. Resume the saved batches before retrying this import; nothing was marked complete."); HISTORY_DELIVERY.waiting += entries.length; return 0; }
  for (const [source, group] of groups) {
  const target = source === "codex" ? codexDoor ?? door : door;
  if (group.length === 0 || !target) continue;
  let number = 0;
  for (const batch of batchesOf(group, byDay)) {
    number += 1;
    // Imported entries carry no live commit/session join.
    const body = encodeBatch(batch);
    for (const entry of batch) retainMeasurement(entry, source);
    // `named` (0.10.10): a copied folder's lines name their client too, so the record says which app the copy came from.
    let queued;
    try { queued = queuedHistory(target, body, source); }
    catch { console.error("Pending history could not be stored safely. Nothing was marked complete; keep the local WorkTrust folder for recovery."); HISTORY_DELIVERY.waiting += batch.length; break; }
    if (queued.status === "acknowledged" && !byDay) { accepted += batch.length; RECEIPTS.alreadyHeld += batch.length; continue; }
    if (queued.status === "review" && !flag("retry-review")) { HISTORY_DELIVERY.review += batch.length; continue; }
    if (queued.status === "waiting") { HISTORY_DELIVERY.waiting += batch.length; continue; }
    try {
      const response = await fetch(target.url, { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", authorization: `Bearer ${target.token}`, ...clientOf(source, rebuild || named), ...proofFor(target.url, body) }, body, redirect: "error", signal: AbortSignal.timeout(65_000) });
      const text = await response.text();
      try { if (!response.ok) throw Error(); confirmedReceipt(text, batch.length); }
      catch {
        const refusal = historyRefusal(text, response); queued.defer(refusal.reason, refusal.seconds);
        if (refusal.reason === "review") { HISTORY_DELIVERY.review += batch.length; continue; }
        HISTORY_DELIVERY.waiting += batch.length; break;
      }
      queued.confirm(); accepted += batch.length; noteReceipt(text);
      if (announce) console.log(`batch ${number}: received ${batch.length}`);
    } catch { queued.defer("unconfirmed"); HISTORY_DELIVERY.waiting += batch.length; break; }
  }
  }
  return accepted;
}

/** Whether the door's import_history takes `from_archive` (0.8.0): asked with tools/list, never assumed. */
async function doorKnowsArchive(target) {
  if (!target) return false;
  try {
    const body = JSON.stringify({ jsonrpc: "2.0", id: 0, method: "tools/list" });
    const response = await fetch(target.url, { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", authorization: `Bearer ${target.token}`, ...proofFor(target.url, body) }, body });
    const text = await response.text();
    const json = JSON.parse(text.trim().startsWith("{") ? text : text.split("\n").find((row) => row.startsWith("data:"))?.slice(5) ?? "null");
    const tool = json?.result?.tools?.find((one) => one.name === "import_history");
    return Boolean(tool?.inputSchema?.properties?.entries?.items?.properties?.from_archive);
  } catch { return false; }
}

/** DEVICE PROOF (2026-10-03): through `worktrust hook` a bound computer hands over WORKTRUST_DEVICE_KEY; every call is then signed. */
const proofFor = (url, body) => {
  const device = process.env.WORKTRUST_DEVICE_KEY;
  if (!device) return {};
  const seconds = String(Math.floor(Date.now() / 1000));
  const nonce = randomBytes(18).toString("base64url");
  return { "worktrust-proof": `${seconds}.${nonce}.${cryptoSign(null, Buffer.from(`POST\n${new URL(url).pathname}\n${seconds}\n${nonce}\n${createHash("sha256").update(body).digest("hex")}`), device).toString("base64url")}` };
};

/**
 * WHICH CLIENT A LINE CAME FROM, FOR THE DOOR (2026-10-04). Through the bridge one key serves every app
 * on this computer, and the door names a coupling's clients by the user-agent it hears (mcp_identify's
 * agents_seen). An Antigravity line names Antigravity: the product name, nothing of the work.
 */
const clientOf = (source, always = false) => (CLI_VERSION_SENT || always || source === "antigravity" || DATABASE_CLIENTS.includes(source) || EXPORT_CLIENTS.includes(source) ? { "user-agent": `${source ?? "claude"}/hook (worktrust-hook)${CLI_VERSION_SENT ? ` worktrust-cli/${CLI_VERSION_SENT}` : ""}` } : {});

async function send(door, payload) {
  retainMeasurement(payload, entrySource.get(payload));
  const body = JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "log_work", arguments: payload } });
  const response = await fetch(door.url, { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", authorization: `Bearer ${door.token}`, ...clientOf(entrySource.get(payload)), ...proofFor(door.url, body) }, body });
  if (!response.ok) throw new Error(`door said ${response.status}`);
  const text = await response.text();
  confirmedReceipt(text);
  return text;
}

/**
 * THE MONTHS ALREADY ON THIS MACHINE, AS HISTORY.
 *
 * The hook records what happens from today. Everything before it sits in the same transcripts,
 * with the same clocks, and the door has a separate path for it — `import_history`, which marks a
 * line as imported: it forms no session, adds no verified hour and carries no level, so nothing
 * here can inflate a credential. What it CAN do is give the record days, months, layers and a
 * rhythm it had no way to know about, and it is the only half of the past that is honest to send:
 * a measured stretch from the person's own machine, not an estimate of what probably happened.
 *
 * One entry per DAY per transcript. A file may span a week; a day is the unit the reconstruction
 * matches commits by, and cutting on the calendar keeps `at` a real instant rather than an
 * average of one. Younger than the live window is left alone — that is `log_work`'s half.
 */
function historyEntries(floor = null, all = false) {
  const entries = [];
  for (const { file } of allTranscripts()) {
    const lines = parsedLines(file);
    if (!lines) continue;
    let cwd = null, steered = null;
    const read = [];
    for (const line of lines) {
      if (typeof line.cwd === "string") cwd = line.cwd;
      if (typeof line.steered === "string") steered = line.steered;
      if (!line.timestamp || (line.type !== "user" && line.type !== "assistant")) continue;
      const at = Date.parse(line.timestamp);
      if (!Number.isFinite(at)) continue;
      read.push(messageOf(line, at));
    }
    read.sort((a, b) => a.at - b.at);
    const byDay = byDayOf(read);
    const agents = agentsByDay(file, null);
    for (const [day, messages] of byDay) {
      if (messages.length === 0) continue;
      // Under-reporting is the safe side (THE FLOORS): a day that began before the account changed is not offered at all.
      if (floor !== null && firstOf(messages) < floor) continue;
      const last = messages[messages.length - 1].at;
      // The live window belongs to the hook: a stretch that log_work may still report is not history.
      if (!all && Date.now() - last < WINDOW_HOURS * 3600_000) continue;
      // The same measure as a live day (seconds, layers, tokens, turns, model); history differs only in the door it goes through.
      const entry = payloadFor({ ...measure(cwd, messages), ref: stretchRef(file, day), steered, agents: agents.get(day) ?? null, live: liveOf(file, day) });
      if (CODEX_ROLLOUT.test(file)) entrySource.set(entry, "codex");
      if (ANTIGRAVITY_TRANSCRIPT.test(file)) entrySource.set(entry, "antigravity");
      if (DATABASE_SESSION.test(file)) entrySource.set(entry, file.slice(0, file.indexOf(":")));
      entryFile.set(entry, { file, from: firstOf(messages), folder: cwd ? String(cwd).split(/[\\/]/).filter(Boolean).pop() ?? null : null });
      entries.push(entry);
    }
  }
  const seen = new Set(); // ONE SESSION FILE IN TWO PROJECT FOLDERS (a copied folder) IS ONE STRETCH (0.6.16, audit M6), as live and preserve count it
  return entries.filter((entry) => !seen.has(entry.stretch_ref) && seen.add(entry.stretch_ref)).sort((a, b) => a.at.localeCompare(b.at));
}

/**
 * A DATA EXPORT'S CONVERSATIONS AS HISTORY (0.10.10, owner 2026-10-10: "hours from an export count as reconstructed, shown,
 * never in verified hours"). Since 0.10.17 one line per RUN of activity in a conversation-day (runsOf, below), no longer one
 * envelope per conversation and day. Each run travels as its TIMELINE (0.10.20) and WorkTrust computes its reconstructed
 * seconds and the person's turns from it; the line says `reconstructed`: the file can be edited before it is read and no
 * device key witnessed it. No tokens (the export carries none and none are estimated), no evidence; the title names the
 * product and never the conversation; the stretch's name is the vendor, the conversation's id and the day, so the same
 * export sent twice is each line once. The database keeps a reconstructed stretch inside eight hours (20261009170000).
 */
/**
 * WHERE A CONVERSATION-DAY IS CUT (CLI 0.10.17, owner 2026-10-17): the hook's own stretch-finished gap, IDLE_BEFORE_SWEEP
 * (half an hour of quiet says a stretch is finished), never a new constant. The gap the cut falls in belongs to the run
 * BEFORE it: that run's timeline ends with a closing step carrying the gap (kind U, the loop's own, never a turn), so
 * WorkTrust counts the gap after the last message as it did when the day was one envelope, and only the windows sharpen.
 */
const RUN_GAP = IDLE_BEFORE_SWEEP;
function runsOf(messages) {
  const runs = [];
  let current = null;
  for (let i = 0; i < messages.length; i += 1) {
    const gap = i === 0 ? null : messages[i].at - messages[i - 1].at;
    if (current && gap > RUN_GAP) { current.tail = messages[i].at; current = null; }
    if (!current) { current = { messages: [], tail: null }; runs.push(current); }
    current.messages.push(messages[i]);
  }
  return runs;
}
const EXPORTS_STATE = join(homedir(), ".worktrust", "exports.json"); // per export digest: sent, or offered and declined; nothing of a conversation
const readExportsState = () => { try { return JSON.parse(readFileSync(EXPORTS_STATE, "utf8")); } catch { return {}; } };
const rememberExport = (digest, note) => { const state = readExportsState(); state[digest] = { ...(state[digest] ?? {}), ...note }; mkdirSync(dirname(EXPORTS_STATE), { recursive: true }); writeFileSync(EXPORTS_STATE, JSON.stringify(state, null, 1)); };
async function exportEntries() {
  if (!exportSessions || !exportRunRef) throw Error("chat-exports.mjs is not beside this file, or is older than this hook: a data export cannot be read");
  const entries = [], reports = [];
  for (const given of EXPORT_PATHS) {
    const read = {}, report = { days: new Set() }; // 0.10.18: the reader streams the export and fills `read` as it goes (path and vendor first; digest, count and the conversations left out as too large at the end)
    for await (const { id, lines } of exportSessions(given, { excluded, report: read })) {
      const messages = [];
      for (const line of lines) { const at = line.timestamp ? Date.parse(line.timestamp) : NaN; if (Number.isFinite(at)) messages.push(messageOf(line, at)); }
      messages.sort((a, b) => a.at - b.at);
      for (const [day, ofDay] of byDayOf(messages)) {
        if (ofDay.length === 0) continue;
        // ONE STRETCH PER RUN OF ACTIVITY (0.10.17): the day's messages cut where the hook calls a stretch finished; one run
        // is the day as before, under the name it always had; several name the one-envelope line they replace.
        const runs = runsOf(ofDay), old = exportRef(read.vendor, id, day);
        runs.forEach(({ messages: run, tail }, index) => {
          const stretch = measure(null, run), ref = runs.length === 1 ? old : exportRunRef(read.vendor, id, day, index);
          // The run's timeline, with the gap to the next run as a closing step (the loop's own, never a turn), so WorkTrust
          // counts it with this run as the one envelope did; the last run of the day closes where the day did.
          const timeline = stretch.timeline ? `${stretch.timeline}${tail ? `U${Math.min(999999, Math.max(0, Math.round((tail - run[run.length - 1].at) / 1000)))}` : ""}` : null;
          const entry = {
            title: EXPORT_TITLES[read.vendor], kind: "researched",
            ...(timeline ? { timeline, duration_basis: "reconstructed", turn_basis: "humanOnly" } : {}),
            ...(stretch.model ? { model: stretch.model } : {}),
            stretch_ref: ref, source_event_id: `exp_${ref}`,
            ...(runs.length > 1 ? { supersedes_ref: old } : {}),
            started_at: new Date(stretch.from).toISOString(), utc_offset: stretch.offset, at: new Date(stretch.to).toISOString(),
          };
          entrySource.set(entry, read.vendor);
          entryFile.set(entry, { file: `${read.vendor}:${id}`, from: stretch.from, folder: null });
          entries.push(entry);
        });
        report.days.add(day);
      }
    }
    const days = [...report.days].sort();
    reports.push({ path: read.path, vendor: read.vendor, digest: read.digest, conversations: read.conversations, days: days.length, first: days[0] ?? null, last: days.at(-1) ?? null, oversized: read.oversized }); // no hours (0.10.20): WorkTrust computes them on arrival and the receipt says
  }
  const seen = new Set();
  return { entries: entries.filter((entry) => !seen.has(entry.stretch_ref) && seen.add(entry.stretch_ref)).sort((a, b) => a.at.localeCompare(b.at)), reports };
}

/**
 * A PERSON'S OWN COPY OF AN AI APP'S SESSION FOLDER (owner, 2026-10-10, one rule): a backed-up ~/.claude/projects, ~/.codex/sessions
 * or an Antigravity brain folder, read with the same readers and the same clock as the live folders, never the live folders
 * themselves (a copy of one of them, or one holding them, is refused by name). Each day is named exactly as the live folder
 * would name it (the session file's name and the day), so a stretch the live folders already hold, or an earlier send of the
 * same copy, is skipped: the live folders win. What travels is RECONSTRUCTED: no device key witnessed the copy, and a copy can
 * be edited. The timeline, the tokens, the model and the evidence travel as they do for a live day; WorkTrust computes the
 * reconstructed seconds from the timeline. The title says where the line came from.
 */
function folderEntries(given) {
  const dir = given.replace(/^~(?=\/|$)/, homedir());
  let stat; try { stat = statSync(dir); } catch { throw Error(`no session files: ${given} does not exist`); }
  if (!stat.isDirectory()) throw Error(`no session files: ${given} is not a folder`);
  const here = resolve(dir), live = [claudeRoot(), codexRoot(), ...antigravityRoots(value("antigravity-root"))].filter(Boolean).map((root) => resolve(root));
  if (live.some((root) => here === root || here.startsWith(root + sep) || root.startsWith(here + sep))) throw Error(`${given} is an AI app's own session folder on this computer, or holds one: the hook measures those itself; a copy lives elsewhere`);
  const files = [];
  const walk = (at, depth) => {
    if (depth > 12) return;
    let names = []; try { names = readdirSync(at, { withFileTypes: true }); } catch { return; }
    for (const entry of names.sort((a, b) => a.name.localeCompare(b.name))) {
      const path = join(at, entry.name);
      if (entry.isDirectory()) { if (entry.name !== "subagents" && !excluded(entry.name)) walk(path, depth + 1); }
      else if (entry.name.endsWith(".jsonl")) files.push(path);
    }
  };
  walk(here, 0);
  if (files.length === 0) throw Error(`no session files under ${given} (Claude Code transcripts, Codex rollouts or Antigravity transcripts, as .jsonl)`);
  const present = new Set(historyEntries(null, true).map((entry) => entry.stretch_ref)), seen = new Set();
  const entries = [], report = { stretches: 0, skipped: 0, days: new Set() };
  for (const file of files) {
    const client = CODEX_ROLLOUT.test(file) ? "codex" : ANTIGRAVITY_TRANSCRIPT.test(file) ? "antigravity" : "claude";
    const lines = parsedLines(file);
    if (!lines) continue;
    let cwd = null;
    const read = [];
    for (const line of lines) {
      if (typeof line.cwd === "string") cwd = line.cwd;
      if (!line.timestamp || (line.type !== "user" && line.type !== "assistant")) continue;
      const at = Date.parse(line.timestamp);
      if (Number.isFinite(at)) read.push(messageOf(line, at));
    }
    read.sort((a, b) => a.at - b.at);
    for (const [day, messages] of byDayOf(read)) {
      if (messages.length === 0) continue;
      const ref = stretchRef(file, day);
      report.stretches += 1;
      if (present.has(ref) || seen.has(ref)) { report.skipped += 1; continue; }
      seen.add(ref);
      const rest = payloadFor({ ...measure(cwd, messages), ref, steered: null, agents: null });
      const entry = { ...rest, title: rest.layer ? `AI-assisted work from a copied session folder · ${rest.layer}` : "AI-assisted work from a copied session folder", ...(rest.timeline ? { duration_basis: "reconstructed" } : {}) };
      if (client !== "claude") entrySource.set(entry, client);
      entryFile.set(entry, { file, from: firstOf(messages), folder: null });
      report.days.add(day); entries.push(entry);
    }
  }
  const days = [...report.days].sort();
  return { entries: entries.sort((a, b) => a.at.localeCompare(b.at)), report: { stretches: report.stretches, skipped: report.skipped, days: days.length, first: days[0] ?? null, last: days.at(-1) ?? null } };
}

/** Every transcript this machine holds, excluded projects skipped before a file is opened. */
function* allTranscripts() {
  const root = claudeRoot();
  if (existsSync(root)) for (const dir of readdirSync(root)) {
    if (excluded(dir)) continue;
    let files;
    try { files = readdirSync(join(root, dir)); } catch { continue; }
    for (const file of files) if (file.endsWith(".jsonl")) yield { id: file.replace(/\.jsonl$/, ""), file: join(root, dir, file) };
  }
  yield* codexRollouts();
}

/**
 * EVERY TRANSCRIPT, with what it was last written. The two filters that used to live here decided
 * the wrong thing at the wrong level:
 *
 * - "idle 30 minutes" skipped the file being typed into, and with it every earlier day of a
 *   session that has been open for a fortnight. Whether a DAY is finished is a fact about the day.
 * - "not older than 48 hours" skipped the machine that was closed for four months, which is
 *   exactly the person whose work needs collecting when they come back.
 *
 * The caller opens a file only when it has been written since the watermark says we last read it,
 * so a sweep over a hundred transcripts costs a hundred `stat` calls and nothing more.
 */
function* candidates() {
  for (const rollout of codexRollouts()) {
    if (rollout.writtenAt) { yield rollout; continue; } // a database session knows its own last moment
    let stat; try { stat = statSync(rollout.file); } catch { continue; }
    yield { ...rollout, writtenAt: stat.mtimeMs };
  }
  const root = claudeRoot();
  if (!existsSync(root)) return;
  for (const dir of readdirSync(root)) {
    if (excluded(dir)) continue;
    const path = join(root, dir);
    let files;
    try { files = readdirSync(path); } catch { continue; }
    for (const file of files) {
      if (!file.endsWith(".jsonl")) continue;
      const full = join(path, file);
      let stat;
      try { stat = statSync(full); } catch { continue; }
      yield { id: file.replace(/\.jsonl$/, ""), file: full, writtenAt: stat.mtimeMs };
    }
  }
}

function hookInput() {
  // Only when something was piped in. Reading fd 0 on a terminal waits for an EOF that never
  // comes, and a hook that hangs is worse than one that does nothing. A dry run READS it, so the
  // hook path is the one a person can rehearse: `echo '<the hook JSON>' | node log-session.mjs
  // --dry-run` shows exactly what that session would send.
  // Antigravity's Stop hook hands its JSON over in the environment (worktrust.mjs hook --antigravity-stop).
  if (process.stdin.isTTY && !process.env.WORKTRUST_HOOK_INPUT) return null;
  try {
    const raw = process.env.WORKTRUST_HOOK_INPUT ?? readFileSync(0, "utf8");
    return raw.trim() ? JSON.parse(raw) : null;
  } catch { return null; }
}

if (flag("uninstall")) {
  // THE WAY OUT IS THE SAME SIZE AS THE WAY IN. A hook that can only be installed is a hook
  // somebody has to reverse-engineer out of a settings file, and it keeps sending in the
  // meantime. This removes the wiring; --purge also removes the copies and the state.
  const file = join(homedir(), ".claude", "settings.json");
  const settings = existsSync(file) ? JSON.parse(readFileSync(file, "utf8")) : {};
  const before = JSON.stringify(HOOK_EVENTS.map((event) => settings.hooks?.[event] ?? []));
  for (const event of HOOK_EVENTS) {
    if (!settings.hooks?.[event]) continue;
    settings.hooks[event] = settings.hooks[event]
      .map((entry) => ({ ...entry, hooks: (entry?.hooks ?? []).filter((item) => !ours(item?.command)) }))
      .filter((entry) => (entry.hooks ?? []).length > 0);
    if (settings.hooks[event].length === 0) delete settings.hooks[event];
  }
  const removed = before !== JSON.stringify(HOOK_EVENTS.map((event) => settings.hooks?.[event] ?? []));
  if (removed) writeFileSync(file, JSON.stringify(settings, null, 2));
  if (flag("purge")) for (const path of [join(homedir(), ".worktrust", "count-behaviour.mjs"), PINNED, join(homedir(), ".worktrust", "log-session.mjs"), STATE, ...READER_FILES.map((name) => join(homedir(), ".worktrust", name)), join(homedir(), ".worktrust", "antigravity.json")]) { try { rmSync(path); } catch { /* already gone */ } }
  console.log(`${removed ? "removed" : "nothing wired"}: ${file}${flag("purge") ? "\n         purged ~/.worktrust" : ""}`);
  console.log("the coupling itself still exists: end it in the app (Sources → the computer's row → end this coupling)");
  return await exitFlushed(0);
}

if (flag("install")) {
  // `--from-now` (every new coupling) and `--history-floor now` (a coupling to another account): see THE FLOORS.
  if (flag("from-now") || value("history-floor") === "now") {
    const floors = readState();
    const now = new Date().toISOString();
    if (flag("from-now")) floors.__from = now;
    if (value("history-floor") === "now") floors.__historyFloor = now;
    writeState(floors);
  }
  // Only complete, verified releases may be installed. Old loose scripts are never copied or fetched.
  const home = join(RELEASE_DIR, "log-session.mjs");
  let via = value("via");
  if (!via) {
    const { installSignedPackage } = await import("./package-integrity.mjs");
    via = installSignedPackage(RELEASE_DIR, join(homedir(), ".worktrust"));
  }
  const file = join(homedir(), ".claude", "settings.json");
  const settings = existsSync(file) ? JSON.parse(readFileSync(file, "utf8")) : {};
  const direct = flag("direct");
  const command = `"${process.env.WORKTRUST_NODE || process.execPath}"${process.env.WORKTRUST_NODE_ARGS === '["-I"]' ? " -I" : ""} "${via}"${direct ? " --internal-module log-session.mjs" : " hook"}`;
  settings.hooks ??= {};
  for (const event of HOOK_EVENTS) settings.hooks[event] ??= [];
  // A WIRING THAT POINTS SOMEWHERE ELSE IS REPAIRED, NOT LEFT. An earlier install wired whatever
  // path `curl -O` had left the file at — a repository working tree, in the first real install —
  // and answering "already installed" to the run that would have fixed it leaves the person
  // certain it is right. So an entry that names this hook and a different path is rewritten.
  let repaired = null;
  const wired = new Set();
  for (const event of HOOK_EVENTS) {
    for (const entry of settings.hooks[event]) {
      for (const item of entry?.hooks ?? []) {
        if (typeof item?.command !== "string" || !ours(item.command)) continue;
        if (item.command === command) { wired.add(event); continue; }
        repaired = item.command;
        item.command = command;
        wired.add(event);
      }
    }
  }
  // An earlier install wired SessionEnd alone. Adding the two that were missing is a repair, not a
  // second installation, and saying "already installed" to the run that would have added them is
  // how a person ends up certain that a thing works which does not.
  const added = HOOK_EVENTS.filter((event) => !wired.has(event));
  const already = added.length === 0;
  if (already && !repaired) { console.log(`already installed — nothing changed (${command})`); return await exitFlushed(0); }
  for (const event of added) settings.hooks[event].push({ hooks: [{ type: "command", command }] });
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, JSON.stringify(settings, null, 2));
  console.log(repaired
    ? `repaired: ${file} pointed at ${repaired}\n          it now runs ${command}`
    : `installed: ${home}\n           ${file} → ${HOOK_EVENTS.join(", ")} run it\n           the file you downloaded may be deleted; this copy is the one that runs`);
  // Codex has no settings.json to wire; its notify hook is one line in config.toml, which this script
  // never rewrites: `npx worktrust` asks and writes it (WORKTRUST_CODEX_OFFER, so no hint twice), and
  // without it Codex rollouts are still swept whenever the Claude Code hook runs.
  if (existsSync(join(homedir(), ".codex")) && !process.env.WORKTRUST_CODEX_OFFER) console.log(`codex:      to have Codex wake this hook too, add to ~/.codex/config.toml:\n            notify = ${via ? `["${process.env.WORKTRUST_NODE || process.execPath}", "${via}", "hook", "--codex-notify"]` : `["node", "${home}", "--codex-notify"]`}\n            (its rollouts are swept on every run either way)`);
  return await exitFlushed(0);
}

const door = coupling();
/**
 * A CODEX STRETCH GOES THROUGH CODEX'S OWN COUPLING. Both clients hold a token to the same door,
 * and the record files a stretch under the coupling that sent it: a Codex thread sent with Claude
 * Code's token would read as Claude Code work. Where only one of the two is coupled, that one
 * carries both, and the model on every stretch still says which it was.
 */
const codexDoor = codexCoupling();
const doorFor = (entry) => (String(entry?.id ?? "").startsWith("codex:") ? codexDoor ?? door : door);
const entrySource = new WeakMap(); // an entry → "codex" or "antigravity" by the client that wrote it; the sends route and name by it
const entryFile = new WeakMap(); // a history entry → its transcript (`--summary` counts sessions), first moment and folder name (`--archive-lines`)
// THE LOCAL ARCHIVE (`npx worktrust preserve --archive`, 2026-10-06): every measured day, live window and floors aside, as JSON lines to preserve.mjs on this computer, which keeps metadata only; nothing is sent.
// WHAT THIS COMPUTER MEASURES (0.8.3, for `npx worktrust status`): the last thirty days of its own sessions, summed from
// the same derived record the hook sends, counts only; reads, prints and exits, nothing sent.
if (flag("evidence-summary")) {
  const since = Date.now() - 30 * 86400_000, rows = historyEntries(null, true).filter((entry) => Date.parse(entry.at) >= since);
  const sum = (pick) => rows.reduce((total, entry) => total + (pick(DERIVED.get(entry) ?? {}) ?? 0), 0);
  const complexity = {};
  for (const entry of rows) { const tier = DERIVED.get(entry)?.complexity?.class; if (tier) complexity[tier] = (complexity[tier] ?? 0) + 1; }
  const summary = {
    stretches: rows.length, // the hours are WorkTrust's (0.10.20): the app shows them
    delivered: sum((d) => (d.delivery ? 1 : 0)), verified_first: sum((d) => (d.delivery?.verified_first ? 1 : 0)),
    failures: sum((d) => d.recovery?.failures), recovered: sum((d) => d.recovery?.recovered), blind_retries: sum((d) => d.recovery?.blind_retries),
    steers: sum((d) => d.steering?.moments), effective_steers: sum((d) => d.steering?.effective),
    refused: sum((d) => (d.oversight ? d.oversight.refused + d.oversight.plans_rejected : 0)), guard_denied: sum((d) => d.oversight?.guard_denied),
    planned: sum((d) => (d.planning ? 1 : 0)), files: sum((d) => d.changes?.files), test_files: sum((d) => d.changes?.test_files), complexity,
  };
  process.stdout.write(`${JSON.stringify(summary)}\n`);
  return await exitFlushed(0);
}
if (flag("archive-lines")) { const lines = historyEntries(null, true).map((entry) => JSON.stringify({ ...entry, ...(DERIVED.get(entry) ?? {}), client: entrySource.get(entry) ?? "claude", started_at: new Date(entryFile.get(entry).from).toISOString(), folder: entryFile.get(entry).folder })); process.stdout.write(`${[...lines, JSON.stringify({ archive_end: lines.length })].join("\n")}\n`); return await exitFlushed(0); } // one write and a count, so the reader tells a whole answer from a cut one
// THE EXPORTS IN A FOLDER (0.10.10, for the bare `npx worktrust`): which lie there, by vendor and digest, and which this computer
// already sent or was asked about; reads, prints one JSON line, sends nothing. `--export-offered <digest>` records a No.
if (flag("find-exports")) { const named = value("find-exports"), state = readExportsState(); const found = (findExports ? await findExports(named && !named.startsWith("--") ? named : undefined) : []).map((one) => ({ ...one, sent: state[one.digest]?.sent === true, offered: Boolean(state[one.digest]) })); process.stdout.write(`${JSON.stringify(found)}\n`); return await exitFlushed(0); }
if (value("export-offered")) { rememberExport(value("export-offered"), { offered: new Date().toISOString() }); return await exitFlushed(0); }
if (!door && !codexDoor && !DRY) { return await exitFlushed(0); } // Not coupled on this machine: nothing to do, quietly.

/**
 * HISTORY FROM THE ARCHIVE (0.8.0; framework §22). When an AI app has deleted its sessions, the stretches this computer
 * archived (`preserve --archive`) can still be filed, marked `from_archive`. Five conditions, each refused by name: a
 * device key (only lines this computer signed travel), an archive that verifies, a stretch whose session is gone from
 * this computer (one still here goes through the ordinary history), a door that knows the mark, and the person asking.
 */
if (flag("history") && flag("resume")) {
  const { resumeHistory } = await import("./history-outbox.mjs");
  const totals = { received: 0, review: 0, waiting: 0, batches: 0 };
  try {
    for (const target of [door, ...(codexDoor && codexDoor.token !== door?.token ? [codexDoor] : [])].filter(Boolean)) {
      const result = await resumeHistory(target, { dry: DRY, retryReview: flag("retry-review"), confirmed: confirmedReceipt, note: noteReceipt,
        send: (body, source) => fetch(target.url, { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream", authorization: `Bearer ${target.token}`, ...clientOf(source, true), ...proofFor(target.url, body) }, body, redirect: "error", signal: AbortSignal.timeout(65_000) }),
      });
      for (const key of Object.keys(totals)) totals[key] += result[key];
    }
    console.log(JSON.stringify({ resumed: totals.received, ...totals, ...RECEIPTS }));
    return await exitFlushed(DRY || (!totals.waiting && !totals.review) ? 0 : 1);
  } catch { console.log("Pending history could not be read safely. Nothing was marked complete; keep the local WorkTrust folder for recovery."); return await exitFlushed(1); }
}

if (flag("history") && flag("from-archive")) {
  const named = value("from-archive"), dir = named && !named.startsWith("--") ? named.replace(/^~(?=\/|$)/, homedir()) : join(homedir(), "AI-Evidence");
  const say = (text) => console.log(text);
  const pem = process.env.WORKTRUST_DEVICE_KEY;
  // ONE RULE (owner, 2026-10-10): VERIFIED is what this computer's coupled key witnessed. A day the device key signed goes as it was
  // measured; a day unsigned, signed by the local archive key, or by another computer's key goes too, as RECONSTRUCTED, inside the
  // database's ceiling for an unmeasured stretch. No device key is no longer a refusal: it means every day is reconstructed. The
  // archive must still verify whole, and only stretches no longer in any AI app here travel.
  let ownKey = null;
  try { ownKey = pem ? createPublicKey(createPrivateKey(pem)).export({ format: "jwk" }).x : null; } catch { ownKey = null; }
  const verified = spawnSync(moduleExecutable(RELEASE_DIR), [...moduleArgs(RELEASE_DIR, "preserve.mjs", ["--verify", dir])], { encoding: "utf8" });
  if (verified.status !== 0) { say(`The archive in ${dir} does not verify, so nothing was sent: ${(verified.stdout || verified.stderr || "").trim().split("\n").pop()}`); return await exitFlushed(1); }
  const { archiveEntries = null } = (await import("./preserve-lines.mjs").catch(() => null)) ?? {};
  if (!archiveEntries) { say("preserve-lines.mjs is not beside this file. Nothing was sent."); return await exitFlushed(1); }
  const present = new Set(historyEntries(null, true).map((entry) => entry.stretch_ref));
  const all = archiveEntries(dir, ownKey), gone = all.filter(({ entry }) => !present.has(entry.stretch_ref));
  const entries = gone.map(({ entry, client, signed }) => {
    if (client !== "claude") entrySource.set(entry, client);
    if (!signed && (typeof entry.seconds === "number" || typeof entry.timeline === "string")) entry.duration_basis = "reconstructed"; // the door keeps an unmeasured stretch inside its own ceiling
    return entry;
  });
  const signedCount = all.filter(({ signed }) => signed).length;
  say(`${all.length} stretches in the archive · ${signedCount} signed by this computer's key (signature checked) · ${all.length - signedCount} unsigned or signed by another key (reconstructed) · ${entries.length} of them no longer in any AI app here`);
  if (DRY || entries.length === 0) { if (entries[0]) say(`\nthe oldest of them, in full:\n${JSON.stringify(entries[0], null, 1)}`); say(entries.length === 0 ? "Nothing to send." : "\ndry run — nothing sent."); return await exitFlushed(0); }
  if (!(await doorKnowsArchive(door))) { say("WorkTrust does not accept history from an archive yet (the door does not know the mark). Nothing was sent."); return await exitFlushed(1); }
  return await exitFlushed((await sendHistory(door, entries, true)) === entries.length ? 0 : 1);
}

if (flag("history")) {
  const historyFloor = floorOf(readState(), "__historyFloor");
  // AN EXPORT IS ITS OWN HISTORY (0.10.10): its lines alone, reconstructed, and never a rebuild (a rebuild replaces this computer's own measured days).
  let fromExports = null, fromFolder = null;
  if (EXPORT_PATHS.length > 0) { try { fromExports = await exportEntries(); } catch (error) { console.log(`export: ${error.message}`); return await exitFlushed(1); } }
  // A COPIED SESSION FOLDER (0.10.10): its own history, reconstructed, the live folders' stretches skipped; never a rebuild.
  if (flag("from-folder")) {
    const given = value("from-folder");
    if (!given || given.startsWith("--")) { console.log("folder: --from-folder needs the copied folder's path"); return await exitFlushed(1); }
    try { fromFolder = folderEntries(given); } catch (error) { console.log(`folder: ${error.message}`); return await exitFlushed(1); }
  }
  if ((fromExports || fromFolder) && flag("rebuild")) { console.log("An export or a copied folder is never a rebuild: its hours are reconstructed and replace nothing. Run it without --rebuild."); return await exitFlushed(1); }
  // THE EXPORT REPLACES (owner, 2026-10-10): the door withdraws the product's earlier connector lines on the export's days by itself; the AI-app
  // lines under no product go only with `--withdraw-unknown`, which the command sends after the person's yes, with an export alone.
  if (flag("withdraw-unknown") && !fromExports) { console.log("--withdraw-unknown goes with --export alone: it withdraws, on the days an export covers, the earlier lines an AI app reported under no product."); return await exitFlushed(1); }
  const entries = fromExports ? fromExports.entries : fromFolder ? fromFolder.entries : historyEntries(historyFloor);
  const months = [...new Set(entries.map((entry) => entry.at.slice(0, 7)))].sort();
  // ONE LINE FOR `npx worktrust` TO ASK WITH (2026-10-03): sessions, days, first and last month; per client its days (the rebuild's plan,
  // 2026-10-07); nothing sent. NO HOURS (0.10.20): the hours are WorkTrust's to compute; the receipt after the send carries them.
  const clients = [...entries.reduce((map, entry) => { const client = entrySource.get(entry) ?? "claude", row = map.get(client) ?? { client, days: new Set() }; row.days.add(entry.at.slice(0, 10)); return map.set(client, row); }, new Map()).values()].map((row) => ({ client: row.client, days: row.days.size, first: [...row.days].sort()[0], last: [...row.days].sort().at(-1) }));
  if (flag("summary")) { console.log(JSON.stringify({ sessions: new Set(entries.map((entry) => entryFile.get(entry).file)).size, days: new Set(entries.map((entry) => entry.at.slice(0, 10))).size, first: months[0] ?? null, last: months.at(-1) ?? null, ...(fromExports ? { exports: fromExports.reports } : {}), ...(fromFolder ? { folder: fromFolder.report } : {}), clients })); return await exitFlushed(0); }
  console.log(`${entries.length} day-stretches · ${fromExports || fromFolder ? "reconstructed" : "measured"} by WorkTrust on arrival · ${months.join(", ")}${flag("rebuild") ? " · rebuild: this computer's earlier lines for these days and clients are replaced at the door" : ""}`);
  if (DRY) {
    // One example in full: the shape is the argument for trusting it, and a summary hides it.
    if (entries[0]) console.log(`\nthe oldest of them, in full:\n${JSON.stringify(entries[0], null, 1)}`);
    console.log(`\ndry run — nothing sent. Add --history${flag("rebuild") ? " --rebuild" : ""} without --dry-run to ${flag("rebuild") ? "rebuild" : "import"} them.`);
    return await exitFlushed(0);
  }
  // A batch the door refused is a failure the caller must see, not a quiet zero.
  const accepted = await sendHistory(door, entries, true, flag("rebuild"), Boolean(fromFolder), fromExports ? { byDay: true, withdrawUnknown: flag("withdraw-unknown") } : {});
  // An export that arrived whole is remembered by its digest (never by a conversation), so the bare command offers it no more.
  if (fromExports && accepted === entries.length) for (const report of fromExports.reports) rememberExport(report.digest, { vendor: report.vendor, sent: true, at: new Date().toISOString(), conversations: report.conversations });
  // ONE LINE FOR THE COMMAND TO ASK WITH (2026-10-10): what the door replaced, how many AI-app lines lie on the export's days, how many it withdrew.
  if (fromExports) console.log(JSON.stringify({ export_sent: accepted, of: entries.length, ...RECEIPTS })); else console.log(JSON.stringify({ history_sent: accepted, of: entries.length, ...RECEIPTS, delivery: HISTORY_DELIVERY })); // the same line for a history send: what the door did with it, and WorkTrust's measuredSeconds for what it stored
  return await exitFlushed(accepted === entries.length ? 0 : 1);
}

const input = hookInput();
const state = readState();
const work = [];
if (input?.transcript_path && existsSync(input.transcript_path) && !excluded(input.transcript_path)) {
  work.push({ id: String(input.session_id ?? input.transcript_path), file: input.transcript_path });
}
// ANTIGRAVITY'S STOP (camelCase, antigravity.google/docs/hooks/): its model and folder are kept for the sweep; no text is in it.
if (typeof input?.transcriptPath === "string" && ANTIGRAVITY_TRANSCRIPT.test(input.transcriptPath) && existsSync(input.transcriptPath)) {
  const id = rememberAntigravity(input);
  const { cwd } = id ? antigravityContext(id) : {};
  if (id && !(cwd && excluded(cwd))) work.push({ id: `antigravity:${id}`, file: input.transcriptPath });
}
// A session that ended with the terminal closed fires no hook, so every run also sweeps the
// transcripts that have gone quiet and were never logged. Self-healing, and it can only ever
// report a stretch it can measure.
for (const found of candidates()) if (!work.some((entry) => entry.file === found.file)) work.push(found);

// A computer coupled by an older CLI has no `__from`: it is set to the first watermark this computer
// ever wrote (when it first sent), or to now on a computer that has sent nothing, and kept.
if (floorOf(state, "__from") === null) {
  const marks = Object.entries(state).filter(([key, entry]) => !key.startsWith("__") && entry?.through).map(([, entry]) => Date.parse(entry.through)).filter(Number.isFinite);
  state.__from = new Date(marks.length > 0 ? Math.min(...marks) : Date.now()).toISOString();
  if (!DRY) writeState(state);
}
const floor = floorOf(state, "__from");
let sent = 0, filed = 0;
const late = []; // measured days the live door will no longer take: they are not dropped, they are filed
const heldBack = new Map(); // per transcript with a late day: its state before that day, put back unless history took every late day
for (const entry of work) {
  const mark = state[entry.id]?.through ? Date.parse(state[entry.id].through) : null;
  // Never before the coupling (THE FLOORS): a transcript with no watermark starts at `__from`, not at its first line.
  const since = mark !== null && floor !== null ? Math.max(mark, floor) : mark ?? floor;
  // Nothing written since we last read this one: it is not opened. This keeps a sweep over every transcript to one `stat` each.
  if (since !== null && entry.writtenAt && entry.writtenAt <= since) continue;
  const stretches = stretchesOf(entry.file, since);
  // THE WATERMARK ADVANCES OVER WHAT WAS ACCEPTED, AND STOPS AT THE FIRST REFUSAL. A door that is
  // down must never cost the person a day, so the loop breaks rather than skipping ahead.
  let through = null, before, reported = state[entry.id]?.reported;
  for (const stretch of stretches) {
    // The day still being worked in is not finished. A fortnight-long session therefore reports
    // every day but today, on whichever run comes first — it no longer waits for its own end.
    if (Date.now() - stretch.to < IDLE_BEFORE_SWEEP) break;
    const total = grownBy(stretch, reported);
    const payload = payloadFor(stretch);
    const source = LIVE_SOURCE.exec(String(entry.id))?.[1];
    if (source) entrySource.set(payload, source);
    if (DRY) { console.log(JSON.stringify({ ...payload, client: source ?? "claude", route: Date.now() - stretch.to > WINDOW_HOURS * 3600_000 ? "history" : "log_work" }, null, 1)); through = stretch.to; reported = total; continue; }
    // MEASURED TIME IS NEVER DROPPED. The live door refuses anything older than two days, which is right, and used to mean a machine closed
    // for a fortnight lost the fortnight. The same numbers go through the history door instead, standing as history stands. Late is not untrue.
    if (Date.now() - stretch.to > WINDOW_HOURS * 3600_000) { before ??= { mark: through === null ? state[entry.id] : { ...state[entry.id], through: new Date(through).toISOString() } }; late.push(payload); through = stretch.to; reported = total; continue; }
    try { await send(doorFor(entry), payload); through = stretch.to; reported = total; sent += 1; } catch (error) {
      if (process.env.WORKTRUST_HOOK_DEBUG) console.error(`worktrust: ${error.message}`);
      break;
    }
  }
  if (before && !heldBack.has(entry.id)) heldBack.set(entry.id, before.mark);
  if (through !== null) state[entry.id] = { through: new Date(through).toISOString(), ...(reported ? { reported } : {}) };
}
// The history door, in batches of two hundred as `--history` sends them. A resend FILLS a line that was missing something, never a twin.
if (!DRY && late.length > 0) {
  try { filed = await sendHistory(door, late); } catch (error) { if (process.env.WORKTRUST_HOOK_DEBUG) console.error(`worktrust: ${error.message}`); }
  // A LATE DAY THE HISTORY DOOR REFUSED IS NOT PASSED: its transcript's mark goes back to before it, so the next run sends it again.
  if (filed < late.length) for (const [id, mark] of heldBack) { if (mark) state[id] = mark; else delete state[id]; }
}
if (!DRY && (sent > 0 || filed > 0)) writeState(state);

// The counter, at most once a day, detached: reading every transcript takes longer than a hook
// may hold a session's exit, and its result waits for a click either way. `--stage` and never
// `--send`: staging is idempotent on the reading's own digest, so a day that changed nothing
// leaves nothing behind.
if (!DRY && existsSync(COUNTER)) {
  const last = state.__counter?.at ? Date.parse(state.__counter.at) : 0;
  if (Date.now() - last > COUNTER_EVERY_MS) {
    try {
      const child = spawn(moduleExecutable(RELEASE_DIR), moduleArgs(RELEASE_DIR, "count-behaviour.mjs", ["--stage"]), { detached: true, stdio: ["ignore", "ignore", "inherit"] });
      child.unref();
      state.__counter = { at: new Date().toISOString() };
      writeState(state);
    } catch { /* the counter is a bonus; a hook that fails on it would cost the stretch it just logged */ }
  }
}
return await exitFlushed(0);

}
await main();
