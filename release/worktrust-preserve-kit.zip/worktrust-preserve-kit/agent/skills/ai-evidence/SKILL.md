---
name: ai-evidence
description: Explain how the person can preserve and audit their local AI-evidence archive, and interpret the CLI output they provide. Never runs person-only WorkTrust commands or invents measurements.
---

# AI evidence kept locally

Help the person preserve a portable metadata record of their AI-assisted work. Read this package's
AGENTS.md and the CLI's AGENTS.md where available. `worktrust preserve` runs locally without a
WorkTrust account, but package installation and `npx` can use the network.

## Rules

1. Never invent a number. Hours, tokens, sessions and dates must come from the person's supplied
   CLI output. Say "not measured" where a field is absent.
2. Never read private session stores or quote prompts, answers, code, paths or commit messages.
   The client can read transcript contents locally to derive counts; that does not authorize the
   agent to read those transcripts.
3. Never execute person-only CLI commands, including `preserve`, bare `worktrust`, `connect`,
   `history` or imports. Explain commands for the person to run in their own terminal; do not unset
   agent environment variables or call internal modules to bypass the guard.
4. Explain writes before recommending them. Bare `preserve` is interactive and may update settings
   or an archive. It is not a read-only inspection command.

## Workflow

1. Explain the required CLI version/runtime from the installed package documentation. If needed,
   show `npx worktrust@latest preserve` as a command the person can run, noting the npm download.
2. Explain retention and archive choices. The person runs `worktrust preserve` themselves and
   decides whether to apply settings or archive. Describe `--apply` and `--archive` only as needed.
3. For an existing archive, the person runs `worktrust preserve --verify` and
   `worktrust preserve --summary`. Interpret the relevant non-sensitive output they choose to share.
   If integrity is broken, report that result before drawing conclusions from the archive.
4. Separate measured figures, reconstructed history and independent corroboration. Local signing
   establishes continuity, not third-party verification of work.

The kit registers no background hooks. The person updates the archive manually in their terminal;
do not promise automatic archiving. Bypassing agent detection is not an acceptable shortcut.

## Interpretation

Describe the period and coverage beside each figure. Cache share and model use may suggest things
for the person to investigate; they do not by themselves prove wasted tokens or a person's skill.
A team considering collection of daily roots must agree what it collects and why. Do not collect or
send another person's archive as part of this skill.
