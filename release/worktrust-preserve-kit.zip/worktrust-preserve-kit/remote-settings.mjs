/**
 * WHAT A PHONE MAY DO ON THIS COMPUTER, CHANGED IN ONE PLACE (CLI 0.11.7, owner 2026-11-12). Every change to the remote
 * settings that widens or narrows a phone's reach (the ceiling of agent modes, the roots, the granted projects, the admin
 * switch) goes through applySettingsChange(change, source). Today the only source is THIS KEYBOARD (`{ kind: "keyboard" }`,
 * a `remote …` command or the menu, both refused in an AI agent's shell by worktrust.mjs). Part B adds a second source, a
 * change the person approved in the WorkTrust app or on the web and the server signed (`{ kind: "admin", proof }`); it will
 * be honoured only while `remote admin on` (the default) and only once its proof verifies here. Until part B ships, an
 * admin change is refused: nothing but this keyboard changes these settings (docs/remote-agents/PROTOCOL.md "Agent modes").
 *
 * PART B (owner, 2026-11-12): the second source is here. A change from the app or the web arrives as `{ kind: "admin",
 * proof, issuerKeys, claims, now }` (remote-daemon.mjs, from a sealed device.configure): remote-admin.mjs adminRefusal
 * checks `remote admin on` and the issuer-signed proof (this computer, this account, this change, five minutes, one use),
 * resolveAdminChange names its folder, root or connection from this computer's own lists by id, and the result goes
 * through the same rules below as a typed command. The admin switch itself never changes from the app.
 *
 * THE CEILING OF AGENT MODES (protocol adapters.ts AGENT_MODES). Manual and plan are always allowed (today's behaviour);
 * `allow edit` lets a phone start a session that edits files inside its projects without asking; `allow auto` lets it start
 * the agent's own automatic mode, and, being above edit, allows edit too. `deny edit` takes both away again. The ceiling is
 * read by the daemon on every start (checkAgentOptions), never taken from a phone.
 */
import { readdirSync } from "node:fs";
import { basename } from "node:path";
import { adminRefusal, resolveAdminChange } from "./remote-admin.mjs";
import { removePhones } from "./remote-connections.mjs";
import { protectedFolder } from "./folder-picker.mjs"; import { FOLDER_IDS } from "./remote-setup.mjs";
import { canonicalProject } from "./remote-policy.mjs";
import { probeFolders } from "./remote-service.mjs";
import { checkRoot, MAX_ROOTS, rootIdOf } from "./remote-projects.mjs";
import { agentOptionsOf } from "./remote-inventory.mjs";
import { uninstallSteerMod } from "./remote-steer-mod.mjs"; import { deskSteerLine } from "./remote-desk-steer.mjs";
import * as P from "./remote-protocol.mjs";
import { keyboardYes } from "./remote-keyboard.mjs";
import { deskReadOf, ensureRemoteDir, loadKeys, loadPhones, loadChosen, readJson, saveChosen, loadPreviewGrants, loadProjects, loadRoots, loadSettings, projectIdOf, savePreviewGrants, saveProjects, saveRoots, saveSettings, writeJson } from "./remote-store.mjs";

export const RAISABLE_MODES = Object.freeze(["edit", "auto"]);
const ORDER = ["manual", "edit", "plan", "auto"];

/** The modes this computer allows: manual and plan always, edit and auto when the person allowed them (auto brings edit). */
export function allowedModes(settings = loadSettings()) {
  const set = new Set(["manual", "plan"]);
  const asked = Array.isArray(settings.modes_allowed) ? settings.modes_allowed : [];
  if (asked.includes("auto")) { set.add("auto"); set.add("edit"); }
  if (asked.includes("edit")) set.add("edit");
  return ORDER.filter((m) => set.has(m));
}

const refused = (reason) => ({ ok: false, reason });

/**
 * A START'S 0.11.7 OPTIONS, decided here (remote-sessions.mjs calls it before anything is set up): the adapter's options as
 * this computer reads them from its own agent, the ceiling from the settings file, and the extra projects from the
 * computer's own list by id. → a reject reason, or { agentMode, effort, extraProjectIds, extras: [{ project_id, path }] }.
 */
export function startChoice(payload, projectId, inventory, settings, known) {
  const options = agentOptionsOf(inventory).find((o) => o.adapter === payload.adapter && o.mode === (payload.mode ?? "structured")) ?? null;
  const choice = P.checkAgentOptions(payload, projectId, options, allowedModes(settings), new Set(known.map((p) => p.project_id)));
  if (typeof choice === "string") return choice;
  return { ...choice, extras: choice.extraProjectIds.map((id) => known.find((p) => p.project_id === id)) };
}

/**
 * The one door for a settings change. `change`: { what: "modes", allow|deny: "edit"|"auto" } | { what: "roots", add: dir,
 * git_init } | { what: "roots", remove: id|dir } | { what: "projects", add: dir } | { what: "projects", remove: id|dir } |
 * { what: "admin", on: boolean } | { what: "endorse", on: boolean } | { what: "desk_history", on: boolean } | { what: "desk_live", on: boolean } | { what: "desk_steer", on: boolean } | { what: "voice", on: boolean } (all six this keyboard only) | { what: "connections", remove:
 * fingerprint } (resolved from the app's change only).
 * `source`: { kind: "keyboard" }, or { kind: "admin", proof, issuerKeys, claims, now, via } (part B; its change is
 * crypto/admin.ts's ADMIN_CHANGE_SPEC, resolved by id before it reaches the rules below).
 * → { ok: true, message, paths?, setting? } or { ok: false, reason, code? } (code: the protocol's reject reason).
 */
export function applySettingsChange(change, source) {
  if (source?.kind === "admin") {
    // From the app or the web: `remote admin on`, then the issuer-signed proof, then this computer's own lists by id.
    const gate = adminRefusal(change, source, loadSettings());
    if (gate) return { ok: false, reason: gate.reason, code: gate.code };
    const resolved = resolveAdminChange(change);
    if (!resolved.ok) return { ok: false, reason: resolved.reason, code: resolved.code };
    const done = applyRules(resolved.change, true);
    return done.ok ? { ...done, setting: resolved.setting } : { ...done, code: done.code ?? "unsupported" };
  }
  if (source?.kind !== "keyboard") return refused("this computer's remote settings are changed at its keyboard");
  return applyRules(change, false);
}

/** The rules every change meets, typed here or resolved from the app (`fromApp`): the same checks, the same files. */
function applyRules(change, fromApp) {
  const settings = loadSettings();
  if (change?.what === "modes") {
    const mode = change.allow ?? change.deny;
    if (!RAISABLE_MODES.includes(mode)) return refused("name edit or auto (manual and plan are always allowed)");
    const now = new Set(allowedModes(settings));
    if (change.allow) { now.add(mode); if (mode === "auto") now.add("edit"); }
    else { now.delete(mode); if (mode === "edit") now.delete("auto"); }
    saveSettings({ ...settings, modes_allowed: ORDER.filter((m) => now.has(m)) });
    return { ok: true, message: `Allowed modes: ${allowedModes(loadSettings()).join(", ")}` };
  }
  if (change?.what === "connections" && fromApp) {
    // From the app only (the keyboard's own `remote disconnect` asks twice and calls removePhones itself).
    const n = removePhones([String(change.remove ?? "")]);
    return n > 0 ? { ok: true, message: "Disconnected: it can no longer steer this computer." } : { ...refused("no phone or browser by that fingerprint"), code: "not_found" };
  }
  if (change?.what === "web") {
    // CLI 0.11.26 (owner, 2026-11-25): may a remote session search the web, and may a phone allow a web page; this keyboard only.
    if (fromApp) return refused("the web tools of a remote session change at this keyboard only");
    if (change.search !== undefined && typeof change.search !== "boolean") return refused("web search: on or off");
    if (change.fetch !== undefined && change.fetch !== "ask" && change.fetch !== "off") return refused("web pages: ask or off");
    saveSettings({ ...settings, ...(change.search !== undefined ? { web_search: change.search } : {}), ...(change.fetch !== undefined ? { web_fetch: change.fetch } : {}) });
    return { ok: true, message: change.search !== undefined ? (change.search ? "A remote session may search the web (a read of the public web, shown in its activity)." : "No remote session searches the web.") : change.fetch === "ask" ? "A remote session may open a web page when you allow that page on your phone." : "No remote session opens a web page." };
  }
  if (change?.what === "endorse") {
    // May a phone confirmed here add a browser it scanned (remote-endorse.mjs)? This keyboard only, like the admin switch.
    if (fromApp) return refused("whether phones may add a browser changes at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    saveSettings({ ...settings, allow_endorse: change.on });
    return { ok: true, message: change.on ? "Your confirmed phones may add a browser. Each one is listed here with the phone that added it." : "No phone may add a browser. Browsers already added stay until you remove them." };
  }
  if (change?.what === "desk_history") {
    // May a phone READ a session of this computer's own desk list that it never continued (remote-history.mjs)? This keyboard only.
    if (fromApp) return refused("reading this computer's own sessions changes at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    saveSettings({ ...settings, desk_history: change.on, ...(change.on ? {} : { desk_live: false, desk_steer: false, voice: false }) }); // without the closed turns there is no reading along either, and no steering or voice
    if (!change.on) uninstallSteerMod();
    return { ok: true, message: change.on ? "Your paired phones and browsers may read the sessions you ran at this computer, in the folders you granted. Nothing is stored on a server." : "Sessions you ran at this computer are not readable from a phone or a browser. One you continue from there is its own remote session and stays readable." };
  }
  if (change?.what === "desk_live") {
    // May a phone READ ALONG, live, with a session running at this computer (remote-history-follow.mjs)? This keyboard only. On brings the closed turns with it.
    if (fromApp) return refused("reading along with this computer's own sessions changes at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    saveSettings({ ...settings, desk_history: change.on, desk_live: change.on, ...(change.on ? {} : { desk_steer: false, voice: false }) }); // read along off takes steering (CLI 0.11.20) and voice (0.11.21) with it
    if (!change.on) uninstallSteerMod();
    return { ok: true, message: change.on ? "Your paired phones may read along, live and read-only, with the sessions you run at this computer. This covers EVERY folder you granted and every project inside a root you added, also one added later, from this keyboard or (while `remote admin` is on, the default) approved in the app or on the web. See them: npx worktrust remote projects list · npx worktrust remote roots list. Nothing is stored on a server, and nothing can be sent into a session from there (unless you also turn on npx worktrust remote desk-steer on)." : "Nobody reads along, and sessions you ran at this computer are not readable from a phone or a browser. One you continue from there is its own remote session and stays readable." };
  }
  if (change?.what === "desk_steer") {
    // May a phone SEND a prompt into a session open at this computer (remote-desk-steer.mjs)? This keyboard only, and only on top of read along.
    if (fromApp) return refused("sending into this computer's own sessions changes at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    if (change.on && (settings.desk_live !== true || settings.desk_history !== true)) return refused("steering needs read along on first: npx worktrust remote read-along on, then npx worktrust remote desk-steer on");
    saveSettings({ ...settings, desk_steer: change.on, ...(change.on ? {} : { voice: false }) }); // steering off takes voice with it (CLI 0.11.21)
    return { ok: true, message: change.on ? "Your paired phones (and a browser after its Remote PIN) may send a prompt into a Claude Code session open at this computer, in the folders you granted. It runs with that session's own permission mode and is refused while the session bypasses permissions; questions still appear here. Restart open sessions (or update Claude Code to 2.1.304 or later) so they load the WorkTrust steer mod." : "Nobody can send a prompt into a session open at this computer. The WorkTrust steer mod is removed; sessions that loaded it stop taking prompts at once." };
  }
  if (change?.what === "voice") {
    // May a phone's voice key (Siri, also while the phone is locked) send a prompt into a session open here (remote-voice.mjs)? This keyboard only, on top of steering.
    if (fromApp) return refused("voice prompts change at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    if (change.on && (settings.desk_steer !== true || settings.desk_live !== true || settings.desk_history !== true)) return refused("voice prompts need desk steering on first: npx worktrust remote desk-steer on, then npx worktrust remote voice on");
    // Owner, 2026-11-25: Siri on is ALL of it, reading answers aloud included, unless the person typed `voice read off` here (chosen.json).
    const read = change.on && loadChosen().voice_read !== "off";
    saveSettings({ ...settings, voice: change.on, voice_read: read });
    return { ok: true, message: change.on ? `A phone you confirmed here may enrol a voice key and send a spoken prompt with Siri into the newest open session of a project you granted, also while that phone is locked (only into a session in default or plan mode then). It cannot approve anything or start an agent. Replies read aloud: ${read ? "on, for a phone whose own \"Read answers aloud\" is on (its prompt's reply and the project's last reply, cut at 4,000 characters; off: npx worktrust remote voice read off)" : "off, as you turned it off here (on: npx worktrust remote voice read on)"}. Each phone turns its own voice on with Face ID.` : "No spoken prompt reaches this computer, and no reply is read aloud. Voice keys stay listed until you remove them: npx worktrust remote voice remove" };
  }
  if (change?.what === "voice_read") {
    // May a voice key whose phone turned on "Read answers aloud" hear replies (remote-voice.mjs)? This keyboard only, on top of voice.
    if (fromApp) return refused("reading answers aloud changes at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    if (change.on && settings.voice !== true) return refused("reading answers aloud needs voice prompts on first: npx worktrust remote voice on, then npx worktrust remote voice read on");
    saveSettings({ ...settings, voice_read: change.on });
    return { ok: true, message: change.on ? "A voice key whose phone turned on \"Read answers aloud\" may hear the reply to its own prompt, and the last reply of a project's newest session, read by Siri, also while that phone is locked. Nothing else: no history, no titles, no approvals. Each reply is cut at 4,000 characters." : "No reply is read aloud from this computer." };
  }
  if (change?.what === "admin") {
    if (fromApp) return refused("the admin switch changes at this keyboard only");
    if (typeof change.on !== "boolean") return refused("on or off");
    saveSettings({ ...settings, admin: change.on });
    return { ok: true, message: change.on ? "Managing this computer from the app or the web: on. Each change there asks your authenticator, and this computer checks WorkTrust's signature on it." : "Managing this computer from the app or the web: off. Only this keyboard changes its remote settings." };
  }
  const keys = loadKeys();
  if (change?.what === "roots") {
    const list = loadRoots();
    if (change.add !== undefined) {
      if (!keys) return refused("this computer is not paired for remote yet: run `npx worktrust remote app`");
      const root = checkRoot(change.add ?? "");
      if (!root.ok) return refused(`not added: ${root.reason}`);
      if (list.length >= MAX_ROOTS && !list.some((r) => r.path === root.path)) return refused(`at most ${MAX_ROOTS} roots`);
      const root_id = rootIdOf(keys.projectSecret, root.path);
      saveRoots([...list.filter((r) => r.root_id !== root_id), { root_id, path: root.path, git_init: change.git_init === true, added_at: Date.now() }]);
      return { ok: true, paths: [root.path], message: `Root: ${root.path}. A phone may open the projects already in it and create one new, empty folder in it per request${change.git_init === true ? ", with git init" : ""}.` };
    }
    const key = String(change.remove ?? "");
    const kept = list.filter((r) => r.root_id !== key && r.path !== key && r.path !== checkRoot(key).path);
    if (kept.length === list.length) return refused("no root by that path or id");
    saveRoots(kept);
    return { ok: true, message: "Removed. Projects made in it stay granted: npx worktrust remote projects remove <folder>." };
  }
  if (change?.what === "projects") {
    const list = loadProjects();
    if (change.add !== undefined) {
      if (!keys) return refused("this computer is not paired for remote yet: run `npx worktrust remote app`");
      const canonical = canonicalProject(change.add ?? "");
      if (!canonical.ok) return refused(`not granted: ${canonical.reason}`);
      const project_id = projectIdOf(keys.projectSecret, canonical.path);
      if (!list.some((p) => p.project_id === project_id)) saveProjects([...list, { project_id, path: canonical.path, added_at: Date.now() }]);
      return { ok: true, paths: [canonical.path], message: `Granted: ${canonical.path}` };
    }
    const key = String(change.remove ?? "");
    const canonical = canonicalProject(key);
    const kept = list.filter((p) => p.project_id !== key && p.path !== key && !(canonical.ok && p.path === canonical.path));
    if (kept.length === list.length) return refused("no granted folder by that path or id");
    saveProjects(kept);
    // Its preview grants go with it: a grant left behind would stand again the day the folder is granted or reached anew.
    const grants = loadPreviewGrants(), gone = list.filter((p) => !kept.includes(p)).map((p) => p.project_id);
    if (gone.some((id) => id in grants)) savePreviewGrants(Object.fromEntries(Object.entries(grants).filter(([id]) => !gone.includes(id))));
    return { ok: true, message: "Removed." };
  }
  return refused("not a setting this computer knows");
}

/** `remote modes allow|deny edit|auto | status`. */
export function modesCommand(io, rest) {
  if (rest[0] === "allow" || rest[0] === "deny") {
    const done = applySettingsChange({ what: "modes", [rest[0]]: rest[1] }, { kind: "keyboard" });
    if (!done.ok) io.fail(`npx worktrust remote modes allow|deny edit|auto: ${done.reason}`);
    io.say(`  ✓ ${done.message}`);
    if (rest[0] === "allow") io.say("    A phone may now start sessions in it; the deny rules (no push, no install, no deploy, no secret) hold in every mode.");
    return;
  }
  if (rest[0] !== undefined && rest[0] !== "status") io.fail("npx worktrust remote modes allow|deny edit|auto | status");
  const allowed = allowedModes();
  const WORDS = { manual: "Manual (asks for every change)", edit: "Edit automatically (edits inside the project without asking)", plan: "Plan (read-only)", auto: "Auto (the agent's own automatic mode)" };
  io.say("  Agent modes a phone may start on this computer:");
  for (const m of ORDER) io.say(`    ${allowed.includes(m) ? "✓" : "·"} ${WORDS[m]}${allowed.includes(m) || m === "manual" || m === "plan" ? "" : `   allow: npx worktrust remote modes allow ${m}`}`);
}

/** `remote desk-history on|off | status`: whether a paired phone or browser may read this computer's own sessions (CHAT-HISTORY.md §7.2). */
export function deskHistoryCommand(io, rest) {
  if (rest[0] === "on" || rest[0] === "off") { const done = applySettingsChange({ what: "desk_history", on: rest[0] === "on" }, { kind: "keyboard" }); if (done.ok && rest[0] === "off") saveChosen("read_along", false); return io.say(`  ✓ ${done.message}`); } // off takes read along with it: the person's own off, remembered (CLI 0.11.26)
  io.say(`  Reading this computer's own sessions from a phone or a browser: ${loadSettings().desk_history === true ? "on" : "off"} (npx worktrust remote desk-history on|off)`);
}

/**
 * WHO READS ALONG NOW (review 2026-11-21, P3-6: under the installed service nobody sees the run terminal's line). The daemon
 * keeps the readers in readers.json (remote-run.mjs: device id, project id and since when, never a word of a session) and
 * refreshes it every three seconds while there are any; `remote status` reads it and believes it for READERS_FRESH_MS.
 */
export const READERS_FRESH_MS = 10_000;
export const keepReaders = (rows, now = Date.now()) => { try { ensureRemoteDir(); writeJson("readers.json", { at: now, readers: rows.slice(0, 8).map((r) => ({ phone: r.phone, project_id: r.project_id, since: r.since })) }); } catch { /* status says nobody: the run terminal's line was still said */ } };
const phoneWords = (id, phones) => { const p = phones.confirmed.find((x) => x.device_id === id); return p?.name ?? (p ? `a phone (key ${p.fingerprint})` : "a phone"); };
const folderWords = (id, projects) => { const p = projects.find((x) => x.project_id === id); return p ? basename(p.path) || p.path : "a granted folder"; };
export function keptReaders(now = Date.now(), phones = loadPhones(), projects = loadProjects()) {
  const kept = readJson("readers.json");
  if (!kept || !Number.isSafeInteger(kept.at) || Math.abs(now - kept.at) > READERS_FRESH_MS || !Array.isArray(kept.readers)) return [];
  return kept.readers.slice(0, 8).map((r) => ({ phone: phoneWords(r.phone, phones), project: folderWords(r.project_id, projects), since: Number.isSafeInteger(r.since) ? r.since : null }));
}
/** What `remote status` and `remote read-along` say of the desk (remote-store.mjs deskReadOf), and who reads along now. */
export function deskReadLine(settings = loadSettings(), now = Date.now()) {
  const read = deskReadOf(settings), readers = read === "live" ? keptReaders(now) : [];
  const clock = (at) => (at === null ? "" : ` since ${new Date(at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`);
  return `  Reading this computer's own sessions from a phone: ${{ off: "off", history: "closed turns only", live: "live (read along) and closed turns" }[read]} (npx worktrust remote read-along on|off)${read === "live" ? `\n  Reading along now: ${readers.length ? readers.map((r) => `${r.phone} in ${r.project}${clock(r.since)}`).join("; ") : "nobody"}` : ""}\n${deskSteerLine(settings)}`;
}
/** `remote read-along on|off | status` (CLI 0.11.19): may a paired phone read along, live and read-only, with a session running at this computer. */
export async function readAlongCommand(io, rest) {
  if (rest[0] === "on" || rest[0] === "off") {
    if (rest[0] === "on" && !(await keyboardYes(io, "A confirmed phone may then read along live with a session in every folder you granted. Turn read along on?"))) return;
    const done = applySettingsChange({ what: "desk_live", on: rest[0] === "on" }, { kind: "keyboard" });
    if (done.ok) saveChosen("read_along", rest[0] === "on"); // typed by the person: remembered, so a link or an update never turns an off back on (CLI 0.11.26)
    return io.say(`  ✓ ${done.message}`);
  }
  if (rest[0] !== undefined && rest[0] !== "status") return io.fail("npx worktrust remote read-along on|off | status");
  io.say(deskReadLine());
  const chosen = loadChosen(), at = chosen.at.read_along;
  io.say(`  Chosen at this keyboard: ${chosen.read_along ? `${chosen.read_along}${at ? ` on ${new Date(at).toISOString().slice(0, 10)}` : ""}` : "not yet (linking a phone, or the next npx worktrust update, turns it on)"}`);
}
/** What the run terminal says when a phone starts or stops reading along (remote-run.mjs): the folder's name and the phone's, never a word of the session. */
export function readAlongLine(fields, phones = loadPhones(), projects = loadProjects()) {
  const who = phoneWords(fields.phone, phones), where = folderWords(fields.project_id, projects);
  const WHY = { off: ": reading along was turned off here", paused: ": this computer is paused", gone: ": the session can no longer be read", busy: ": this computer could not keep up", expired: ": it went away", capped: ": an hour passed (the phone can open it again)", removed: ": it was disconnected", refused: "", asked: "" };
  return fields.on ? `  ! ${who} reads along with a session in ${where}. To stop it: npx worktrust remote read-along off` : `  ! ${who} stopped reading along with a session in ${where}${WHY[fields.why] ?? ""}.`;
}

/** `remote admin on|off | status`: whether a change approved in the app or on the web (with the authenticator) is honoured here. */
export function adminCommand(io, rest) {
  if (rest[0] === "on" || rest[0] === "off") {
    const done = applySettingsChange({ what: "admin", on: rest[0] === "on" }, { kind: "keyboard" });
    io.say(`  ✓ ${done.message}`);
    return;
  }
  io.say(`  Managing this computer from the app or the web: ${loadSettings().admin === false ? "off" : "on"} (npx worktrust remote admin on|off; each change there asks your authenticator)`);
}

/**
 * `remote folder-check` (internal; run by probeFolders as the service's own program): can each root and project in a folder
 * macOS guards be listed? Writes { at, folders: [{ path, folder, ok }] } to folder-check.json and nothing else.
 */
export function folderCheck() {
  const folders = [...loadRoots(), ...loadProjects()].map((x) => x.path).filter((path, i, all) => all.indexOf(path) === i && protectedFolder(path))
    .map((path) => { try { readdirSync(path); return { path, folder: protectedFolder(path), ok: true }; } catch { return { path, folder: protectedFolder(path), ok: false }; } });
  ensureRemoteDir();
  writeJson("folder-check.json", { at: Date.now(), folders });
}

/** After a folder was added at the keyboard: when macOS guards it, ask at once, from the program that will run the agents. */
export async function askMacFolderAccess(io, paths) {
  const guarded = [...new Set((paths ?? []).map((p) => protectedFolder(p)).filter(Boolean))];
  if (guarded.length === 0) return null;
  io.say(`  macOS guards your ${guarded.join(" and ")} folder. It now asks once whether the program that runs your agents (shown as "node" or "python") may read it.`);
  io.say("  Click OK (Allow). Without it, a session there stops at a prompt nobody sees, or fails with \"Operation not permitted\".");
  const ids = io.setup?.folders(guarded) ?? []; if (ids[0]) io.setup.asked("folder_access", ids[0]); const runtime = await io.prepare(); // 0.11.26: one step per guarded folder on the phone (remote-setup.mjs)
  const result = await (io.probeFolders ?? probeFolders)({ program: [runtime.node, ...runtime.nodeArgs, runtime.entry, "remote", "folder-check"], path: loadSettings().agent_path ?? process.env.PATH ?? "" });
  const refusedHere = (result?.folders ?? []).filter((f) => !f.ok);
  for (const name of guarded) { const id = FOLDER_IDS[name]; if (!result) io.setup?.skipped("folder_access", "no_answer", id); else if (refusedHere.some((f) => f.folder === name)) io.setup?.skipped("folder_access", "refused", id); else io.setup?.done("folder_access", id); }
  if (result && refusedHere.length === 0) { io.say("  ✓ macOS lets the Remote Agent service read it."); return true; }
  io.say(`  ! ${result ? `macOS refused: ${refusedHere.map((f) => f.path).join(", ")}` : "No answer from macOS in time"}. To allow it later: System Settings › Privacy & Security › Files and Folders,`);
  io.say(`    then turn on ${guarded.join(" and ")} for "node" (or "python"); or add that program under Full Disk Access.`);
  return false;
}

/**
 * TWO MORE QUESTIONS WHEN A PHONE HAS LINKED (CLI 0.11.14, owner 2026-11-16), after its reach (remote-connections.mjs
 * reachStep): may the confirmed phones add a browser, and which agent modes may a phone start here. Both are the settings
 * that exist, changed through `apply` (the keyboard's one door, applySettingsChange): `endorse` is what `remote phones
 * allow-endorse on|off` writes, the ceiling what `remote modes allow|deny` writes. Both answers are taken first and only
 * then applied, so Ctrl+C or Esc at either question changes nothing. Without a terminal the commands are named.
 */
export const CEILINGS = Object.freeze([
  { value: "plan", label: "Manual and Plan", info: "The agent asks before every change, or only reads and plans." },
  { value: "edit", label: "+ Edit automatically", info: "Also sessions that edit in their projects without asking." },
  { value: "auto", label: "+ Auto", info: "Also the agent's own automatic mode (it allows edit too)." },
]);
/** The ceiling a list of allowed modes is: plan, edit or auto. */
export const ceilingOf = (allowed) => (allowed.includes("auto") ? "auto" : allowed.includes("edit") ? "edit" : "plan");
/** The `modes` changes that move the ceiling from one step to another (none when it stays). */
export function ceilingChanges(from, to) {
  if (from === to) return [];
  if (to === "plan") return [{ what: "modes", deny: "edit" }];
  if (to === "auto") return [{ what: "modes", allow: "auto" }];
  return from === "auto" ? [{ what: "modes", deny: "auto" }] : [{ what: "modes", allow: "edit" }];
}
const nowMark = (on) => (on ? { note: { text: "now", tone: "dim" } } : {});
export async function trustStep(io, { apply, interactive, term = null, choose = null, settings = loadSettings() }) {
  const endorse = settings.allow_endorse === true, ceiling = ceilingOf(allowedModes(settings));
  if (!interactive || !term || !choose) { io.say("  Later: npx worktrust remote phones allow-endorse on|off   and   npx worktrust remote modes allow|deny edit|auto"); return "later"; }
  term.enter();
  try {
    io.setup?.asked("endorse"); const asked = await choose(term, { title: "May your confirmed phones add a browser?", items: [
      { label: "Yes, they may add a browser", info: "A phone confirmed here may add a browser it scanned.", value: true, ...nowMark(endorse) },
      { label: "No", info: "Only this keyboard adds a browser.", value: false, ...nowMark(!endorse) }] });
    if (asked !== "quit" && asked !== "back") io.setup?.asked("modes"); // the endorse answer taken (asked closes it), the modes on the screen now
    const modes = asked === "quit" || asked === "back" ? asked : await choose(term, { title: "Which agent modes may a phone start here?", items: CEILINGS.map((c) => ({ ...c, ...nowMark(c.value === ceiling) })) });
    term.erase(); term.restore();
    if (modes === "quit" || modes === "back") { if (asked === "quit" || asked === "back") io.setup?.skipped("endorse", "later"); io.setup?.skipped("modes", "later"); io.say("  Unchanged. Later: npx worktrust remote phones allow-endorse on|off · npx worktrust remote modes"); return "unchanged"; }
    io.setup?.done("modes");
    const changes = [...(asked.item.value === endorse ? [] : [{ what: "endorse", on: asked.item.value }]), ...ceilingChanges(ceiling, modes.item.value)];
    for (const change of changes) await apply(change);
    if (changes.length === 0) io.say("  ✓ Unchanged: these were already your settings.");
    return "set";
  } finally { term.restore(); }
}

