/**
 * THE TRANSCRIPT READERS — the clients that do not write Claude Code's shape, read into it (2026-10-04).
 *
 * The counter (`count-behaviour.mjs`) and the session hook (`log-session.mjs`) both read other
 * clients' local logs as if they were Claude Code transcripts, so ONE rubric and ONE clock read them
 * all. The readers used to be one block of text copied into both files and held equal by a test;
 * both files had grown past the line ratchet, so the readers now live here, once, and both import
 * this file. It ships beside them: in the npm package, on the site (/counter/transcript-readers.mjs)
 * and in ~/.worktrust, where the hook's install copies it. Without it, both still run and read
 * Claude Code alone, and say so.
 *
 * Text is read here for the rubric and the layer and travels nowhere: what these yield goes to the
 * counter's named rules and the hook's measure(), whose payloads are fixed allowlists of numbers,
 * dates and enum values (log-session.mjs, "WHAT CANNOT LEAVE").
 */
import { closeSync, mkdirSync, openSync, readFileSync, readSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

// ── codex rollout reader ──
/**
 * A CODEX ROLLOUT, READ AS A TRANSCRIPT (2026-09-27). Codex keeps one JSONL per thread under
 * ~/.codex/sessions/YYYY/MM/DD/rollout-<stamp>-<uuid>.jsonl: a session_meta line, then per turn a
 * turn_context (model, effort, cwd), response_items (messages, tool calls, their outputs) and a
 * token_usage_record per model response. On the machine this was built on five of them held 679
 * million tokens that nothing read. This turns the records into the lines Claude Code writes, so
 * ONE rubric and ONE clock read both:
 *   · a user or assistant message → a user or assistant line with a text part; the developer line
 *     and the harness's own user-role messages (<environment_context>, <recommended_plugins> and
 *     the like: a tag opening the text) are the harness, not the person, and are dropped;
 *   · a tool call → an assistant line with a tool_use part: `exec` becomes Bash with the command
 *     as input, `apply_patch` an Edit with the first path it names, `spawn_agent` an Agent; its
 *     output → a user line with a tool_result, is_error read from Codex's own "exit code N";
 *   · a token_usage_record → an assistant line carrying the usage in Claude's keys, ONCE per
 *     response_id (Codex writes a response more than once): input minus cached is new input,
 *     cached is a cache read, cache_write a cache write, output already holds the reasoning tokens.
 * The running total in event_msg/token_count is never read: it is a counter, not a record.
 * Text is read here for the rubric and the layer and travels nowhere, as with every transcript.
 */
// Either separator (0.6.16, audit H4): on Windows a path reads C:\Users\…\rollout-….jsonl, and a pattern of `/` alone matched none.
export const CODEX_ROLLOUT = /(^|[\\/])rollout-\d{4}-\d{2}-\d{2}T[\d-]+-[0-9a-f-]{36}\.jsonl$/;
/** A rollout's thread id: its file's name without .jsonl, split on either separator. */
export const codexIdOf = (file) => String(file).split(/[\\/]/).at(-1).replace(/\.jsonl$/, "");
export const CODEX_HARNESS_TURN = /^\s*<[a-z][a-z_]*[\s>]/i;
export const codexToolName = (name) => (name === "exec" || name === "shell" || name === "container.exec" || name === "local_shell" ? "Bash" : name === "apply_patch" ? "Edit" : name === "spawn_agent" || name === "followup_task" ? "Agent" : name === "request_user_input" || name === "request_user_input_async" ? "AskUserQuestion" : String(name ?? "tool"));
export const codexToolInput = (name, raw) => {
  const mapped = codexToolName(name);
  if (mapped === "Bash") {
    if (typeof raw === "string") { try { const parsed = JSON.parse(raw); if (parsed && typeof parsed === "object") return { command: Array.isArray(parsed.command) ? parsed.command.join(" ") : String(parsed.command ?? parsed.cmd ?? raw) }; } catch { /* the string is the command */ } return { command: raw }; }
    return { command: Array.isArray(raw?.command) ? raw.command.join(" ") : String(raw?.command ?? raw?.cmd ?? "") };
  }
  if (mapped === "Edit") { const path = /\*\*\* (?:Update|Add|Delete) File: ([^\n]+)/.exec(typeof raw === "string" ? raw : JSON.stringify(raw ?? "")); return { file_path: path ? path[1].trim() : "" }; }
  return {};
};
export const codexOutputText = (output) => (typeof output === "string" ? output : Array.isArray(output) ? output.map((part) => (typeof part === "string" ? part : part?.text ?? "")).join("\n") : "");
/** The rollout's raw JSON lines → transcript-shaped line objects, in file order. */
/**
 * HOW THE CODEX SESSION WAS STARTED (owner, 2026-10-22/27; docs/AGENT-HOURS.md), from the rollout's own `session_meta`: `cli`,
 * `vscode` interactive; `exec`, `mcp` (another program's MCP server) and `{ subagent: … }` / `thread_source: "subagent"` (a thread an
 * agent spawned: Agent operations) headless; no source: the `originator` (`codex_exec`, `codex_cli_rs`, `codex_vscode`); else unknown.
 */
export const codexSessionKind = (source, meta = {}) => (source === "cli" || source === "vscode" ? "interactive" : source === "exec" || source === "mcp" || meta.thread_source === "subagent" || (source && typeof source === "object" && Object.hasOwn(source, "subagent")) ? "headless" : source == null ? (meta.originator === "codex_exec" ? "headless" : meta.originator === "codex_cli_rs" || meta.originator === "codex_vscode" ? "interactive" : "unknown") : "unknown");
/**
 * HOW A SESSION WAS STARTED, READ LINE BY LINE (0.10.29; docs/AGENT-HOURS.md): interactive | headless | scheduled | unknown, only from
 * what the AI app wrote, never a guess (WorkTrust counts headless and scheduled as Agent operations, never the person's hours; unknown
 * is left unsaid). Claude Code: `entrypoint` on every line (`cli`, `claude-*` interactive; `sdk-cli` = `claude -p`, `sdk-ts`, `sdk-py`
 * headless) and, on the person's role, `turnOrigin` / `origin.kind`. Not read (measured on 586 sessions): `promptSource: "sdk"` (it
 * rides on editor sessions), `userType` (`external` on every line); a sidechain (subagent) line never decides the first turn.
 * In order: (1) a headless entrypoint is headless, or scheduled when a timer started its first turn; (2) a turn marked `human`:
 * interactive; (3) a first turn marked `scheduled`: scheduled; (4) a first turn from another program (`peer`, `coordinator`, a task
 * notification, `system`): headless; (5) the entrypoint's or a reader's own word; (6) unknown. An unnamed value decides nothing.
 */
const ORIGIN_OF = { human: "human", scheduled: "scheduled", task_notification: "program", "task-notification": "program", peer: "program", coordinator: "program", system: "program" };
const entrypointKind = (value) => (typeof value !== "string" ? null : /^sdk(-|$)/.test(value) ? "headless" : value === "cli" || /^claude-/.test(value) ? "interactive" : "unknown");
const SESSION_WORDS = new Set(["interactive", "headless", "scheduled", "unknown"]);
const onlyToolResults = (content) => Array.isArray(content) && content.length > 0 && content.every((part) => part?.type === "tool_result");
export function sessionKindReader() {
  let entry = null, human = false, first;
  return {
    note(line) {
      if (!line || typeof line !== "object") return;
      // What the client said on the line: a reader's word (Codex), else Claude Code's entrypoint. Interactive wins over headless,
      // headless over unknown (a session resumed by hand after `claude -p` is the person's).
      const said = typeof line.sessionKind === "string" && SESSION_WORDS.has(line.sessionKind) ? line.sessionKind : entrypointKind(line.entrypoint);
      if (said && entry !== "interactive") entry = said === "interactive" ? "interactive" : entry === null || entry === "unknown" ? said : entry;
      if (line.type !== "user" || line.isSidechain === true || line.isMeta === true || line.isCompactSummary === true || onlyToolResults(line.message?.content)) return;
      const origin = ORIGIN_OF[typeof line.turnOrigin === "string" ? line.turnOrigin : typeof line.origin?.kind === "string" ? line.origin.kind : ""] ?? null;
      if (origin === "human") human = true;
      if (first === undefined) first = origin; // the session's first turn, marked or not: an unmarked one decides nothing
    },
    kind() {
      if (entry === "headless") return first === "scheduled" && !human ? "scheduled" : "headless";
      if (human) return "interactive";
      if (first === "scheduled") return "scheduled";
      if (first === "program") return "headless";
      return entry ?? "unknown";
    },
  };
}
/** One session's kind from its lines, in file order (the hook and the tests read it the same way). */
export const sessionKindOf = (lines) => { const reader = sessionKindReader(); for (const line of lines ?? []) reader.note(line); return reader.kind(); };
export function* codexLines(records) {
  let cwd = null, model = null, mode = null, sessionKind = null;
  const seenResponses = new Set();
  for (const raw of records) {
    if (!raw || !String(raw).trim()) continue;
    let record; try { record = JSON.parse(raw); } catch { continue; }
    const timestamp = typeof record?.timestamp === "string" ? record.timestamp : null;
    const payload = record?.payload && typeof record.payload === "object" ? record.payload : {};
    if (record.type === "session_meta") { if (typeof payload.cwd === "string") cwd = payload.cwd; sessionKind ??= codexSessionKind(payload.source, payload); continue; } // the rollout's own (first) meta: a fork's copied history never renames it
    if (record.type === "turn_context") {
      if (typeof payload.cwd === "string") cwd = payload.cwd; if (typeof payload.model === "string") model = payload.model;
      // 0.8.7: Codex's approval policy and sandbox, as one word on the common scale (never asks and full access is "full").
      const approval = String(payload.approval_policy ?? ""), sandbox = String(payload.sandbox_policy?.type ?? payload.sandbox_policy ?? payload.sandbox_mode ?? "");
      mode = approval === "never" ? (sandbox === "danger-full-access" ? "full" : "auto") : approval === "on-failure" ? "edits" : approval ? "ask" : mode;
      continue;
    }
    if (record.type === "token_usage_record") {
      const id = String(payload.response_id ?? "");
      const usage = payload.usage;
      if (!usage || typeof usage !== "object" || (id && seenResponses.has(id))) continue;
      if (id) seenResponses.add(id);
      const n = (key) => (typeof usage[key] === "number" && Number.isFinite(usage[key]) ? usage[key] : 0);
      yield { ...(sessionKind ? { sessionKind } : {}), type: "assistant", timestamp, cwd, uuid: id ? `codex-usage-${id}` : undefined, message: { ...(model ? { model } : {}), content: [], usage: { input_tokens: Math.max(0, n("input_tokens") - n("cached_input_tokens")), output_tokens: n("output_tokens"), cache_read_input_tokens: n("cached_input_tokens"), cache_creation_input_tokens: n("cache_write_input_tokens") } } };
      continue;
    }
    if (record.type !== "response_item") continue;
    const kind = payload.type;
    if (kind === "message") {
      if (payload.role !== "user" && payload.role !== "assistant") continue;
      const text = Array.isArray(payload.content) ? payload.content.filter((part) => typeof part?.text === "string").map((part) => part.text).join("\n") : typeof payload.content === "string" ? payload.content : "";
      if (payload.role === "user" && CODEX_HARNESS_TURN.test(text)) continue;
      yield { ...(sessionKind ? { sessionKind } : {}), type: payload.role, timestamp, cwd, ...(mode ? { permissionMode: mode } : {}), uuid: payload.id ? `codex-${payload.id}` : undefined, message: { ...(payload.role === "assistant" && model ? { model } : {}), content: [{ type: "text", text }] } };
      continue;
    }
    if (kind === "custom_tool_call" || kind === "function_call") {
      const input = kind === "function_call" ? (() => { try { return JSON.parse(payload.arguments ?? "{}"); } catch { return {}; } })() : payload.input;
      yield { ...(sessionKind ? { sessionKind } : {}), type: "assistant", timestamp, cwd, uuid: payload.id ? `codex-${payload.id}` : undefined, message: { ...(model ? { model } : {}), content: [{ type: "tool_use", ...(payload.call_id ? { id: String(payload.call_id) } : {}), name: codexToolName(payload.name), input: codexToolInput(payload.name, input) }] } };
      continue;
    }
    if (kind === "custom_tool_call_output" || kind === "function_call_output") {
      const text = codexOutputText(payload.output);
      const exit = /(?:failed with|exited with|exit code)[:\s]+(-?\d+)/i.exec(text.slice(-400));
      yield { ...(sessionKind ? { sessionKind } : {}), type: "user", timestamp, cwd, uuid: payload.id ? `codex-${payload.id}` : undefined, message: { content: [{ type: "tool_result", ...(payload.call_id ? { tool_use_id: String(payload.call_id) } : {}), content: text, is_error: exit ? exit[1] !== "0" : false, ...(exit ? {} : { outcome: "unknown" }) }] } }; // 0.8.5: no exit code (Codex code mode never prints one) is an unknown outcome, never a pass
    }
  }
}
/** Every rollout under a Codex sessions root, in a stable order. */
/**
 * WHAT A CODEX ROLLOUT SHOWS OF HOW THE PERSON STEERS (CLI 0.10.16, owner 2026-10-16): the same `live` keys the WorkTrust
 * mod fills inside Claude Code, read from what Codex itself writes, so nothing is installed. Per UTC day of one rollout:
 * each turn by its effort level (`turn_context.effort`; per TURN here, per request in Claude Code), the models that
 * answered, the highest context fill (a request's input tokens over the model's window) and the highest plan-limit use
 * (`rate_limits.primary`/`secondary.used_percent`), as whole percentages. Compactions and subagents stay out: the rollout
 * does not say who started them, and a guess is noise. Null when the day shows none of it.
 */
const EFFORT_LEVELS = new Set(["low", "medium", "high", "xhigh", "max"]);
export function codexLive(file, day) {
  if (!CODEX_ROLLOUT.test(String(file)) || !/^\d{4}-\d{2}-\d{2}$/.test(String(day))) return null;
  let text; try { text = readFileSync(file, "utf8"); } catch { return null; }
  const out = {}, models = new Set();
  const peak = (key, value) => { if (Number.isFinite(value)) { const v = Math.max(0, Math.min(100, Math.round(value))); if (v > 0 && (out[key] ?? 0) < v) out[key] = v; } };
  for (const raw of text.split("\n")) {
    if (!raw.includes(day)) continue;
    let record; try { record = JSON.parse(raw); } catch { continue; }
    if (String(record?.timestamp ?? "").slice(0, 10) !== day) continue;
    const p = record?.payload && typeof record.payload === "object" ? record.payload : {};
    if (record.type === "turn_context") {
      if (typeof p.effort === "string" && EFFORT_LEVELS.has(p.effort)) out[`effort_${p.effort}`] = Math.min(100000, (out[`effort_${p.effort}`] ?? 0) + 1);
      if (typeof p.model === "string" && p.model) models.add(p.model);
    } else if (record.type === "event_msg" && p.type === "token_count") {
      const window = p.info?.model_context_window, input = p.info?.last_token_usage?.input_tokens;
      if (Number.isFinite(window) && window > 0 && Number.isFinite(input)) peak("context_peak_pct", (input / window) * 100);
      for (const limit of [p.rate_limits?.primary, p.rate_limits?.secondary]) peak("limit_peak_pct", limit?.used_percent);
    }
  }
  if (models.size > 0) out.models = models.size;
  return Object.keys(out).length > 0 ? out : null;
}

export function* codexRolloutFiles(root) {
  let entries = []; try { entries = readdirSync(root, { withFileTypes: true }); } catch { return; }
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const full = join(root, entry.name);
    if (entry.isDirectory()) yield* codexRolloutFiles(full);
    else if (CODEX_ROLLOUT.test(entry.name)) yield full;
  }
}
/** The rollout's working directory, from its first line alone: the file is not read for it. */
export function codexCwd(file) {
  let fd; try { fd = openSync(file, "r"); } catch { return null; }
  try {
    const buffer = Buffer.allocUnsafe(64 * 1024);
    const read = readSync(fd, buffer, 0, buffer.length, 0);
    const first = buffer.toString("utf8", 0, read).split("\n")[0] ?? "";
    const meta = JSON.parse(first);
    return meta?.type === "session_meta" && typeof meta.payload?.cwd === "string" ? meta.payload.cwd : null;
  } catch { return null; } finally { closeSync(fd); }
}
// ── end codex rollout reader ──

// ── antigravity transcript reader ──
/**
 * A GOOGLE ANTIGRAVITY CONVERSATION, READ AS A TRANSCRIPT (2026-10-04). Antigravity (the 2.0 app,
 * the `agy` CLI and the IDE) keeps one plaintext JSONL per conversation at
 * <app_data_dir>/brain/<conversationId>/.system_generated/logs/transcript.jsonl, app_data_dir being
 * ~/.gemini/antigravity (2.0), ~/.gemini/antigravity-cli (CLI) or, likely, ~/.gemini/antigravity-ide
 * (antigravity.google/docs/hooks/ names the path as the hook's transcriptPath; the step fields from
 * jazzyalex.github.io/agent-sessions/guides/antigravity-cli-local-history.html). One object per
 * step: step_index, source (USER_EXPLICIT | MODEL | SYSTEM), type (USER_INPUT, PLANNER_RESPONSE,
 * RUN_COMMAND, VIEW_FILE, CODE_ACTION …, CONVERSATION_HISTORY, CHECKPOINT, SYSTEM_MESSAGE),
 * status, created_at, content, optional thinking and tool_calls. NO token and NO model field:
 *   · a USER_INPUT the person wrote (USER_EXPLICIT) → a user line with a text part: a human turn;
 *   · a PLANNER_RESPONSE → an assistant line: its content as text, each tool call a tool_use
 *     (a command → Bash, a file write → Edit, a subagent → Agent), the model the HOOK named;
 *   · any other step of the loop (a command run, a file viewed) → a user line with a tool_result,
 *     which is never a human turn, is_error from its status or the exit phrase;
 *   · replayed history, checkpoints, system and ephemeral messages → nothing: the harness, not work.
 * `thinking` is never read. No usage block is made up: such a stretch is sent without tokens.
 * A step written twice (RUNNING, then DONE) is read once, on its step_index.
 */
export const ANTIGRAVITY_TRANSCRIPT = /(^|[\\/])brain[\\/][^\\/]+[\\/]\.system_generated[\\/]logs[\\/]transcript\.jsonl$/; // either separator (0.6.16, H4)
/** A transcript's conversation id: the folder under brain/, split on either separator. */
export const antigravityIdOf = (file) => String(file).split(/[\\/]/).at(-4);
const ANTIGRAVITY_SKIPPED = new Set(["CONVERSATION_HISTORY", "CHECKPOINT", "SYSTEM_MESSAGE", "EPHEMERAL_MESSAGE"]);
/** A model name as a client names it, or null: the hook's modelName is the only one, and a name is all it may be. */
export const cleanModel = (name) => (typeof name === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/ -]{0,63}$/.test(name.trim()) ? name.trim() : null);
const antigravityTime = (value) => {
  if (typeof value === "string") { const at = Date.parse(value); return Number.isFinite(at) ? new Date(at).toISOString() : null; }
  if (typeof value === "number" && Number.isFinite(value)) return new Date(value < 1e12 ? value * 1000 : value).toISOString();
  if (value && typeof value === "object" && Number.isFinite(Number(value.seconds))) return new Date(Number(value.seconds) * 1000 + Math.floor(Number(value.nanos ?? 0) / 1e6)).toISOString();
  return null;
};
const antigravityArgs = (call) => { const raw = call?.args ?? call?.arguments ?? call?.input ?? {}; if (typeof raw !== "string") return raw && typeof raw === "object" ? raw : {}; try { return JSON.parse(raw) ?? {}; } catch { return {}; } };
const antigravityTool = (call) => {
  const name = String(call?.name ?? "tool");
  const args = antigravityArgs(call);
  if (/run_command|shell|exec|terminal/i.test(name)) return { type: "tool_use", name: "Bash", input: { command: String(args.CommandLine ?? args.command ?? args.cmd ?? "") } };
  if (/write|replace|edit|code_action|create_file/i.test(name)) return { type: "tool_use", name: "Edit", input: { file_path: String(args.TargetFile ?? args.AbsolutePath ?? args.file_path ?? args.path ?? "") } };
  if (/subagent|spawn|delegate/i.test(name)) return { type: "tool_use", name: "Agent", input: {} };
  return { type: "tool_use", name, input: {} };
};
/** The transcript's raw JSON lines → transcript-shaped line objects. `context`: { id, model, cwd } from the hook. */
export function* antigravityLines(records, context = {}) {
  const model = cleanModel(context.model);
  const cwd = typeof context.cwd === "string" ? context.cwd : null;
  const seen = new Set();
  for (const raw of records) {
    if (!raw || !String(raw).trim()) continue;
    let step; try { step = JSON.parse(raw); } catch { continue; }
    if (!step || typeof step !== "object") continue;
    const index = Number.isInteger(step.step_index) ? step.step_index : null;
    if (index !== null) { if (seen.has(index)) continue; seen.add(index); }
    const timestamp = antigravityTime(step.created_at);
    const type = String(step.type ?? "");
    if (!timestamp || ANTIGRAVITY_SKIPPED.has(type)) continue;
    const uuid = index !== null && context.id ? `antigravity-${context.id}-${index}` : undefined;
    const text = typeof step.content === "string" ? step.content : "";
    if (type === "USER_INPUT") { if (step.source === "USER_EXPLICIT") yield { type: "user", timestamp, cwd, uuid, message: { content: [{ type: "text", text }] } }; continue; }
    if (type === "PLANNER_RESPONSE") {
      // No tool_use id: a result names no call, so the counter pairs a run with the next result in order.
      const calls = (Array.isArray(step.tool_calls) ? step.tool_calls : []).map(antigravityTool);
      yield { type: "assistant", timestamp, cwd, uuid, message: { ...(model ? { model } : {}), content: [...(text ? [{ type: "text", text }] : []), ...calls] } };
      continue;
    }
    const exit = /(?:failed with|exited with|exit code)[:\s]+(-?\d+)/i.exec(text.slice(-400));
    yield { type: "user", timestamp, cwd, uuid, message: { content: [{ type: "tool_result", content: text, is_error: /^(ERROR|FAILED)$/i.test(String(step.status ?? "")) || (exit ? exit[1] !== "0" : false) }] } };
  }
}
/** The app data directories Antigravity may write to: the 2.0 app, the CLI, the IDE; a test names its own. */
export const antigravityRoots = (given) => (given ? [given.replace(/^~(?=\/|$)/, homedir())] : ["antigravity", "antigravity-cli", "antigravity-ide"].map((name) => join(homedir(), ".gemini", name)));
/** Whether Antigravity is on this machine: its config folder or one of its data folders. */
export const antigravityHere = () => [join(homedir(), ".gemini", "config"), ...antigravityRoots()].some((path) => { try { return statSync(path).isDirectory(); } catch { return false; } });
/** Every conversation's transcript under the roots, in a stable order. */
export function* antigravityTranscripts(roots) {
  for (const root of roots) {
    let ids = []; try { ids = readdirSync(join(root, "brain")).sort(); } catch { continue; }
    for (const id of ids) {
      const file = join(root, "brain", id, ".system_generated", "logs", "transcript.jsonl");
      try { if (statSync(file).isFile()) yield { conversationId: id, file }; } catch { /* no transcript in this conversation */ }
    }
  }
}
/**
 * WHAT THE HOOK SAID, KEPT ON THIS MACHINE. The transcript names neither the model nor the folder;
 * the Stop hook's payload does (modelName, workspacePaths). Both are kept in ~/.worktrust/antigravity.json
 * per conversation, so a day swept later still knows its model and its repository; the folder never
 * leaves (the hook reads it for the repository's owner/name and a layer keyword, as for Claude Code).
 */
const MEMORY = () => join(homedir(), ".worktrust", "antigravity.json");
const readMemory = () => { try { return JSON.parse(readFileSync(MEMORY(), "utf8")) ?? {}; } catch { return {}; } };
export const antigravityContext = (conversationId) => readMemory()[conversationId] ?? {};
export function rememberAntigravity(input) {
  const id = typeof input?.conversationId === "string" && /^[A-Za-z0-9_-]{1,80}$/.test(input.conversationId) ? input.conversationId : null;
  if (!id) return null;
  const first = Array.isArray(input.workspacePaths) ? input.workspacePaths.find((path) => typeof path === "string") : null;
  let cwd = null; try { cwd = first ? (first.startsWith("file://") ? fileURLToPath(first) : first) : null; } catch { cwd = null; }
  const memory = readMemory();
  memory[id] = { ...(memory[id] ?? {}), ...(cleanModel(input.modelName) ? { model: cleanModel(input.modelName) } : {}), ...(cwd ? { cwd } : {}), at: new Date().toISOString() };
  const kept = Object.fromEntries(Object.entries(memory).sort((a, b) => String(b[1]?.at ?? "").localeCompare(String(a[1]?.at ?? ""))).slice(0, 500));
  try { mkdirSync(join(homedir(), ".worktrust"), { recursive: true }); writeFileSync(MEMORY(), JSON.stringify(kept)); } catch { /* the sweep still runs, without the model */ }
  return id;
}
// ── end antigravity transcript reader ──

// ── the database clients' tool calls (0.8.5), read by session-databases.mjs ──
/**
 * A CURSOR TOOL CALL AS THE STRETCH READS IT (0.8.5): its name mapped to the common one (a terminal command is Bash,
 * its to-do list is TodoWrite), the command for the CLI to name a KIND of (never kept), the to-do statuses (never their
 * text), and the outcome Cursor recorded: an exit code only when the command failed, an error status, or the person's
 * rejection; a background command, or a call with no outcome, is unknown, never a pass.
 */
const CURSOR_NAMES = { run_terminal_command_v2: "Bash", run_terminal_cmd: "Bash", todo_write: "TodoWrite", edit_file_v2: "Edit", edit_file: "Edit", read_file_v2: "Read", read_file: "Read", ripgrep_raw_search: "Grep", glob_file_search: "Glob", delete_file: "Edit" };
const json = (text) => { if (typeof text !== "string") return null; try { return JSON.parse(text); } catch { return null; } };
export function cursorCall(bubble) {
  const id = typeof bubble.callId === "string" && bubble.callId ? bubble.callId : null;
  if (!id) return null;
  const raw = String(bubble.toolName ?? "tool"), name = CURSOR_NAMES[raw] ?? raw;
  const todos = json(bubble.todoStatuses);
  const input = name === "Bash" ? { command: typeof bubble.command === "string" ? bubble.command : "" } : name === "TodoWrite" && Array.isArray(todos) && todos.length > 0 ? { todos: todos.map((status) => ({ status: status === "completed" ? "completed" : "pending" })) } : {};
  const rejected = Number(bubble.rejected) === 1 || bubble.rejected === true || bubble.decision === "rejected";
  const exit = bubble.exitCode === null || bubble.exitCode === undefined ? null : Number(bubble.exitCode);
  const failed = rejected || (exit !== null && exit !== 0) || bubble.outcome === "error" || bubble.status === "error";
  const known = failed || (name === "Bash" ? Number(bubble.hasOutput) === 1 && Number(bubble.background) !== 1 : bubble.status === "completed" || bubble.outcome === "success");
  return {
    use: { type: "tool_use", id, name, input },
    result: { type: "tool_result", tool_use_id: id, is_error: failed, ...(known ? {} : { outcome: "unknown" }), content: rejected ? "User rejected the tool call." : "" },
  };
}
/**
 * A COPILOT TOOL CALL AS THE STRETCH READS IT (0.8.5): a terminal command is Bash (its command line for the CLI to name
 * a kind of, never kept) with the exit code VS Code recorded; a missing exit code is unknown. Its to-do list is TodoWrite
 * (statuses only), its subagents are Agent. What a confirmation type means is not documented, so no refusal is read.
 */
const COPILOT_NAMES = { run_in_terminal: "Bash", manage_todo_list: "TodoWrite", execution_subagent: "Agent", runSubagent: "Agent", copilot_replaceString: "Edit", copilot_createFile: "Write", copilot_readFile: "Read", copilot_findTextInFiles: "Grep", copilot_findFiles: "Glob" };
export function copilotCall(part) {
  const id = typeof part.toolCallId === "string" && part.toolCallId ? part.toolCallId : null;
  if (!id) return null;
  const raw = String(part.toolId ?? "tool"), name = COPILOT_NAMES[raw] ?? raw, data = part.toolSpecificData ?? {};
  const line = data.commandLine && typeof data.commandLine === "object" ? data.commandLine.toolEdited ?? data.commandLine.original : null;
  const input = name === "Bash" ? { command: typeof line === "string" ? line : "" } : name === "TodoWrite" && Array.isArray(data.todoList) ? { todos: data.todoList.map((todo) => ({ status: todo?.status === "completed" ? "completed" : "pending" })) } : {};
  const exit = Number.isInteger(data.terminalCommandState?.exitCode) ? data.terminalCommandState.exitCode : null;
  const known = name === "Bash" ? exit !== null : false;
  return { use: { type: "tool_use", id, name, input }, result: { type: "tool_result", tool_use_id: id, is_error: exit !== null && exit !== 0, ...(known ? {} : { outcome: "unknown" }), content: "" } };
}
