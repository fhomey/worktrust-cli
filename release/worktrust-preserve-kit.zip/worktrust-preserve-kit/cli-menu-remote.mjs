/**
 * THE MENU'S DEEPER LEVELS (CLI 0.11.7; 0.11.8: every item says in one sentence what it does, `info`, beside its command, `hint`): Remote Agent ›, its projects, roots, allowed modes and connections, and the history and
 * preservation choices. Each item still runs one direct command (runShown), named in its muted line; this file only reads
 * the remote settings to label the items and never writes one itself: a change goes through the command, so it goes
 * through applySettingsChange (remote-settings.mjs) like a typed one. Folders are chosen without typing (folder-picker.mjs).
 *
 * 0.11.9 (owner, 2026-11-14): every sentence fits the one-row form (60 characters at most), and Remote Agent asks for the
 * approval FIRST: what cannot work before it cannot be chosen (remoteItems).
 */
import { homedir } from "node:os";
import { join } from "node:path";
import { choose, muted, remoteState, runShown, typed } from "./cli-menu.mjs";
import { makeProjectsFolder, pickFolder, pickerCommand, suggestedFolders } from "./folder-picker.mjs";
import { awaitingName, awaitingRow, connections } from "./remote-connections.mjs";
import { detailLines, deviceHistory, deviceLabel, historyRows as deviceRows, shortNumber } from "./remote-device-history.mjs";
import { loadIdentity, loadProjects, loadRoots, loadSettings } from "./remote-store.mjs";
import { allowedModes, ceilingOf } from "./remote-settings.mjs";
import { HEALTH_REFUSAL, keptHealth } from "./remote-health.mjs";
import { defaultRootOf } from "./remote-store.mjs";
import { ask, defaultRootItem, permissionsRow, switchItems } from "./cli-menu-switches.mjs";
import { behindPhones, updateLines, updateRow } from "./remote-phone-app.mjs";

const BACK = { label: "← Back", hint: "Esc", back: true }; // its name and its key say it: no sentence of its own (owner, 2026-11-14)
const tilde = (path) => (path.startsWith(homedir()) ? `~${path.slice(homedir().length)}` : path);

/** Loop one level: each pick runs, Back or Esc returns; a pick that returns false ends the menu (Ctrl+C after a command). */
async function level(term, header, title, build, io = null) {
  for (;;) {
    const picked = await choose(term, { header, title: typeof title === "function" ? title() : title, items: build() });
    if (picked === "quit") return false;
    if (picked === "back" || picked.item.back) return true;
    const result = picked.item.run ? await picked.item.run() : true;
    await io?.state?.(); // the head above reads this computer again: what the command changed shows at once
    if (result === false) return false;
    if (result === "back") return true; // the step this level was for is done (0.11.9: approved): the level above draws again
  }
}

/** The folder the system picker chose, or a typed path where there is no picker. */
async function chooseFolder(term) {
  const command = pickerCommand();
  if (command) { term.restore(); const path = await pickFolder(command); term.enter(); return path; }
  return typed(term, "No folder picker on this system. Type the folder's path:");
}

/** Roots › Add folders: the suggested folders, ticked with Space, a new folder, or the system's picker. */
async function addRoots(term, io, header) {
  const have = new Set(loadRoots().map((r) => r.path));
  const offered = suggestedFolders().filter((f) => !have.has(f.path));
  const items = [
    ...offered.map((f) => ({ label: tilde(f.path), note: { text: `${f.projects} project${f.projects === 1 ? "" : "s"} found`, tone: "dim" }, info: "Space ticks it; Enter adds the ticked folders as roots.", tick: true, path: f.path })),
    { label: "+ Make a new folder for my projects", make: true, hint: "npx worktrust remote roots add <folder> --git-init", info: "Makes a folder in your home folder and adds it as a root." },
    { label: "Choose another folder…", pick: true, hint: "npx worktrust remote roots add <folder>", info: "Opens the folder picker and adds the folder you choose." },
    BACK,
  ];
  const picked = await choose(term, { header, title: "Add folders where your projects live", items, multi: true });
  if (picked === "quit") return false;
  if (picked === "back" || picked.item.back) return true;
  const chosen = picked.ticked.map((i) => ({ path: i.path, gitInit: false }));
  if (picked.item.make) {
    const name = await typed(term, "Name of the new folder in your home folder:", "Projects");
    term.enter();
    if (name) { const made = makeProjectsFolder(name); if (made.ok) chosen.push({ path: made.path, gitInit: true }); else { term.write(`  ${made.reason}\n`); await term.anyKey(); } }
  }
  if (picked.item.pick) { const path = await chooseFolder(term); term.enter(); if (path) chosen.push({ path, gitInit: false }); }
  for (const c of chosen) if ((await runShown(term, io, ["remote", "roots", "add", c.path, ...(c.gitInit ? ["--git-init"] : [])])) === false) return false;
  return true;
}

/** The rows of Roots for new projects ›, for its level and for the search (0.11.21: the default folder's switch first). */
const rootsRows = (term, io, header) => [
    defaultRootItem((() => { try { return defaultRootOf() !== null; } catch { return false; } })(), (args) => runShown(term, io, args)),
    { label: "+ Add folders", hint: "npx worktrust remote roots add <folder>", info: "Choose folders whose projects a phone may open or add to.", run: () => addRoots(term, io, header) },
    ...loadRoots().map((r) => ({ label: `Remove ${tilde(r.path)}`, hint: `npx worktrust remote roots remove ${tilde(r.path)}`, info: "A phone can no longer use this folder. No file is touched.", run: () => runShown(term, io, ["remote", "roots", "remove", r.path]) })),
    BACK,
  ];
const rootsMenu = (term, io, header) => level(term, header, "Roots for new projects", () => rootsRows(term, io, header));

function projectsMenu(term, io, header) {
  return level(term, header, "Projects a phone may steer an agent in", () => [
    { label: "+ Add a project folder…", hint: "npx worktrust remote projects add <folder>", info: "Pick a folder a phone may steer an agent in.", run: async () => { const path = await chooseFolder(term); term.enter(); return path ? runShown(term, io, ["remote", "projects", "add", path]) : true; } },
    ...loadProjects().map((p) => ({ label: `Remove ${tilde(p.path)}`, hint: `npx worktrust remote projects remove ${tilde(p.path)}`, info: "A phone can no longer start an agent here. No file changes.", run: () => runShown(term, io, ["remote", "projects", "remove", p.path]) })),
    BACK,
  ]);
}

function modesMenu(term, io, header) {
  return level(term, header, "Agent modes a phone may start here", () => {
    const allowed = allowedModes(loadSettings());
    const toggle = (mode, words) => ({ label: `${words}: ${allowed.includes(mode) ? "allowed" : "not allowed"}`, hint: `npx worktrust remote modes ${allowed.includes(mode) ? "deny" : "allow"} ${mode}`, info: allowed.includes(mode) ? `Stops a phone from starting this mode${mode === "edit" ? "; auto goes too" : ""}.` : `Lets a phone start this mode${mode === "auto" ? "; that allows edit too" : ""}.`,
      run: () => runShown(term, io, ["remote", "modes", allowed.includes(mode) ? "deny" : "allow", mode]),
      confirm: { ...ask(words.toLowerCase(), `A phone may start an agent in ${words.toLowerCase()} mode here.`, `Phones may start it from now on${mode === "auto" ? ", and edit automatically too" : ""}.`, `Phones can no longer start it${mode === "edit" ? "; auto mode goes too" : ""}. Running sessions keep their mode.`, !allowed.includes(mode)), question: allowed.includes(mode) ? `Stop phones starting ${words.toLowerCase()}?` : `Let phones start ${words.toLowerCase()}?` } });
    return [
      { label: "Manual: always allowed", info: "Always there: the agent asks before every change.", disabled: true },
      { label: "Plan: always allowed", info: "Always there: the agent reads and plans, changes nothing.", disabled: true },
      toggle("edit", "Edit automatically"),
      toggle("auto", "Auto mode"),
      { label: "Status", hint: "npx worktrust remote modes status", info: "Shows which modes a phone may start. It only reads.", run: () => runShown(term, io, ["remote", "modes", "status"]) },
      BACK,
    ];
  });
}

/**
 * THE LINKED DEVICES, AS A TABLE (0.11.9, owner 2026-11-14): one row per connection: name, kind, since, last activity. Enter
 * opens that connection's acts. Disconnect runs the same `remote disconnect <fingerprint>` a person types, with its typed
 * confirmation (remote-connections.mjs, a security decision of 2026-11-12): the menu confirms nothing itself and fills nothing in.
 */
const day = (ms) => (Number.isFinite(ms) ? new Date(ms).toISOString().slice(0, 10) : "not known");
function connectionsMenu(term, io, header) {
  return level(term, header, "Connections to this computer", () => {
    const list = connections(), wide = Math.min(20, Math.max(4, ...list.map((c) => c.name.length))), last = term.size().columns >= 72; // a narrow terminal keeps name, kind and since
    if (list.length === 0) return [
      { label: "Nothing is linked now.", info: "Link a phone with the row below.", disabled: true, quiet: "Nothing to open here." },
      { label: "Link a phone (QR here)", hint: "npx worktrust remote pair", info: "Shows a QR that links a phone to this computer.", run: () => runShown(term, io, ["remote", "pair"]) },
      { label: "History ›", hint: "npx worktrust remote phones --history", info: "Every device ever linked here: how long, how it ended.", run: () => devicesMenu(term, io, header) }, // 0.11.22: who was linked, and how long
      BACK,
    ];
    const acts = (c) => () => level(term, header, `${c.name} · ${c.kind} · ${c.fingerprint}`, () => [
      ...(c.state === "pending" ? [{ label: "Confirm it", hint: `npx worktrust remote phones confirm ${c.fingerprint}`, info: "Confirms this link. Check the fingerprint on the device.", run: async () => ((await runShown(term, io, ["remote", "phones", "confirm", c.fingerprint])) === false ? false : "back") }] : []),
      { label: "Disconnect", hint: `npx worktrust remote disconnect ${c.fingerprint}`, info: "Closes it. You type its name or code to confirm.", run: async () => ((await runShown(term, io, ["remote", "disconnect", c.fingerprint])) === false ? false : "back") },
      BACK,
    ], io);
    return [
      ...list.map((c) => ({ label: `${c.name.length > wide ? `${c.name.slice(0, wide - 1)}…` : c.name.padEnd(wide)}  ${c.kind.padEnd(7)}  since ${day(c.since)}${last ? `  last ${day(c.last_seen)}` : ""}${c.state === "pending" ? "  pending" : ""}${c.inUse ? "  in use" : ""}`, hint: `npx worktrust remote disconnect ${c.n}`, info: `Enter opens ${c.name} · ${c.fingerprint}.`, run: acts(c) })),
      { label: "Disconnect all…", hint: "npx worktrust remote disconnect --all", info: "Closes every connection. You type close all to confirm.", run: () => runShown(term, io, ["remote", "disconnect", "--all"]) },
      { label: "History ›", hint: "npx worktrust remote phones --history", info: "Every device ever linked here: how long, how it ended.", run: () => devicesMenu(term, io, header) },
      BACK,
    ];
  }, io);
}

/**
 * HISTORY › (CLI 0.11.26, owner 2026-11-25: "device | number | linked since | last seen >, and when you open one you see all the
 * additional information, and you can go back"). One short row per link (remote-device-history.mjs historyRows, cut to the
 * terminal so nothing wraps); Enter opens its detail, every field labelled, with Disconnect for a link that is live now (the
 * same `remote disconnect` and its typed confirmation); Back returns to the list on the same row.
 */
export async function devicesMenu(term, io, header) {
  for (let at = 0; ;) {
    const periods = deviceHistory(), rows = deviceRows(periods, term.size().columns - 8); // "> 1  " before a row and a space after it
    const items = [...(periods.length === 0 ? [{ label: "No device was ever linked here.", disabled: true, quiet: "Nothing to open here." }] : []),
      ...periods.map((p, i) => ({ label: rows[i], hint: `npx worktrust remote phones --history ${shortNumber(p)}`, info: "Enter opens everything known about this device.", period: p })), BACK];
    const picked = await choose(term, { header, title: `Devices linked to this computer, newest first (${periods.length})`, items, at });
    if (picked === "quit") return false;
    if (picked === "back" || picked.item.back) return true;
    at = items.indexOf(picked.item);
    if ((await deviceDetail(term, io, picked.item.period)) === false) return false;
  }
}
async function deviceDetail(term, io, p) {
  const live = connections().find((c) => c.device_id === p.device_id && !p.ended_at && !p.ended_how);
  const items = [...(live ? [{ label: "Disconnect", hint: `npx worktrust remote disconnect ${live.fingerprint}`, info: "Closes it. You type its name or code to confirm.", run: () => runShown(term, io, ["remote", "disconnect", live.fingerprint]) }] : []), BACK];
  const picked = await choose(term, { header: () => detailLines(p, term.size().columns - 1), title: `${deviceLabel(p)} · ${shortNumber(p)}`, items });
  if (picked === "quit") return false;
  if (picked === "back" || picked.item.back) return true;
  return picked.item.run(); // after a disconnect: the list again, read anew
}

/**
 * SHARING (0.11.9, owner 2026-11-14): what this computer sends, in words, and the switches that exist. Each switch runs the
 * command a person types (`mcp off | on`, `remote pause | resume`); the session hook has no switch in the CLI (measuring is
 * paused in WorkTrust under Sources, and `disconnect` takes it out), so its row says so and cannot be chosen. One app alone
 * cannot be coupled or uncoupled by a command today, so there is no row per app. The state is read again at every draw.
 */
/** Pause and resume ask first too (0.11.22): one wording, in Sharing and in Remote Agent. */
const pauseAsk = (paused) => ({ name: "Remote Agent", what: "Linked phones and browsers steer the agents on this computer.", change: paused ? "Phones can steer agents here again." : "No phone steers agents here until you resume. Links and sessions stay.", question: paused ? "Resume Remote Agent?" : "Pause Remote Agent?" });

export function sharingItems(state, remote, act = {}) {
  const doorOn = state.door === "on", live = ["approved", "paused"].includes(remote.word), paused = remote.word === "paused";
  return [
    { label: `Session hook: ${state.hook === true ? "on" : state.hook === false ? "not installed" : "not known"}`, note: { text: "no switch here", tone: "dim" }, info: "Sends times, tokens, models and tools. Never content.", disabled: true, quiet: "Pause it under Sources." },
    state.door === "on" || state.door === "off"
      ? { label: `WorkTrust in your AI apps: ${doorOn ? `on${Number.isInteger(state.apps) ? ` (${state.apps} app${state.apps === 1 ? "" : "s"})` : ""}` : "off"}`, hint: `npx worktrust mcp ${doorOn ? "off" : "on"}`, info: doorOn ? "On: your AI logs finished work. Enter takes the door out." : "Off: hours only. Enter puts the door back in your AI apps.", run: () => act.door?.(doorOn ? "off" : "on"),
        confirm: ask("WorkTrust in your AI apps", "Your AI apps can log a piece of finished work through WorkTrust's door. Never its content.", "The door goes back into your AI apps.", "The door comes out of your AI apps. Your hours are still measured.", !doorOn) }
      : { label: "WorkTrust in your AI apps: not known", hint: "npx worktrust mcp status", info: "Its state could not be read. Enter shows it.", run: () => act.door?.("status") },
    live
      ? { label: `Remote Agent: ${paused ? "paused" : "on"}`, hint: `npx worktrust remote ${paused ? "resume" : "pause"}`, info: paused ? "Paused: no phone steers agents here. Enter resumes." : "On: linked phones steer agents here. Enter pauses.", run: () => act.remote?.(paused ? "resume" : "pause"), confirm: pauseAsk(paused) }
      : { label: `Remote Agent: ${remote.word}`, hint: "npx worktrust remote …", info: "Lets your phone steer this computer's agents.", disabled: true, quiet: remote.word === "not known" ? "Its state could not be read." : "Set it up under Remote Agent." },
    BACK,
  ];
}
export async function sharingMenu(term, io, header) {
  for (;;) {
    const state = await io.state();
    const picked = await choose(term, { header, title: "Sharing", items: sharingItems(state, remoteState(), { door: (to) => runShown(term, io, ["mcp", to]), remote: (to) => runShown(term, io, ["remote", to]) }) });
    if (picked === "quit") return false;
    if (picked === "back" || picked.item.back) return true;
    if ((await picked.item.run()) === false) return false;
  }
}

/**
 * WHETHER THIS COMPUTER IS APPROVED FOR REMOTE AGENT, in three states (0.11.9): true (its identity is here), false (none),
 * null when the file could not be read (remote-store readJson refuses an unreadable or non-private one): not known is
 * never "not approved".
 */
export function approval() { try { return Boolean(loadIdentity()); } catch { return null; } }

/**
 * Remote Agent's rows (owner, 2026-11-14: "first the approve, and once that succeeded you go on to the other steps"). Pure:
 * `approved` is approval()'s answer, `act` what each row does. NOT APPROVED: the approval is first and chosen, and what
 * cannot work before it cannot be chosen. By the code: `remote pair` and adding a project or a root refuse without this
 * computer's remote keys (remote-cli.mjs needPaired, remote-settings.mjs applyRules), and no phone can be linked, so there
 * is no connection to list and nothing to pause. Modes is a local setting and Status only reads: both stay.
 * APPROVED: Link a phone first, and approving again stays (new keys). NOT KNOWN: every row can be chosen and the title says so.
 *
 * PART OF PREMIUM (owner, 2026-11-14; docs/remote-agents/ISSUER.md §12): when WorkTrust itself answered `premium_required`
 * (`access`, from api/cli/door: the switch on and the account Free), the first row is "Upgrade to Premium ›" and every other
 * row stays visible and cannot be chosen (the one disabled-row mechanism). Any other answer, or none, is the list as above.
 */
/**
 * PERMISSIONS › (0.11.22, owner 2026-11-23): what a phone may do here, in the order each needs the one before (read along,
 * steering, voice, answers aloud), a row whose prerequisite is off says what it needs and stays visible; then Modes ›.
 */
export const permissionItems = (switches, modes) => [...switches, modes, BACK];
export const modesRow = (act) => ({ label: "Modes ›", hint: "npx worktrust remote modes", info: "Agent modes a phone may start. This computer is the limit.", run: act.modes, ...(act.modesNote ? { note: { text: act.modesNote, tone: "dim" } } : {}) });

export function remoteItems(approved, paused, act = {}, access = null) {
  if (access === "premium_required") return [
    { label: "Upgrade to Premium ›", hint: act.upgradeHint ?? undefined, info: "Remote Agent is part of Premium. Opens the upgrade page.", run: act.upgrade },
    ...remoteItems(approved, paused).filter((item) => !item.back && !item.approve).map((item) => ({ label: item.label, hint: item.hint, info: item.info, disabled: true, quiet: "Part of Premium: upgrade first.", note: { text: "Premium", tone: "dim" } })),
    BACK,
  ];
  const wait = approved === false ? { disabled: true, quiet: "Approve this computer first.", note: { text: "not yet", tone: "dim" } } : {};
  const approve = { approve: true, label: approved ? "Approved ✓ · approve again ›" : "Approve this computer ›", hint: approved ? "npx worktrust remote app --repair" : "npx worktrust remote app | web", info: approved ? "Approve again: new keys, and linked phones link again." : "Needed once: your account allows steering this computer.", run: act.approve };
  const link = { label: "Link a phone (QR here)", hint: "npx worktrust remote pair", info: "Shows a QR that links a phone to this computer.", run: act.link, ...wait };
  return [
    ...(approved ? [link, approve] : [approve, link]),
    { label: "Projects ›", hint: "npx worktrust remote projects", info: "Folders a phone may steer an agent in.", run: act.projects, ...wait },
    { label: "Roots for new projects ›", hint: "npx worktrust remote roots", info: "Where a phone may open and create projects.", run: act.roots, ...wait },
    { label: "Connections ›", hint: "npx worktrust remote connections", info: "Phones and browsers linked here.", run: act.connections, ...wait },
    { label: paused ? "Resume" : "Pause", hint: `npx worktrust remote ${paused ? "resume" : "pause"}`, info: paused ? "Lets linked phones steer agents here again." : "Stops every phone until you resume. Links stay.", run: act.pause, confirm: pauseAsk(paused), ...wait },
    act.health ?? { label: "Status", hint: "npx worktrust remote status", info: "Shows if Remote Agent is on and what is linked. Only reads.", run: act.status }, // 0.11.22: heavy memory load takes Status's row (the same command)
    act.permissions ?? permissionsRow({}, undefined), // 0.11.22 (owner, 2026-11-23): read along, steering, voice, answers aloud and Modes in one row, so nine rows and every digit reach all
    BACK,
  ];
}

/**
 * "Upgrade to Premium ›" (owner, 2026-11-14): the address WorkTrust answered, opened in the browser AND printed, for a
 * terminal without one (SSH). No address: where to find it in words. The account is asked again at the next read.
 */
export async function showUpgrade(term, io, url) {
  term.write(url ? `\n  Upgrade to Premium: ${url}\n  It opens in your browser; on another device, open the address above.\n` : "\n  Upgrade to Premium in WorkTrust: Settings › Plan & billing.\n");
  if (url) io.openUrl?.(url);
  term.write(`  ${muted("Press any key for the menu.")}\n`);
  const k = await term.anyKey();
  return !(k.ctrl && k.name === "c");
}

/**
 * "Update the phone app (QR)" (CLI 0.11.27; owner, 2026-11-26; remote-phone-app.mjs): which phones run an older build, then
 * the QR of the update's link, or where to update in words; any key for the menu.
 */
export async function showPhoneUpdate(term, behind, { color = Boolean(process.stdout.isTTY) && !process.env.NO_COLOR } = {}) {
  term.write(`${updateLines(behind, { color }).join("\n")}\n\n  ${muted("Press any key for the menu.")}\n`);
  const k = await term.anyKey();
  return !(k.ctrl && k.name === "c");
}

/** Remote Agent ›. The rows are read again after every command, so an approval made here opens the other steps at once. */
export async function remoteMenu(term, io, header) {
  let state = (await io.state?.()) ?? null; // the account's answer (plan, remoteAccess, upgrade), read again after every command below
  const reading = { ...io, state: async () => (state = (await io.state?.()) ?? null) };
  const title = () => (state?.remoteAccess === "premium_required" ? "Remote Agent · part of Premium" : approval() === null ? "Remote Agent · its state could not be read" : "Remote Agent");
  return level(term, header, title, () => {
    const approved = approval(), paused = (() => { try { return loadSettings().paused !== null; } catch { return false; } })();
    // The two roads; one that leaves this computer approved returns to the list above, which now opens on Link a phone.
    const road = (which) => async () => ((await runShown(term, io, ["remote", which, ...(approved ? ["--repair"] : [])])) === false ? false : approved === false && approval() === true ? "back" : true);
    // 0.11.12: a linked phone with no reach chosen yet is said first, and its row opens the access step (awaitingRow).
    const waiting = state?.remoteAccess === "premium_required" ? null : awaitingName();
    // HEAVY MEMORY LOAD (remote-health.mjs): the remote service's newest sample, red, said in red in Status's row (0.11.22: it ran the same command); Enter shows the figures.
    const red = keptHealth()?.level === "red" ? [{ label: "Health: heavy memory load", note: { text: "red", tone: "red" }, hint: "npx worktrust remote status", info: `${HEALTH_REFUSAL}. New sessions wait; running ones continue. Enter shows the figures.`, run: () => runShown(term, io, ["remote", "status"]) }] : [];
    const settings = (() => { try { return loadSettings(); } catch { return {}; } })(), run = (args) => runShown(term, io, args);
    const modesNote = (() => { try { return { plan: "Manual, Plan", edit: "+ Edit", auto: "+ Auto" }[ceilingOf(allowedModes(loadSettings()))]; } catch { return null; } })(); // 0.11.14: the ceiling in a word
    const behind = (() => { try { return behindPhones(); } catch { return []; } })(), update = updateRow(behind, () => showPhoneUpdate(term, behind)); // CLI 0.11.27: a linked phone on an older build, said first after a waiting link
    return [...(waiting ? [awaitingRow(waiting, run)] : []), ...(update ? [update] : []), ...remoteItems(approved, paused, {
      health: red[0], permissions: permissionsRow(settings, () => level(term, header, "Permissions", () => permissionItems(switchItems((() => { try { return loadSettings(); } catch { return {}; } })(), run), modesRow({ modes: () => modesMenu(term, io, header), modesNote })), io)),
      approve: () => level(term, header, approved ? "Approve this computer again (new keys)" : "Approve this computer", () => [
        { label: "With the WorkTrust app", hint: `npx worktrust remote app${approved ? " --repair" : ""}`, info: "One QR: the app approves and links this phone.", run: road("app") },
        { label: "In the browser", hint: `npx worktrust remote web${approved ? " --repair" : ""}`, info: "Opens WorkTrust in your browser, where you approve.", run: road("web") },
        BACK,
      ], io),
      link: () => runShown(term, io, ["remote", "pair"]),
      projects: () => projectsMenu(term, io, header), roots: () => rootsMenu(term, io, header), connections: () => connectionsMenu(term, io, header),
      pause: () => runShown(term, io, ["remote", paused ? "resume" : "pause"]),
      status: () => runShown(term, io, ["remote", "status"]),
      upgrade: () => showUpgrade(term, io, state?.upgrade ?? null), upgradeHint: state?.upgrade ? String(state.upgrade).replace(/^https?:\/\//, "") : undefined,
    }, state?.remoteAccess ?? null)];
  }, reading);
}

const historyRows = (term, io) => [
    { label: "Sessions on this computer", hint: "npx worktrust history", info: "Sessions your AI apps still hold. Shows a plan, asks first.", run: () => runShown(term, io, ["history"]) },
    { label: "Your local archive", hint: "npx worktrust history --from-archive", info: "Sessions your apps deleted, from your archive. Asks first.", run: () => runShown(term, io, ["history", "--from-archive"]) },
    { label: "A ChatGPT or Claude export…", hint: "npx worktrust history --export <path>", info: "Asks for its path. Reconstructed hours, never verified.", run: async () => { const path = await typed(term, "The export's path (the zip, its folder or conversations.json):", join(homedir(), "Downloads")); term.enter(); return path ? runShown(term, io, ["history", "--export", path]) : true; } },
    { label: "A copied session folder…", hint: "npx worktrust history --from-folder <dir>", info: "Your copy of a session folder. Reconstructed, not verified.", run: async () => { const path = await chooseFolder(term); term.enter(); return path ? runShown(term, io, ["history", "--from-folder", path]) : true; } },
    BACK,
  ];
export const historyMenu = (term, io, header) => level(term, header, "Import earlier history", () => historyRows(term, io));

const preserveRows = (term, io) => [
    { label: "How long each AI app keeps sessions", hint: "npx worktrust preserve", info: "Shows how long each AI app keeps sessions. Changes nothing.", run: () => runShown(term, io, ["preserve"]) },
    { label: "Keep them longer", hint: "npx worktrust preserve --apply", info: "Keeps sessions longer. Asks per change, backs up first.", run: () => runShown(term, io, ["preserve", "--apply"]) },
    { label: "Make a local archive", hint: "npx worktrust preserve --archive", info: "Writes a metadata-only record to ~/AI-Evidence. Not sent.", run: () => runShown(term, io, ["preserve", "--archive"]) },
    { label: "Check the archive", hint: "npx worktrust preserve --verify", info: "Checks that record's hashes and signatures. It only reads.", run: () => runShown(term, io, ["preserve", "--verify"]) },
    { label: "Count hours from the archive", hint: "npx worktrust preserve --summary", info: "Counts hours and tokens from that record. It only reads.", run: () => runShown(term, io, ["preserve", "--summary"]) },
    BACK,
  ];
export const preserveMenu = (term, io, header) => level(term, header, "Preserve evidence", () => preserveRows(term, io));

/**
 * EVERY MENU'S ROWS, FOR THE SEARCH (0.11.21, cli-menu-search.mjs): the rows each level draws, with where they live, read when a
 * search runs (so their state is now). A row runs as it does in its own menu: the same command. Connections are left out (their
 * rows are the devices of the moment, and each opens a step of its own).
 */
export function menuIndex(term, io, header) {
  const at = (where, rows) => rows.filter((row) => !row.back).map((row) => ({ ...row, where }));
  let settings = {};
  try { settings = loadSettings(); } catch { settings = {}; }
  const run = (args) => runShown(term, io, args);
  return [
    ...at("Remote Agent › Permissions", switchItems(settings, run)),
    ...at("Remote Agent", [{ label: "Link a phone (QR here)", hint: "npx worktrust remote pair", info: "Shows a QR that links a phone to this computer.", run: () => run(["remote", "pair"]) }, { label: "Status of Remote Agent", hint: "npx worktrust remote status", info: "Shows if Remote Agent is on and what is linked. Only reads.", run: () => run(["remote", "status"]) }]),
    ...at("Remote Agent › Roots", rootsRows(term, io, header)),
    ...at("Import earlier history", historyRows(term, io)),
    ...at("Preserve evidence", preserveRows(term, io)),
  ];
}
