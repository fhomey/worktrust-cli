# WorkTrust CLI

WorkTrust CLI measures the work you do with AI on your own computer and lets you steer your own coding agents from your phone.

It counts hours, tokens and tools for your verified AI Passport on [WorkTrust](https://worktrust.io): counts and metadata,
never your prompts, your code or what the AI answered. With Remote Agent, the same tool lets your phone start and follow
the coding agents on this computer, inside the folders you allow. You run every command yourself, each one shows its plan
first, and nothing is sent before you say yes.

## What you can do

- **Measure.** A session hook measures each stretch of AI work on this computer: when, how long, which model, how many tokens, what kind of work.
- **Import history.** Send the earlier sessions your AI apps still hold, or a ChatGPT or Claude data export, as earlier work. It is shown with its origin, never as verified hours.
- **Preserve evidence.** See how long each AI app keeps its sessions, keep them longer, and write a local, hash-chained record of your measured days. This needs no account and sends nothing.
- **Remote Agent.** Start, follow and answer the coding agents on this computer from your phone or a browser, end-to-end sealed.
- **Connect your AI apps.** Give the AI apps on this computer the WorkTrust door, so your AI can log a finished piece of work. Or run hours only, without the door.

What WorkTrust shows is observed work within a stated period. The scores built on it are not calibrated and are not a
hiring instrument.

## Install and first run

```sh
npx -y worktrust
```

In your own terminal this opens the menu. On a computer that is not connected yet it is a short one: Connect this
computer, Preserve evidence, Help. Connect shows the plan, asks, and you approve the computer in your browser with your
own account and second factor; the moment that succeeds, the full menu is there. The `-y` answers npm's own question in
advance: without it npm may ask `Ok to proceed?` before WorkTrust starts.

**With Python instead.** The Python package runs the same CLI and brings its own Node, so it needs no Node on the computer:

```sh
pipx run worktrust
pip install worktrust
```

**What you need.**

- Node 18 or later for measuring, importing and preserving. Reading the AI apps that keep their sessions in a database needs Node 22.5 or later.
- Node 22.4 or later for Remote Agent, or the Python package.
- macOS, Linux or Windows. Every release is built and tested on six platforms: Linux x64 and arm64, macOS on Intel and Apple silicon, Windows x64 and arm64.
- A WorkTrust account for everything except `preserve`, which is for everyone.

**If your Node is older than 22.4.** Measuring keeps working. A `remote` command, and the menu's Remote Agent item, say so
and show the ways forward, each with its exact command:

1. Update this computer's Node. The CLI reads how Node is installed here and shows the matching command (nvm, fnm, Volta,
   asdf, Homebrew, winget, or the installer from nodejs.org). For fnm, Volta and Homebrew it can run the command for you,
   after showing it and only when you type yes. It never uses sudo and never runs a system package manager. Afterwards it
   runs `npx worktrust update`, so the session hook and your AI apps point at the new Node, and continues what you started.
2. Use the Python package, which brings its own Node: `pipx run worktrust remote app`.

Without a terminal nothing is asked and nothing runs: the same text is printed and the command ends with a failure code.

**Update.** `npx -y worktrust@latest update` brings this computer's hook and AI-app doors to the newest version. Your key and
pairing stay. On a computer that is already on that version, with nothing waiting, it says so and changes nothing;
`update --force` sets everything up again all the same.

**Stop.** `npx worktrust disconnect` takes WorkTrust out of every AI app here and removes the key. Then revoke the
computer in WorkTrust under Sources, Devices. More under [Undo](#undo).

## The menu

On a computer that is not connected yet:

```
  WorkTrust CLI 0.11.9
  Not connected yet

>  1  Connect this computer    npx worktrust connect
   2  Preserve evidence ›      npx worktrust preserve …
   3  Help · all commands      npx worktrust help
   4  Quit                     q

  Asks before it writes; your browser signs in to WorkTrust.

  ↑/↓ move · Enter open · Esc quit · 1-9 jump
```

Once it is connected (80 columns; on a wide terminal each row's sentence stands on the row itself, as a fourth column):

```
  WorkTrust CLI 0.11.9
  Account        you@example.com
  This computer  imac · connected since 2026-11-03
  Remote Agent   approved, 2 connections
  Sharing        session hook on · AI apps on (7) · Remote Agent approved

   1  Update WorkTrust · up to date (0.11.9)   npx worktrust update
>  2  Check this computer                      npx worktrust
   3  Remote Agent ›                           npx worktrust remote …
   4  Import earlier history ›                 npx worktrust history …
   5  Preserve evidence ›                      npx worktrust preserve …
   6  Sharing ›                                npx worktrust mcp …
   7  Status                                   npx worktrust status
   8  Disconnect this computer                 npx worktrust disconnect
   9  Help · all commands                      npx worktrust help
      Quit                                     q

  Shows what is coupled here and finishes what waits.

  ↑/↓ move · Enter open · Esc quit · 1-9 jump
```

One row per item, and no row moves when you move. A row that cannot be chosen is dimmed and says why in words: Update
when there is nothing to update, and most of Remote Agent until this computer is approved for it. The summary above the
menu comes from this computer's own files; it never shows the key. Sharing › says what this computer sends and holds the
switches that exist: `mcp off | on` and Remote Agent's pause. Remote Agent › Connections lists every linked phone and
browser, and disconnecting one runs `remote disconnect` with its typed confirmation. Esc quits at the top and goes back
one level below it.

Every item shows the command it runs, so you can type it next time. Without a terminal (a script, a hook, the MCP door)
there is no menu and nothing waits for a key.

## Commands

| Command | What it does |
|---|---|
| `npx worktrust` | In your terminal: the menu. Without a terminal, or with any option: connects this computer (shows the plan, asks, you approve in your browser), or shows what is connected. |
| `npx worktrust connect` | Connects this computer again, also when it is already connected. Asks first. |
| `npx worktrust update` | Brings this computer onto the newest CLI: same key, no new pairing. Something new is asked about. Already there with nothing waiting: says so and changes nothing (`--force` sets it up again). |
| `npx worktrust history` | Sends this computer's earlier sessions as history. `--rebuild` measures them again, `--export <path>` reads a ChatGPT or Claude export, `--from-archive` and `--from-folder <dir>` read your own copies. Always shows the plan and asks. |
| `npx worktrust disconnect` | Takes WorkTrust out of every AI app here. Asks first. |
| `npx worktrust status` | Shows what is connected here. It only reads. |
| `npx worktrust project` | Sets a folder's mode: exclude (nothing read), confidential (hours and tokens count; no name, branch, path or commit is sent) or normal. `project list` shows them. |
| `npx worktrust remote` | Remote Agent: `app` or `web` approve this computer, `pair` links a phone, then `status`, `pause`, `resume`, `disable`, `connections`, `disconnect`, `projects`, `roots` and `modes`. |
| `npx worktrust mcp off` | Hours only: the WorkTrust door out of every AI app here. The session hook keeps measuring. |
| `npx worktrust mcp on` | The door back in, so your AI can log finished work. |
| `npx worktrust mcp` | Says which of the two this computer is in. |
| `npx worktrust protect-key` | After an update: moves the key's protection into the operating system's vault. Asks first. |
| `npx worktrust orchestration report --file recording.jsonl` | Inspects a local recording of agent metadata. Sends nothing. |
| `npx worktrust mod` | The WorkTrust mod for Claude Code: what it counts and whether it is on. `mod install` turns it on, `mod remove` turns it off. |
| `npx worktrust git` | Sends your own commits as counts and kinds, measured on this computer: never a file name, a message, code or the commit's id. Asks once. |
| `npx worktrust preserve` | Keeps your AI history: the report, then `--apply` (keep sessions longer), `--archive`, `--verify` and `--summary` for the local record. For everyone, with or without an account. |

`npx worktrust help` prints these with every option. `--dry-run` shows a plan and stops; `--no-color` or `NO_COLOR` turns
colours off.

## How it works

1. **A plan, then a question.** A command lists what it found and what it would change, and asks. Nothing is written or sent before you answer.
2. **You approve the computer in your browser**, signed in to WorkTrust with your second factor. The terminal never sees a password and cannot choose an account.
3. **A session hook measures** each stretch of AI work when a session ends, and sends the measurement.

**What it reads.** Your AI apps' own session files on this computer, to take clocks, token counts, model names and the
kind of work from them.

**What it sends.** Per stretch of work: its timeline, token counts, the model's name, the kind of work and closed
technology keywords. For a repository on GitHub, GitLab or Bitbucket also its owner/name and the hashes of the commits
made; for any other repository a code that names nothing. The full list is in
[What it reads, writes and sends](#what-it-reads-writes-and-sends).

**What it never sends.** Your prompts, the AI's answers, your code, file contents or file paths.

**Where the key lives.** In a private file on this computer, and after `protect-key` wrapped by the operating system's
vault (Keychain, Credential Manager or the Secret Service). See [Credential protection](#credential-protection).

**What you can check.** The package has no dependencies and is published with provenance. Each release is signed, and the
launcher checks the package's files against that signature before it starts. A signature shows that a release is ours. It
does not prove that work happened: see [Why you can check it](#why-you-can-check-it) and
[Release signatures and the limits of verification](#release-signatures-and-the-limits-of-verification).

The long versions start at [What happens](#what-happens).

## Remote Agent

Remote Agent lets your phone, or a browser, steer the coding agents on this computer. It is off until you turn it on at
this keyboard, and it has its own key, apart from the measuring key.

**Pairing in three steps.**

1. `npx worktrust remote app` shows a QR code here. You scan it with the WorkTrust app and approve this computer with your authenticator. `npx worktrust remote web` does the same in your browser.
2. `npx worktrust remote projects add <folder>` allows a folder. A phone can start an agent only in folders you allowed here.
3. `npx worktrust remote pair` shows a QR code for a phone: five minutes, one phone, once.

**What a phone can do.** Start an agent in an allowed folder, follow it, answer it, and approve by class: a file edit
inside the project, a test, build or lint command from a short reviewed list, and a message an agent wants to send, shown
whole.

**What a phone cannot do.** Install from the network, push, deploy, delete outside the project, read secret files or
grant an "always allow". Those are decided at this keyboard or not at all.

**Modes with a ceiling.** Manual and Plan are always there. Edit automatically and Auto exist only once you allow them
here with `remote modes allow`. The computer refuses a mode above what you allowed.

**Sealed end to end.** The computer holds one outbound connection and opens no port. Messages are sealed between your
phone and this computer; the relay passes them on and cannot read a prompt, a file, a path, an output or a model name.

A session steered from a phone is recorded as an agent run. It never counts as your AI Hours.

The details: [Remote Agent: steer this computer's agents](#remote-agent-steer-this-computers-agents-from-your-phone-or-browser-npx-worktrust-remote).

## The phone app

The WorkTrust app is coming to the App Store and Google Play. It is in TestFlight testing now, and there is no date yet.
News is on [worktrust.io](https://worktrust.io). Until then, Remote Agent also works from a browser at app.worktrust.io.

## Supported AI apps and agents

- **Measured** (their sessions are read): Claude Code, Codex, Gemini CLI, Antigravity, Cursor, Copilot in VS Code, Hermes Agent, Goose, OpenCode, OpenClaw, the Ollama app and Open WebUI.
- **Connected** (they can get the WorkTrust door): Claude Code, Codex CLI, Gemini CLI, Cursor, VS Code (Copilot agent mode), Windsurf, Mistral Vibe, Antigravity, Grok Build, Zed, Cline, Goose, OpenCode and OpenClaw.
- **Steered by Remote Agent:** Claude Code, Codex, OpenCode and a terminal session.

Only what is on this computer is found. Which sessions can be read depends on the format each app keeps.

## Privacy and security

- Counts and metadata only. No prompt, answer, code or file content leaves this computer.
- Nothing is written or sent before you say yes, and `--dry-run` shows any plan without doing it.
- An AI agent cannot run these commands for you: they stop in an agent's shell. See [AGENTS.md](AGENTS.md).
- The key stays on this computer, and you can revoke it in WorkTrust at any time.
- A signature proves a release is ours and that a key was present. It is not independent proof of the work.

The threat model and the known limits are in [SECURITY.md](SECURITY.md). To report a vulnerability, write to
**hello@worktrust.io** with "security" in the subject. Please keep credentials, transcripts and account data out of
public issues.

## Links

- [worktrust.io](https://worktrust.io): the site. [worktrust.io/preserve](https://worktrust.io/preserve): keeping your history, with or without an account.
- [What changed in each version](CHANGELOG.md)
- [SECURITY.md](SECURITY.md) and [AGENTS.md](AGENTS.md)
- [Licence](#licence): the WorkTrust CLI Licence, in [LICENSE](LICENSE)
- The reference below: everything above, in full.

## Reference

The long versions of what is above. The headings are the ones other pages link to.

## The npm package and the Python package, in full

**The official npm package** is `worktrust`, published by the npm account **worktrustio** with
provenance from this repository (github.com/fhomey/worktrust-cli). Check it on npmjs.com before you run
it; a package of another name or from another publisher is not ours. Use the complete package:
individual support scripts are no longer downloaded and executed during setup. The live 0.10.25
release includes signed startup checks; 0.10.21 does not include this guard.

**Python tool runners:** this repository also builds `worktrust` for `uvx` and `pipx` from the
same measurement modules. Native wheels (0.10.13+) include a pinned official Node runtime,
so that route needs no separate Node/npm installation. See the
[Python distribution](https://github.com/fhomey/worktrust-cli/tree/main/python) for supported
platforms and installation commands, and the official [PyPI project](https://pypi.org/project/worktrust/)
for published versions. npm and Python versions are checked together.

```sh
uvx worktrust@latest preserve
pipx run --no-cache worktrust preserve
```

Omit `preserve` to connect your computer. These runners install and invoke the same CLI;
they do not automatically instrument Python applications or measure different activity.

Connecting through the Python package installs the runtime and engine in an immutable directory
under `~/.worktrust/installations/`; client hooks use that persistent path, so clearing a tool-runner
cache does not break the coupling. Updates retain older installations for running clients.
Run `worktrust disconnect` before removing an installed Python tool if you also want to remove its
WorkTrust coupling. Disconnect removes the key and client wiring; it leaves runtime files in place.

**Agent observations (requires 0.10.14+):** the optional Python
`worktrust_cli.telemetry` SDK lets an application explicitly record parent/child runs, its own
token counters, token budgets, checks and security events in a local file. The shared engine
inspects it with `worktrust orchestration report --file agent-events.jsonl`, without uploading.
The private platform import is Sources → Agent teams when that platform change is deployed.
These are application reports, not human hours or independently verified outcomes. Installing
through npm, uvx or pipx alone does not instrument agents. See the Python README for the opt-in
SDK, fixed metadata fields, consent and local deletion. Install `worktrust>=0.10.14` in the
agent application's own Python environment to import the SDK; a uvx/pipx tool environment
is separate. Check the registry for availability: a GitHub release awaiting approval is not
a completed npm or PyPI publication.

**No account? Keep your history anyway.** Claude Code and Gemini CLI delete their sessions after 30
days by default, and a deleted session can never be measured again. `npx worktrust@latest preserve` shows what
each AI app on this computer keeps, keeps it longer on your yes, and writes a local, metadata-only
record. It needs no account and opens no network connection: it stays on this computer until you
yourself run a command that sends. See [Keep your history](#keep-your-history).


**For AI agents:** read [AGENTS.md](AGENTS.md). An agent does not run this CLI's commands for a person (they stop in an agent's shell), does not report work it did not see, and does not rebuild, fork or strip it.

## What happens

1. **A plan, then a question.** The command lists every AI app it found on this computer and the
   file each one gets changed, then asks `Continue? [Y/n]`. Nothing is written or sent before you
   answer. `--dry-run` shows the plan and stops.
2. **Approve this computer in your browser.** WorkTrust opens; you see this computer's name, its
   system and the AI apps that will get the WorkTrust door, and approve it, signed in with your own account and second factor. That decides which
   WorkTrust account the computer belongs to: the terminal never sees a password and cannot choose
   an account. Nothing is typed: the browser is sent back to this computer (127.0.0.1), where the
   terminal waits for one answer and exchanges it with a secret only it holds (PKCE). A link
   forwarded to someone else approves nothing they can collect.
   Without a browser (over SSH, or `--device`), the terminal shows a code that you type yourself at
   app.worktrust.io/connect/computer on another device.
3. **The terminal finishes by itself.** It keeps the key in its private file and gives every
   AI app here the WorkTrust door, then installs the session hook. Quit your AI apps and open them
   again.
4. **Earlier work only if you say yes.** It counts your AI apps' sessions already on
   this computer and asks `Send these as history? [y/N]`. Enter sends nothing. What goes is hours
   and tokens per day, never text, and WorkTrust shows it as earlier work, never as verified hours.
   Nothing from before the coupling is ever sent without that yes: the session hook starts at the
   moment of coupling. Beside the seconds, each day says what they were (the model answering, tools
   running, your own turns, pauses) and what the session's subagents did on their own clocks, as
   counts; a subagent's hour is shown as an agent-hour and never as one of yours.
5. **Codex only if you say yes.** With Codex on this computer it asks `Let Codex wake the session
   hook? [y/N]` and, on a yes, sets the one `notify` line in `~/.codex/config.toml` (the file is
   kept as `config.toml.worktrust-backup` first). Another program's `notify` is never replaced.
6. **Antigravity only if you say yes.** With Google Antigravity on this computer it asks `Let
   Antigravity wake the session hook? [y/N]` and, on a yes, adds one hook named `worktrust` with a
   single `Stop` command to `~/.gemini/config/hooks.json` (kept as `hooks.json.worktrust-backup`
   first). Other hooks in that file stay as they are. Antigravity records no token counts, so its
   sessions arrive with durations and turn counts only.
7. **Hermes Agent with the other apps.** With Hermes on this computer (`~/.hermes`, and every profile
   under `~/.hermes/profiles`) its `config.yaml` gets the WorkTrust entry under `mcp_servers` and one
   `on_session_end` hook that wakes the session hook; Hermes itself asks once before it runs a new
   hook. A file that writes those sections inline is left as it is. The session hook reads Hermes's
   own `state.db`: clocks, roles, the model and the session's token totals, never a message. A chat
   app (Telegram, WhatsApp, Slack …) is sent as work steered from elsewhere; a subagent's, a
   scheduled job's or a board task's session is not counted. Needs Node 22.5 or newer.
8. **Goose, OpenCode and OpenClaw the same way.** Goose gets the entry under `extensions` in
   `~/.config/goose/config.yaml` and one plugin folder, `~/.agents/plugins/worktrust`, whose
   SessionEnd hook wakes the session hook. OpenCode gets it under `mcp` in
   `~/.config/opencode/opencode.json` (a file with comments is left as it is) and one plugin file,
   `plugin/worktrust.js`, that wakes the session hook when a session goes idle. OpenClaw is coupled
   through its own `openclaw mcp set` (and `openclaw mcp unset` on disconnect); without that command
   on this computer it is printed for you to run. Each is read from its own session database, the
   same way as Hermes: clocks, roles, models and token counts, never a message. OpenClaw's Talk
   sessions are sent as voice, its chat-app sessions as remote; subagents and scheduled runs are
   not counted.
9. **Cursor and GitHub Copilot in VS Code, read in place.** Cursor's chats are read from its own database
   (`User/globalStorage/state.vscdb`), each message's type, clock, model and token counts through SQLite's own
   `json_extract`, never the text. Copilot's are read from VS Code's `chatSessions` files: each request's two clocks
   (asked, answered), its model and its token counts; the messages and responses are parsed with the file and never
   kept or sent. Neither app runs a hook WorkTrust can give it, so the WorkTrust door, which both start when they
   open, starts the session hook in the background, at most once an hour.
10. **Gemini CLI, read in place (0.10.35).** Its sessions are the files Gemini CLI records under
   `~/.gemini/tmp/<project>/chats/`: each message's role and clock, the model, the token counts and each tool
   call's name and status, never a message, a thought or a tool's output. Subagent sessions are not counted.

```
npx worktrust@latest history       send this computer's earlier sessions later (asks first)
npx worktrust@latest history --rebuild   re-measure them with the current rules; WorkTrust replaces this computer's
                                   earlier lines day by day, never counting a day twice (shows the plan, asks first)
npx worktrust@latest history --from-archive [dir]   send what your local archive holds of sessions your AI apps
                                   already deleted, marked as from your archive: a day this computer's key signed as
                                   measured, every other day as reconstructed (shows the plan, asks first)
npx worktrust@latest history --export <path>   a ChatGPT or Claude data export (the zip, its folder, conversations.json, a conversations part or the manifest)
                                   as history: hours reconstructed from its clocks, never verified (shows the plan, asks first)
npx worktrust@latest history --from-folder <dir>   your own copy of an AI app's session folder (a backed-up ~/.claude/projects,
                                   ~/.codex/sessions): the days this computer's sessions lack, reconstructed (asks first)
npx worktrust codex         let Codex wake the session hook (asks first)
npx worktrust antigravity   let Antigravity wake the session hook (asks first)
npx worktrust@latest status        what is coupled here
npx worktrust mcp off       hours only: the WorkTrust door out of every AI app here, so nothing of WorkTrust loads into
                            your sessions; the session hook keeps measuring your hours, and update leaves the door out
npx worktrust mcp on        the door back in: your AI may also log finished work (about 40 tokens per session); nothing
                            from the time it was off is sent
npx worktrust mcp           which of the two this computer is in (and whether a claude.ai WorkTrust connector also loads)
npx worktrust@latest disconnect    take it out again (shows the plan, asks first)
```

**Hours only, or also work lines.** Your passport's hours come from the session hook, which reads your AI apps' own
session files; it needs no WorkTrust door in the apps. The door adds one thing: your AI's own `log_work` line at the end
of a piece of work, and for that its short instruction (and, in apps that load every tool up front, its tool
definitions) is loaded into every session. `connect` asks which you want (Enter keeps the door, as before); an update
asks once on a computer coupled before. The choice lives in `~/.worktrust/door.json` (0600). The hook tells WorkTrust
the mode beside the CLI version, one word, so Sources › Devices can show "work lines off" instead of an unexplained gap.
If Claude Code has also been connected to a WorkTrust connector of your claude.ai account, the CLI says so once: keep
the local door (it carries this computer's key) and remove the other at claude.ai/customize/connectors.

## Keep your history

**Why.** Your AI apps decide how long your history lives, and several delete it on their own schedule:

| App | Kept by default | `preserve --apply` |
|---|---|---|
| Claude Code | 30 days, then deleted without notice | sets `cleanupPeriodDays` to 3650 |
| Gemini CLI | 30 days | turns `general.sessionRetention` off |
| Hermes Agent | 90 days after a session ended | prints the line to add (`sessions.auto_prune: false`) |
| Codex CLI | no deletion documented | nothing to change |
| Cursor, Copilot Chat, OpenCode, Goose, LM Studio | not documented | left alone |

(From each vendor's own documentation, checked 6 October 2026. Copilot Chat also syncs its sessions
to GitHub by default: `chat.sessionSync.enabled`.) A deleted session is a day of work that can never
be shown again, by WorkTrust or by anyone.

**Local, and yours.** `preserve` works on this computer only. It needs no WorkTrust account and no
key, and it opens no network connection; `check-cli-package` refuses the package if `preserve.mjs` so
much as imports a network module. What it keeps stays here **until you yourself run a command that
sends**: `npx worktrust` to couple this computer, then `npx worktrust@latest history`, which shows what it
would send and asks `[y/N]` first. Without those two, nothing ever leaves.

```
npx worktrust@latest preserve                  every step: the report, then asks to keep the settings and a local archive
npx worktrust@latest preserve --apply          the settings step only: asks [y/N] per change, backs the file up first
npx worktrust@latest preserve --archive [dir]  a local record of the measured days (default ~/AI-Evidence)
npx worktrust@latest preserve --verify [dir]   check that record: was anything changed afterwards?
npx worktrust@latest preserve --summary [dir]  hours, tokens per model, cache share and parallel sessions, from that record
```

**Always the newest, from any terminal or agent.** Run it as `npx worktrust@latest …`: npx then asks npm for the
newest version every time, where a bare `npx worktrust` may reuse a copy npm cached earlier. Which terminal or AI
agent runs it makes no difference: `preserve` writes to your own user's places (the apps' settings files and
`~/AI-Evidence`), so every terminal and agent on this computer under your user reaches the same archive, and lines
from different versions sit side by side, each naming the version that measured it. Another user on the same computer
gets an archive of their own. A coupled computer's session hook runs from its own copy in `~/.worktrust` and changes
with `npx -y worktrust@latest update`, or (from 0.10.37, installed from npm) when you turn CLI active back on for that
computer in WorkTrust › Sources: it then updates itself, verified, the next time WorkTrust runs there (SECURITY.md,
"Updating itself when you turn it on"). The WorkTrust app says when a newer version is out.

**One command walks it all.** `npx worktrust@latest preserve` shows the report, asks `Keep these settings? [y/N]`
(then does what `--apply` does), asks `Keep a local archive in ~/AI-Evidence? [y/N]` (then does what `--archive`
does; an archive already there is simply added to), and with an archive prints its check and its summary. Enter is
No. Without a terminal, and without `--yes`, it changes nothing. The flags each do one step, for scripts.

**Later, into WorkTrust, if you want.** Because `--apply` keeps the apps' own session files, coupling
this computer months from now still finds them: `npx worktrust@latest history` measures them the same way the
live hook does, and they arrive as history, labelled as such, never as work WorkTrust watched happen.
The archive is a plain, documented format made for the same purpose; importing it directly is planned,
not built.

**What `--archive` keeps, per AI app per day.** The same measurement the session hook makes, and
nothing it does not:

| Field | What it is |
|---|---|
| `client` | the AI app (`claude`, `codex`, `cursor`, `copilot`, `hermes` …) |
| `day`, `started_at`, `ended_at` | the day, and when the measured stretch began and ended |
| `seconds` | measured time: every gap between stamped events up to five minutes |
| `model_seconds`, `tool_seconds`, `human_seconds`, `idle_seconds` | what those seconds were: the model answering, tools or an agent run, your own turns, and what a cap cut off |
| `tokens_in`, `tokens_out`, `tokens_cache_read`, `tokens_cache_write` | token counts, when the app records them (one answer counted once, however many lines the app wrote it in) |
| `agent_runs`, `agent_seconds`, `agent_peak` | subagents: how many ran, their own time, the most open at once (never added to `seconds`) |
| `interrupts`, `steers` | how often you stopped the agent mid-answer, and how often your message arrived while it was still mid-task (counts, never the words) |
| `utc_offset` | your computer's offset from UTC when the stretch began, such as +02:00, so a working day reads in your own local time |
| `model` | the model's name as the app reported it |
| `kind`, `layer`, `layers` | the kind of work (built, changed, researched) and the area it touched (front end, back end, data …), as the session hook names them |
| `exchanges` | how many times you and the model took turns |
| `commits` | the hashes of commits made in the stretch, never a message: what ties AI time to work in the repository |
| `steered_from` | `remote` when the session ran over SSH |
| `duration_basis`, `token_basis`, `turn_basis` | how the seconds, tokens and turns were measured |
| `project` | a one-way hash of the project's name, keyed with this computer's own secret (`~/.worktrust/archive-salt`, never in the archive) so a guessed name cannot be tested: which days belong together, never which project |
| `stretch_ref` | a hash of the session's id and the day, so a stretch is archived once |
| `device_id`, `profile_id` | which computer and which user profile on it, as one-way hashes (the machine's own id never appears) |
| `signals`, `analyzer_version` | the behaviour signals of that stretch as keys and counts from the local counter's rubric (framing, steering, verification, recovery), and the rubric's version; derived on this computer from your own turns, never a word of them (0.7.0) |
| `verification`, `delivery` | per kind of check run in the stretch (test, typecheck, lint, build, the project's gate, CI) how many ran and how many failed; per delivery step (commit, PR, push, deploy) how many succeeded, and whether a check had passed before the first; named from each command on this computer, never the command itself (0.7.1) |
| `recovery` | of the tool calls that failed in the stretch, how many a later call of the same kind recovered, the middle time that took, how many were retried unchanged and how many with a different approach; inputs compared on this computer by digest, never kept (0.7.2) |
| `delegation` | the longest and the middle chain of actions the agent took on its own between your turns (or your stopping it), and how often it stopped to ask you a question or to have a plan approved (0.7.3) |
| `context`, `routing` | how often the context was compacted and which context commands you used (compact, clear, resume, context, model, memory; never a command of your own), how many models answered and how often the model changed (0.7.4) |
| `steering` | the moments you stepped in while the agent worked (stopping it, or a message mid-task), how many changed what the agent did next, and how many were followed by a passing check (0.7.5) |
| `tools`, `complexity` | how many different tools the agent used, and the stretch's task complexity C1 to C5 by the rule complexity/1 (points for layers touched, tools, subagents, duration, a recovered failure, kinds of check and a delivery; the rule is in stretch-evidence.mjs), with its points and the rule's version (0.7.6) |
| `oversight`, `planning`, `changes` | how often you refused an action or a plan the agent proposed, and how often a guard (the client's safety layer) refused one; how often the agent wrote its to-do list, the most items, and of the last list how many were done (never what they say); how many files the stretch's commits changed and how many of them tests (never a path) (0.8.1) |
| `supplements` | a supplement line: when a newer CLI measures more of a stretch already archived, the new fields go into a line of their own that names that stretch; nothing earlier is rewritten, and the chain and the day's root cover it (0.8.2) |
| `evidence` (sent) | the same derived record now also travels with each stretch to WorkTrust, kinds and counts only, and `npx worktrust status` shows what this computer measured in the last thirty days (0.8.3) |
| `unconfirmed` | checks the stretch ran whose outcome no reader could see (Codex's code mode prints no exit code; a background terminal), per kind: counted, never as a pass (0.8.5) |
| `autonomy`, `authorship` | the permission mode the AI app ran in, on one scale (ask, edits, plan, auto, full), how often it changed and the turns in plan mode; of the stretch's commits, how many name an AI as co-author (the trailer is read here, its names never leave) (0.8.7) |
| `framing`, `quality`, `risk`, `tool_mix`, `reads`, `context_files` | how the work was framed (your turns before the agent's first action, a plan first or not), checked (a check passing after the last change, the failures before a check passed, the change looked at before delivery; security scans count as checks), risked (destructive commands proposed, refused, run), which kinds of tools were used, files read again unchanged, and which of the AI app's own context files (instructions, skills, agents, commands, settings, MCP) the commits changed; kinds and counts only (0.8.8) |
| `quality.change_blocks`, `checked_blocks`, `rework_cycles`, `stage` | how many change blocks (edits with no check between them) a check followed, how often a failed check was followed by another change before it ran again (rework), and the furthest step the stretch reached here: attempted, verified, committed, pushed, pr, deployed; counts and one word only (0.8.9) |
| `timing` | how fast the stretch moved: seconds from your first turn to the first action and from the first change to the first check, the actions and seconds from a failure to the change that answered it, the calls from a failed check to it passing, and the calls back to work after a compaction; medians from the order and the clocks, never what was said (0.9.0) |
| `hygiene` | risk and hygiene: rollbacks, privileged commands (sudo, a forced push), hooks skipped (--no-verify), secrets touched (a .env printed, a private key read), destructive commands and how many a look or a check came before, the answer to a guard (retried, changed, stopped), and whether a check followed delivery; counts only, never the command or the path (0.9.1) |
| `route` | the route the work took: branches made, pushes straight to the default branch, and of the stretch's own commits those over twenty files, a fix that followed another, those naming an issue, and the changed CI, script and docs files; counts only, never a subject, a branch name or a path (0.9.2) |
| `adaptation` | evidence and adaptation: what the stretch read by kind (docs, tests, logs, config, source, the web), a plan written again after a failure, a model changed right after a failure, two or more agents whose work a check met, and outages (overloaded, rate-limited, timed out) and how many the work went on past; counts only, never a path or a message (0.9.3) |
| `reach` | the work's reach and its plan: commands on infrastructure (terraform, kubectl, helm, docker), data (psql, sqlite, bq, dbt) and cloud (aws, gcloud, az, supabase, vercel); plan or roadmap documents written and whether one came before the first code change; reviews approved, sent back or commented and issues opened or closed from the terminal; counts and one flag, never a command, a file name or a path (0.9.4) |
| `hygiene.secrets` | counts a secret touched only when a file that holds one (a .env, a private key, credentials.json, .aws/credentials) is shown or copied (cat, head, tail, base64, cp); a search for a word (grep, sed, awk) is no read (0.9.5) |
| `hygiene.secrets` | counts a secret shown only when a reader (cat, head, tail, base64, cp) takes the file as its own argument; a command that uses a .env and reads its output, and a template (.env.example), are no secret shown (0.9.6) |
| `outcomes` | outcomes of the steps: per kind of check whether its first run passed, delivery attempts that failed, a model change and a new plan after a failure each followed by a passing check; and a check whose output goes through a pipe is read from its output's words (an error fails, a pass passes, a silent type check or lint passes, anything else is unconfirmed), never from the pipe's exit code (0.9.8) |
| `retrieval` | retrieval and grounding: searches (grep, rg, find, Grep, Glob, a web search, an MCP search tool), the same search again, a search followed by a read or a change (found) or by another search (again), searches before the first change and right after a failure, and deliveries with docs, tests or a search since the last change (grounded); counts only, nothing searched is kept (0.9.9) |
| `window` | the context window, from the token counts the AI app writes beside each answer (input plus cached, once per message): the peak a turn carried, the turns over 100k, 200k and 500k, the growth from the first quarter of answers to the last, and compactions near the peak; counts only, nothing of what the context held (0.10.0) |
| `review` | reviewing the agent: reviews while it worked, the middle interval, subagent runs reviewed, and what a review led to (a change of course, a change, a check); counts only (0.10.1) |
| `live` | counted inside Claude Code by the WorkTrust mod, only when you turned it on (`worktrust mod install`, 0.10.15): permission questions put to you and how many you answered yes or no (not in auto mode, where a classifier answers), model requests per effort level, how many models answered and requests sent to another model, the highest context fill and plan-limit use as percentages, compactions you asked for or that ran by themselves, subagents started (built-in, your own, in the background, forks) and teammates, and how many other mods, MCP servers and own agent types were active; counts only, never a prompt, an answer, a command, a path or a name. From 0.10.16 a Codex session carries the same keys read from its own rollout, with nothing installed: each turn's effort level, the models, and the highest context fill and plan-limit use |
| `collector_version` | the CLI version that measured it |
| `seq`, `prev`, `hash` | the line's place, the hash of the line before it, and its own hash |

A value the app did not record is left out, never written as 0. Each day also gets a proof in
`proofs/<day>.json` (the day's line count, a root hash over its lines, and a signature with this
computer's device key when it is coupled), and `manifest.json` holds the count and the last hash, so a
removed line is caught. The manifest names the computer and profile too.

**Never kept:** a prompt, an answer, code, a file or its path, a branch, a commit message, a title,
terminal output, or anything typed. The text in your sessions is read only to find clocks, model names
and counts, exactly as the session hook reads it.

- **What `--apply` writes.** Only the settings in the table above, each on a typed `y`. The file is
  copied to `settings.json.worktrust-backup-<date>` first, every other setting stays as it was, and a
  value you set higher is never lowered. Hermes's YAML is never edited.
- **Today is archived tomorrow.** A day goes into the archive once it is over; a later run only adds
  lines and never rewrites one.
- **What `--summary` counts.** From the archive, after its chain checks out: per month the measured
  hours, the tokens per model and the share of input served from the cache (where tokens go, and so
  where they can be saved), and the days on which two or more sessions ran in one project at the same
  time, with the most open at once and their session time against the wall-clock time they covered.
- **The archive is yours** to keep, copy, back up or delete. The free kit on
  [worktrust.io/preserve](https://worktrust.io/preserve) is this package plus a guideline, for teams
  that want the same record without WorkTrust.

## Rebuild the history

From **0.10.21**, changed measured history waits for review before it
can replace measurements already received for that computer, client and historical day.
The earlier receipt is retained as local activity, not independent proof of human effort.
Other computers and periods remain on the record, including an unavailable old laptop.
A support withdrawal is not reversed by reconnecting or running a rebuild.

Since 0.10.5 there is one path: `npx worktrust@latest history` always re-measures and replaces this computer's earlier
lines day by day. If a send did not finish, or you merged two keys of one computer, run `npx worktrust@latest` again:
it finishes what did not arrive and never counts a day twice.

A newer version of this command measures a session differently from an older one: what the seconds were (the model
answering, tools running, your own turns, pauses), your own turns rather than every message, tokens with the cache,
and more AI apps (Cursor, Copilot, Hermes, Goose, OpenCode, OpenClaw, Codex, Antigravity). Lines an earlier version
sent stand as they were measured then, and sending the sessions again would count those days twice: an old line
does not name its stretch, so WorkTrust cannot tell it from the one that arrives.

`npx worktrust@latest history --from-archive` (0.8.0) is for the sessions an AI app has already deleted (Claude
Code's default is 30 days). It sends what your local archive (`preserve --archive`) holds of them, and only that:
days of sessions no longer on the computer, each line marked as coming from your archive. One rule (2026-10-10):
a day signed by this computer's device key goes as it was measured; every other day (unsigned, signed by the local
archive key, or by another computer's key) goes as **reconstructed**, and the plan says how many of each. It refuses,
and sends nothing, when the archive does not verify or when WorkTrust does not yet accept the mark. It shows the plan
first and asks once; Enter is No. Such lines are history, like any import: never verified hours.

`npx worktrust@latest history --rebuild` re-measures every session still on this computer with the current rules and
sends them with one difference: WorkTrust **replaces** this computer's earlier lines, day by day.

- **What it does.** It shows the plan first: per AI app, the days and the measured hours it would send, and the first
  and last day. It asks once; Enter is No. `--dry-run` shows the plan and stops. Nothing is sent before a typed `y`.
  For every day and AI app it carries, WorkTrust withdraws this computer's earlier lines (sent by this key or by an
  earlier key of the same computer, live or as history), each with a correction row that says why, and then stores the
  re-measured lines. A line that arrives unchanged is kept as it is. A day is counted once, and the same rebuild sent
  twice changes nothing.
- **What it never does.** A replaced line is withdrawn and kept, never deleted: it stays in your record and the record shows
  each replacement; deleting your account still removes all of it. Never touched: another computer's lines, what a web
  connector (Claude or ChatGPT on the web) brought in, an AI app the batch does not carry, a day it does not carry, a line
  you made private, a line less than 48 hours old (the session hook's own window), and a line received in the last 12
  hours (the batches of one run never replace each other). It sends what `history` sends and nothing more: durations,
  token counts, model names, a layer keyword, counts; never text.
- **Only from this computer's own key.** A connector (an AI signed in on the web) cannot ask for a rebuild; WorkTrust
  refuses it at the door.
- **Offered once by `update`.** When this computer's earlier lines were measured by other rules (the copy in
  `~/.worktrust` says which; 0.10.31: the measuring rules, not the version), `npx worktrust@latest update` says so in
  plain words, lists what changed, shows the plan and asks once (0.10.30); Enter and `--yes` are No, `--rebuild`
  agrees in advance, and a version that measures as the one before offers nothing. The command cannot read your
  record, so it is an offer, not a finding.

## A web chat's data export

`npx worktrust@latest history --export <path>` (0.10.10) brings a ChatGPT data export (Settings → Data controls →
Export data) or a Claude data export (Settings → Privacy → Export data) onto your record as history, so years of
browser chats appear with their months, days and rhythm. The path is the zip the vendor sent you, the folder it was
unpacked into, or `conversations.json` itself; the vendor is told by the file's shape. Of the zip only
`conversations.json` is opened: the profile, memories and files beside it are never inflated. Claude on the web now
sends a manifest and one zip per category (0.10.17): give a `conversations-000.zip` part, the folder holding the
`conversations-*.zip` parts (read in part order), or the manifest json, which is read only for the file names of its
conversations parts lying beside it; its download links are never followed. The other parts (memories, projects,
artifacts, frames, design chats, the light metadata) are refused by name and never opened.

Any size (0.10.18): the file is read as a stream, a conversation at a time, so a gigabyte export reads in a bounded
memory; it keeps of each conversation only the clocks, roles, ids and a model name it needs (the counter, the text it
reads here). Bounds: a file to 64 GB, two million conversations, nesting to 64; a single conversation whose kept
fields pass 8 MB is left out and counted, never the export. A zip over 4 GB (zip64) is refused by name: unpack it and
give `conversations.json`. Every 64 MB a line on stderr says how many megabytes and conversations were read, nothing else.

- **What goes.** Per run of activity in a conversation (0.10.17; before, one line per conversation and day): a run
  ends where two messages lie more than thirty minutes apart, the gap after which the hook calls a stretch finished, so a
  conversation left open for hours is two windows, not one. Cutting changes the windows and never the total: the five
  minutes the clock counts after a message stay with the run before the gap. A day of one run keeps the name it had; a
  cut day replaces the one line an earlier send made of it. Each run: a neutral line (`A conversation in ChatGPT`, `A conversation in Claude on
  the web`), the seconds between the messages' clocks counted the way a measured day is (a pause over five minutes is
  not work; a day is cut at eight hours), your own turns as a count, the model's name where the export carries one, when
  it began and ended, and a stable name made of the conversation's id and the day, so the same export sent twice, or
  from two computers, is each line once. Never a title, never a message, never tokens (the export carries none and none
  are estimated).
- **What it counts as.** Hours **reconstructed**, shown on your record with their origin and never in your verified
  hours: an export file can be edited before it is read, and no device key witnessed those hours. WorkTrust holds this
  at the door and in the database, whatever the sender claims.
- **How it asks.** The plan first (the product, conversations, days, reconstructed hours, first and last month), then
  one question; Enter is No; `--dry-run` shows the plan and stops. On a coupled computer the bare `npx worktrust` looks
  in your Downloads folder (its top level only) for such an export it has not sent, offers it the same way, once, and
  remembers your answer by the file's digest, never by a conversation.
- **The export replaces.** On the days the export covers, its lines count and the earlier lines of that product your
  connector of the same vendor reported (an AI signed in on the web, which selects what it reports) are withdrawn and
  kept, each with a correction row, so a day counts once; the command says how many. A connector line that arrives later
  for a day the export covers is held. Lines that connector reported earlier under no product may describe the same
  conversations: the command says how many lie on those days and asks once, `Also withdraw N earlier lines your Claude
  connector reported for these days?`; Enter is No, `--yes` keeps No, `--dry-run` sends nothing, and only a typed yes or
  `--withdraw-unknown` said in advance withdraws exactly those lines on exactly those days, the same way, never deleting.
  The count in the question is the door's own, and it is the count the yes withdraws. Never touched, whatever you answer
  (0.10.19, held on the server): any line a computer of yours wrote (measured sessions, a rebuilt or archived history, an
  earlier export send), a measured line, a connector of another vendor, another product, a private line, a day the export
  does not cover.

## A copied session folder, and the local archive key

**One rule (2026-10-10).** Verified hours are what this computer's coupled key witnessed: the live session hook, the
AI apps' own folders read at history time, and an archive day signed by this computer's device key. Everything else
that carries clocks is **reconstructed**: shown on your record with its origin, never in your verified hours.

`npx worktrust@latest history --from-folder <dir>` brings in your own copy of an AI app's session folder: a backed-up
`~/.claude/projects`, `~/.codex/sessions`, or an Antigravity brain folder. It is read with the same readers and the
same clock as the live folders, never the live folders themselves (a path that is, or holds, one of them is refused).
Each day is named exactly as the live folder would name it, so a stretch this computer's own sessions already hold is
skipped (they win), and the same copy sent twice is each line once. What travels: the copy's own counts (tokens, your
turns, the model, the evidence kinds), as reconstructed hours, titled as from a copied session folder; not the hours in
layers, which say what a measured day's seconds were. The plan first, one question, Enter is No; `--dry-run` sends
nothing.

`preserve --archive` on a computer that is not coupled now signs each day's root with a **local archive key**
(`~/.worktrust/archive-key.json`, only you can read it), made once and said in one line. It needs no account and no
network and never leaves this computer. It is continuity, not proof of time: a day it signed can be told from an edit,
and the chain stays one computer's when you couple later (the device key then signs new days, and either key may seal
a day it sealed before), but such a day reaches WorkTrust as reconstructed. It is never offered as the device key at
pairing: `connect` always mints a fresh pair, because a private key that lived on disk before the pairing would weaken
the proof of possession the pairing binds, for nothing your record would gain.

## Credential protection

Existing installations keep private file storage until the person opts in. From 0.10.26,
run `worktrust update`, quit the AI apps, then run `worktrust protect-key` and restart
those apps. A new computer can run `worktrust protect-key` before connecting. `worktrust status`
shows the storage mode. This command is local and does not publish or change a Passport.

Protected mode encrypts the token, pending renewal token, device private key and coupling metadata
with AES-256-GCM in `~/.worktrust/key.json`. Its random encryption key lives in macOS Keychain,
Windows Credential Manager, or Linux Secret Service (`/usr/bin/secret-tool` from libsecret-tools,
with a running, unlocked desktop secret service). No keychain reset is performed. First-time
protection may require OS approval; background reads never request an unlock prompt. An unavailable
vault stops uploads without advancing their checkpoints. There is no plaintext fallback.

Migration verifies the vault write before atomically replacing the old file. No plaintext backup
is created. Existing backups and already running processes can still hold the old secrets; this
is not secure erasure of an SSD or revocation of previously copied credentials. The local archive's
separate continuity key (`archive-key.json`) is not migrated by this command. `preserve` remains
offline and refuses to silently change signing identity when protected credentials are unavailable.

- **AI apps use the bridge.** The bridge and hooks read the protected credentials as the OS user;
  their settings contain a launcher command, not the credentials. Update every installed bridge
  first: older releases cannot read the encrypted format. Protected mode refuses `--direct`.
- **A device signature proves possession.** The server stores the public key and checks fresh
  signed requests and single-use nonces. Neither file encryption nor an OS vault proves genuine
  local activity. Software authorized as the same OS user may still obtain or use these secrets.
  This is not a hardware-bound, non-exportable key. Revoke the connection if it may be compromised.
- **The key renews itself every week.** A new secret is made here, only its hash is sent, signed,
  and last week's key stops working.
- `npx worktrust --direct` writes a plain key into the apps' settings instead, for an app
  that cannot run a local command. Such a key is not bound to the computer and does not renew.

## What it reads, writes and sends

From **0.10.21**, before each submission the hook keeps a local
metadata file in `~/.worktrust/measurements/`. The `worktrust-measurement/1` format retains
the available timeline, opaque stretch reference, dates, counts and collector identifiers.
It omits prompts, answers, titles, repository names, file paths, endpoint URLs and credentials.
Files request mode 0600 in a mode-0700 directory; Windows ACLs need their own validation.
Retries retain the same metadata once; changed measurements get a separate file. Disconnecting
does not erase this journal. You control its retention and backups; it is not a remote backup.
Keep the regular `preserve --archive` archive too if your AI app removes its session files.
Metadata cannot reconstruct deleted conversation text or observations it never recorded.

A successful HTTP response alone does not advance progress. The hook requires an explicit
receipt; JSON-RPC errors, tool errors, incomplete receipts and partially refused batches are
retried safely. A row kept pending on WorkTrust remains excluded from counted activity.

| | |
|---|---|
| **Reads** | Which AI apps are installed (the settings folders of Claude Code, Codex, Cursor, Gemini CLI, Antigravity, VS Code, Windsurf, Hermes Agent, Goose, OpenCode, OpenClaw), and the chats Cursor and Copilot keep (clocks, models and token counts only). Afterwards, the session hook reads Claude Code's, Codex's and Antigravity's session files, the session databases of Hermes, Goose, OpenCode and OpenClaw, and the chats Cursor and Copilot keep, on this computer to measure durations and token counts. |
| **Writes** | The key file (above). In each AI app's MCP settings (`~/.claude.json` through `claude mcp`, `~/.cursor/mcp.json`, `~/.codex/config.toml`, `~/.gemini/settings.json`, `~/.gemini/config/mcp_config.json` (Antigravity), VS Code's `mcp.json`, Windsurf's `mcp_config.json`, Hermes's and Goose's `config.yaml`, OpenCode's `opencode.json`, OpenClaw through `openclaw mcp set`) a WorkTrust entry that runs the local bridge, with no key in it; four hooks in `~/.claude/settings.json` (SessionStart, SessionEnd, PreCompact and, since 0.10.32, Stop, which sweeps at most once an hour); the bridge, the hook and the counter in `~/.worktrust/`; and `~/.worktrust/consent.json`, what you agreed to (names and days only, 0.10.30). |
| **Sends, to pair** | This computer's system (macOS, Windows, Linux) and host name. WorkTrust also records the network address the request arrives from, as a security record kept 90 days and seen only by WorkTrust staff (to answer a theft or fraud report). |
| **Sends, afterwards** | Per measured stretch of work, and nothing else: its timeline and basis (`timeline`, `duration_basis`: since 0.10.20 the CLI sends no duration and no hours in layers of its own; WorkTrust computes them from the timeline), token counts (`tokens_in`, `tokens_out`, `tokens_cache_read`, `tokens_cache_write`, `token_basis`), the model's name (`model`), the kind of work and one layer keyword such as frontend or backend (`title`, `kind`, `layer`, `layers`), closed technology keys (`stack`) and separate display-only tool keys (`tools_seen`), how the turns are counted (`turn_basis`; the counts themselves WorkTrust reads from the timeline), the subagent runs that started in the stretch, by position only (`agents`, since 0.10.32: per run its kind, builtin, own, background or fork, its start and active intervals in whole seconds from the stretch's start, and its tool failures and recoveries as counts; never a name, a prompt, a path or an id; at most 64 runs, 12 intervals a run, 256 in all), when it began and ended and your computer's offset from UTC (`started_at`, `at`, `utc_offset`), what the CLI derived from the stretch as kinds and counts (`evidence`: checks run and failed, delivery steps and whether a check passed first, recoveries, delegation, context, routing, steering, refusals, planning, files and test files changed, the complexity class; with the WorkTrust mod on, its `live` counts from inside Claude Code: permission answers, effort levels, context and plan-limit peaks, subagents and setup; never a word, a command or a path; since 0.8.3, `live` since 0.10.15), a hash of the session and the day (`stretch_ref`), `steered_from` when it ran over SSH, the stretch's clock as step kinds and whole seconds so WorkTrust computes the figures itself (`timeline`, since 0.10.20: never a word, a tool name or a path), how the session was started as the AI app recorded it, beside the timeline (`session_kind`: interactive, headless or scheduled, since 0.10.29; left out when the app did not say), each model answer's outcome as one character, completed, failed or not known (`call_outcomes`, since 0.10.32), and in a run no person started the length of each of your turns as a bucket (`input_lengths`) and a timer's cadence word with an opaque reference (`schedule_cadence`, `schedule_ref`), the CLI's version and a digest of its own files as signals (`cli_version`, `cli_digest`), and, so the work can be matched to GitHub, the repository as its remote's owner/name (`repo`, only for a repository on GitHub, GitLab or Bitbucket, the hosts WorkTrust can couple; never one on your own or a client's server), for any other git repository a code in its place (`repo_code`: 16 hex of an HMAC of its remote, or its root, keyed with this computer's own secret in `~/.worktrust/archive-salt`, which is never sent, so WorkTrust can group its lines but cannot tell which repository it is) and the hashes of the commits made in the stretch (`commits`, never their messages). With a re-measure (0.10.32), each batch also carries a digest of each day it holds as this computer computed it (`days`: a date and 64 hex, never a line), the question before it asks only for the digests this computer sent before, and a count of transcripts this computer could not read rides beside that question (`unreadable`: a number, never which file). |
| **Never sends** | Prompts, answers, code, file names or paths, commit messages, branch names, or the name of your local folder (a repository is named only as its remote's owner/name, above). The door has no field for them and refuses a submission that carries them. |

**The clock is WorkTrust's, not this computer's (0.10.20).** A measured stretch travels as its timeline: one step per
transcript line, as a kind (your turn, the model's answer, a tool call, a tool's result, a question that waited for you, an
interruption) and the whole seconds since the previous step. Nothing of a message is in it: no word, no tool name, no path.
This CLI computes no duration and no hours of its own and carries no rule for doing so; WorkTrust computes the seconds, the
hours in layers and the turns from the timeline when it arrives, and the figures the terminal shows after a send are
WorkTrust's receipt. The line also names the CLI's version and a digest of its own files, as signals of which code ran,
never as proof.

## Why you can check it

- **No npm dependencies and no install scripts.** Plain files, readable
  in an afternoon: `worktrust.mjs` (this command), `setup-mcp.mjs` (writes the MCP entries),
  `log-session.mjs` (the session hook), `count-behaviour.mjs` (the local counter) and `preserve.mjs`
  (keep your history), with the readers they import.
- **Bundled measurement modules.** The npm package includes its counter and readers. Interactive
  commands can check the registry for a version notice; they no longer execute another npm
  version automatically. Installation stays with the selected package manager. See SECURITY.md.
- **Provenance.** The release workflow requests npm provenance from the public source repository.
  Verify the actual version's attestation and contents before relying on that origin; the manifest
  setting alone does not establish it. `npm audit signatures` checks an installed dependency tree.
- **Read it before you run it:** `npm pack worktrust` downloads the package as a file without
  running anything.
- **The key** never appears on a command line a process list could show: it is written to its file
  and reaches the bridge and the hook only in their environment.

## A computer that is already coupled, or shared

- `npx worktrust@latest connect` on a computer that is already coupled says to which account (masked) and
  asks `Couple it again? [y/N]`. Enter and `--yes` mean No; `--replace` says yes in advance.
- The browser page that approves it shows, large, which WorkTrust account is signed in, with
  **Use another account**: the computer goes to whoever approves it there.
- Once the new key is in place, the old key is ended at WorkTrust (the request is signed by this
  computer's own device key). An AI app still open on the old key is refused and moves to the new one.
- When the new account is a different one, the old account sees a notice that its computer moved,
  with the computer's name and the moment, never the other account; no earlier work on this
  computer is offered to the new account, only work from the moment of coupling.
- `npx worktrust@latest status` shows the account this computer sends to.
- Different people on one computer with their own OS user each couple their own: everything lives
  in that user's home folder, and the accounts never meet.

## Undo

`npx worktrust@latest disconnect` removes the WorkTrust entries (Hermes's hook with them), the hook (and Codex's `notify` line and
Antigravity's `worktrust` hook when WorkTrust set them), the credentials, installed bridge scripts and the record of
what you agreed to (`~/.worktrust/consent.json`, 0.10.30).
Protected mode retains an encrypted empty slot and its OS wrapping key so reconnecting stays protected.
A small note of the previous account (masked) remains so that a later coupling by another account
does not offer its earlier work. Other retained files and your local evidence archive are not an
automatic server or archive erasure.
Then revoke the key in WorkTrust: Sources → Devices → this computer → Revoke.

## Remote Agent: steer this computer's agents from your phone or browser (`npx worktrust remote`)

Off until you run `npx worktrust remote app` (or `remote web`) at this keyboard; an AI agent's shell is refused every
`remote` command except `status`.

- `app` and `web` make a REMOTE key pair for this computer (Ed25519 and X25519, files of mode 0600 in `~/.worktrust/remote/`),
  never the measurement key, and has it approved in WorkTrust with your second factor; then it starts a service while you
  are logged in (launchd on macOS, a systemd user unit on Linux, linger off; on Windows `npx worktrust remote run` in a
  terminal) and draws a QR code for the WorkTrust app. `pair` draws a new one: five minutes, one phone, once. A phone
  that scanned it is confirmed; one that typed the code instead waits for `npx worktrust remote phones confirm`.
- Two roads to approve the computer's key: `npx worktrust remote app` shows the approval as a QR code here (no browser);
  the WorkTrust app scans it and you approve with your authenticator code. `npx worktrust remote web` opens the approval
  page in your browser. Both take `--gateway` and `--device`; `remote enable` (0.11.6 and before) is gone since 0.11.7.
- `projects add <folder>` grants a folder (its real path; never your home folder, the disk's root or a folder holding
  keys, keychains, browser profiles or wallets). A phone starts agents only in granted folders, several at once (four by
  default).
- `connections` lists every phone and browser linked to this computer (name, kind, fingerprint, since, last seen) and
  this computer's own link. `disconnect <number|name|fingerprint>` closes one after two confirmations (y, then the start
  of its fingerprint or its name typed); `disconnect --all` closes every one after you type `close all`. Without a
  terminal both refuse. `phones remove` does the same removal. End a key for your whole account in WorkTrust, Settings,
  Remote Agent.
- `roots add <folder> [--git-init]` adds a folder your projects live in (the same rules). A phone may open the git
  projects already directly inside it (the most recently changed first, thirty in all with the granted ones) and create
  one new, empty project folder in it. A phone names a project by the id this computer gave it, never by a path. In the
  menu (Remote Agent, Roots) you tick suggested folders or use your system's folder picker instead of typing.
- `modes allow|deny edit|auto` and `modes status`: the agent modes a phone may start here. Manual and Plan always; Edit
  automatically and Auto only once allowed here (Auto includes Edit). The computer refuses a mode above what you allowed.
  `admin on|off`: whether a change made in the WorkTrust app or on the web (allowed modes, folders, roots, connections)
  is taken here. On by default; each such change asks your authenticator there, carries WorkTrust's signature on that
  exact change for this computer (five minutes, one use), is checked here against the keys built into this CLI, and is
  said in the `remote run` terminal. `admin off` keeps every change at this keyboard. The switch itself changes only here.
- From a phone you may approve: a file edit inside the project, a test, build or lint command from a short reviewed list,
  and a message an agent sends through a connector, shown whole (channel, every recipient, subject, text, attachment
  names). Everything else is decided at this keyboard or not at all: installs from the network, `git push`, deploys,
  deleting outside the project, reading secret files, any "always allow". It is denied on this computer, and the phone is
  told why.
- One outbound connection to the WorkTrust gateway, end-to-end encrypted: the gateway relays sealed messages and reads no
  prompt, file, path, output or model name. No port is opened on this computer.
- A session steered from a phone is never your AI Hours: the service records it in `~/.worktrust/remote/steered.jsonl`
  before the agent starts, and the session hook sends it as an agent run (`session_kind` headless, `steered_from`
  remote).
- `status`, `pause`, `resume`, `disable` (the hard off; `--forget` also deletes the remote keys), `phones`, `projects`.

- From a browser (app.worktrust.io › Remote Agent): approve the browser in WorkTrust with your passkey, your
  authenticator and a 6-digit PIN (asked again after five minutes without your input; agents keep running meanwhile).
  Run `npx worktrust remote pair` here and paste the link it prints into the browser. Then confirm the browser's
  fingerprint at this keyboard: `npx worktrust remote phones confirm <fingerprint>`. A browser is never confirmed by the
  link alone. With `npx worktrust remote phones allow-endorse on`, a phone confirmed here may add a browser it scanned
  instead (off by default). A PIN reset in WorkTrust removes every browser link; phones keep theirs.

Remote needs Node 22.4 or later (the Python package bundles one). It connects to the WorkTrust gateway
(`wss://remote.worktrust.io`, live since 2026-11-09).

## Requirements

Node 18 or later for the base CLI. SQLite session readers require Node 22.5 or later with `node:sqlite`;
without it, those clients are not read. macOS, Linux or Windows; available readers depend on the local client format.

See [SECURITY.md](SECURITY.md) for the credential-file threat model, network/update behaviour and known
trust limits. A local signature proves possession of a key, not independent observation of the work.

Security reports: see [SECURITY.md](SECURITY.md).

## Licence

Use is allowed under the WorkTrust CLI Licence, for the WorkTrust service only; copying, modifying or redistributing the
code is not, and neither is using it, or what you learned from reading it, as a model for any other product or
platform (rewriting, porting or translating it included). See LICENSE.
The licence is free of charge. `preserve` (with `--apply`, `--archive`, `--verify` and `--summary`) is for everyone,
with or without an account; every other feature is for WorkTrust account holders, and without an account the rest may
only be installed and evaluated. The archives and files the CLI makes from your own data are yours.
Version 1.1 of the licence applies from 0.10.39; 0.10.18 to 0.10.38 were published under version 1.0; versions up to and
including 0.10.17 were published under the MIT licence and stay under it.

## Release signatures and the limits of verification

From 0.10.22, the official launcher verifies fixed release files through `worktrust-launch.mjs` before
starting the shared engine. Python uses the `pycryptodomex` library to verify its package and
bundled runtime before Node executes. Final npm/Python/source/preservation downloads are
covered by an Ed25519-signed `release-artifacts.json`, containing their SHA-256 values and the
source commit. Verify against the separately pinned publisher key, not a key supplied by the manifest.

The initial package-manager installation and host interpreter are trusted bootstrap boundaries.
A computer owner can alter or bypass a launcher; software signatures do not attest execution.

Local Claude records and other client activity are outside this release manifest. An official
CLI can read edited input. `cli_digest` remains client-reported diagnostic metadata and cannot
prove which program ran. SHA-256/SHA-512 are not encryption; HTTPS protects transport. Public
claim eligibility remains the server publication gate's responsibility.

Revoking a computer key stops new submissions, not the validity of every historical publication.
Passport withdrawal is a separate audited operation. Neither operation automatically erases the
person's prior data. Release signing keys, computer keys and passport signing keys are separate.

In 0.10.25, hooks and helper processes from the official launcher stay inside the checked
release. The old loose `~/.worktrust/count-behaviour.mjs` and individual-script download
fallbacks are no longer executed. Persistent Python hooks use the host Python to check the
copied Node runtime before starting it, even after the temporary uvx/pipx cache is removed.
Keep that host Python installed. Updating preserves credentials, pending uploads and archives;
it does not approve held history or publish a passport automatically.
