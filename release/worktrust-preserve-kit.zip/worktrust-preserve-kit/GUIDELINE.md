# WorkTrust AI Work Evidence Preservation Guideline

**Preserve now. Verify later.** Metadata first. Content never by default. Free to use without a WorkTrust account.

This kit helps you, or your team, keep a portable record of AI-assisted work on your own computers. The folder is the
WorkTrust CLI as npm ships it plus this guideline; its `preserve` command contacts no server at all, WorkTrust or any
other, and needs no account. The CLI's other commands (connecting a computer to WorkTrust) are only for people who
choose WorkTrust. Read every file before you run it: plain JavaScript, no dependencies, no install.

## 1. Why

AI tools were not built to keep your professional history. Several delete it on their own schedule:

| Tool | Kept by default | Keep it longer |
|---|---|---|
| Claude Code | 30 days, then deleted silently | `"cleanupPeriodDays": 3650` in `~/.claude/settings.json` (0 is not allowed) |
| Gemini CLI | 30 days | `"general": { "sessionRetention": { "enabled": false } }` in `~/.gemini/settings.json` |
| Hermes Agent | 90 days for ended sessions | `sessions.auto_prune: false` in Hermes' config |
| Codex CLI | no deletion documented | nothing to change |
| Cursor, OpenCode, Goose, LM Studio | not documented | back the history up yourself |
| GitHub Copilot Chat (VS Code) | not documented; synced to GitHub by default | `"chat.sessionSync.enabled": false` keeps it local |
| Ollama, llama.cpp, vLLM | no history kept | a collector is needed (vLLM exposes token and latency metrics) |
| Hugging Face Inference Endpoints | operational logs 30 days; payloads and tokens not stored | keep your own log |

Each line comes from the vendor's own documentation (checked 6 October 2026). "Not documented" means the vendor
states no retention; it does not mean forever.

## 2. The evidence levels

| Level | Meaning |
|---|---|
| 1 Self-reported | A claim without technical evidence. |
| 2 Historical | Records found later; useful, but nobody watched them being made. |
| 3 Observed | A collector recorded the work while it happened. |
| 4 Anchored | Observed records, hashed, signed, and their daily root kept somewhere you do not control alone. |

Data found later stays historical. It never becomes "observed" by being imported.

## 3. What to keep, and what never to keep

Keep: timestamps and durations, the client and model name, token counts when the tool records them, counts of tool
calls, tests, builds and subagents, a hashed project identifier, the collector's version, and integrity information.

Never keep by default: prompts, model answers, source code or file contents, file paths, terminal output, secrets,
and personal data inside the work. Store "test run, 18.4 s, passed, 13:42", not the test output.

## 4. Do it in three steps

1. **Stop the deleting.** `node worktrust-launch.mjs preserve` shows what each tool on this computer keeps; `node
   worktrust-launch.mjs preserve --apply` asks before each change, backs the settings file up first, and never lowers a value
   you set higher.
2. **Archive the metadata.** `node worktrust-launch.mjs preserve --archive` writes `~/AI-Evidence/YYYY/MM/stretches.jsonl`
   (one line per session per day: client, model, minutes, tokens, the time split, subagents) and a daily root in
   `proofs/`. Run it daily or weekly (cron, launchd, Task Scheduler). It only appends; it never rewrites a line.
3. **Check it.** `node worktrust-launch.mjs preserve --verify` recomputes every hash, the chain and each day's root. One
   changed number anywhere and it says which line.

Back the `AI-Evidence` folder up the way you back up everything else, encrypted.

## 5. Integrity, briefly

Every archive line carries the hash of the line before it, so an edit or a deletion breaks every later link. Each day
gets a root over its lines. When this computer holds a WorkTrust device key the root is signed with it (Ed25519);
otherwise it is signed with a local archive key the tool makes once (`~/.worktrust/archive-key.json`, readable by
you alone, no account, no network), which is continuity rather than proof of time: WorkTrust counts a day signed by
the coupled device key as measured and any other day as reconstructed. A chain on one computer can be rebuilt by whoever controls that computer, so
for stronger evidence copy the daily roots (only the roots, they reveal nothing) somewhere else: a team share, a git
repository, or later WorkTrust.

Cryptography proves that records were not changed after a moment. It does not prove that the work was good, who did
every part, or what someone can do. That takes interpretation and other sources.

## 6. For teams: measured internally, for audit and for fewer tokens

A team can run the kit on every developer machine and collect the archives in a place the team controls. Nothing
leaves the organisation. What it gives you:

- **An audit trail of AI use**: which clients and models ran, when, for how long, with how many subagents, per
  project hash, with a chain that shows tampering.
- **Token reduction**: tokens per model and per month, and the share served from the cache. A low cache share or a
  model doing work a smaller one could do is where tokens are saved.
- **Parallel work**: several sessions in one repository at the same time are separate lines with their own start and
  end, so overlap per project and day can be counted instead of guessed.
- **Retention you decide**, independent of any vendor's history window. Suggested: raw metadata 24 months at least,
  monthly totals and daily roots permanently, secrets never.

Agree beforehand what is measured and why, tell the people it concerns, and keep personal data out. Under the EU AI Act
logging becomes an obligation for high-risk systems (for example AI that evaluates people at work); this kit is a
record of your own use, not such a system. Ask your legal team for your own case.

## 7. Later, if you want

The archive is a plain, documented format. WorkTrust can import it as historical evidence, and from the moment the
WorkTrust CLI records your work as it happens, new evidence counts as observed. Older evidence keeps its level.

Your AI work history belongs to you. Preserve it.
